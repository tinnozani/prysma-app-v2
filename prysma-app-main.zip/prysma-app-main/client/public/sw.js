// prysma_ :: service worker para notificações push
const CACHE_NAME = "prysma-sw-v4"; // incrementado para forçar limpeza de cache no iOS

self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  // Limpa todos os caches antigos ao ativar nova versão do SW
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      )
    ).then(() => self.clients.claim())
  );
});

// Recebe mensagens do cliente para agendar notificações
self.addEventListener("message", (event) => {
  if (event.data?.type === "SCHEDULE_CHECKIN") {
    const { day, hour, minute } = event.data.payload;
    // Armazena configuração no cache
    caches.open(CACHE_NAME).then((cache) => {
      cache.put(
        new Request("/_prysma_checkin_config"),
        new Response(JSON.stringify({ day, hour, minute, enabled: true }))
      );
    });
  }

  if (event.data?.type === "CANCEL_CHECKIN") {
    caches.open(CACHE_NAME).then((cache) => {
      cache.delete(new Request("/_prysma_checkin_config"));
    });
  }

  if (event.data?.type === "TEST_NOTIFICATION") {
    self.registration.showNotification("prysma_ :: check-in semanal", {
      body: event.data.body ?? "lembrete de check-in configurado com sucesso.",
      icon: "/apple-touch-icon.png",
      badge: "/apple-touch-icon.png",
      tag: "prysma-checkin",
      requireInteraction: false,
    });
  }
});

// Verifica periodicamente se é hora de disparar a notificação
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "prysma-checkin-check") {
    event.waitUntil(checkAndNotify());
  }
});

// Fallback: verifica a cada fetch (não ideal, mas funciona sem PeriodicSync)
self.addEventListener("fetch", () => {
  checkAndNotify();
});

async function checkAndNotify() {
  try {
    const cache = await caches.open(CACHE_NAME);
    const response = await cache.match(new Request("/_prysma_checkin_config"));
    if (!response) return;

    const config = await response.json();
    if (!config.enabled) return;

    const now = new Date();
    const dayNames = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];
    const currentDay = dayNames[now.getDay()];
    const currentHour = String(now.getHours()).padStart(2, "0");
    const currentMinute = String(now.getMinutes()).padStart(2, "0");

    if (
      currentDay === config.day &&
      currentHour === config.hour &&
      currentMinute === config.minute
    ) {
      // Verifica se já notificou nos últimos 2 minutos
      const lastNotified = config.lastNotified ?? 0;
      if (Date.now() - lastNotified < 120_000) return;

      // Atualiza lastNotified
      config.lastNotified = Date.now();
      await cache.put(
        new Request("/_prysma_checkin_config"),
        new Response(JSON.stringify(config))
      );

      await self.registration.showNotification("prysma_ :: check-in semanal", {
        body: `}_ hora do seu check-in semanal, comandante. a sala de comandos aguarda.`,
        icon: "/apple-touch-icon.png",
        badge: "/apple-touch-icon.png",
        tag: "prysma-checkin",
        requireInteraction: true,
        actions: [
          { action: "open", title: ":: abrir app" },
          { action: "dismiss", title: "depois" },
        ],
      });
    }
  } catch (e) {
    // Silencia erros do SW
  }
}

// Clique na notificação abre o app
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  if (event.action === "open" || !event.action) {
    event.waitUntil(
      self.clients.matchAll({ type: "window" }).then((clients) => {
        if (clients.length > 0) {
          clients[0].focus();
          clients[0].navigate("/checkin");
        } else {
          self.clients.openWindow("/checkin");
        }
      })
    );
  }
});
