import { CrystalEnergy } from "@/components/CrystalEnergy";

export default function Simulacao() {
  return (
    <div className="p-8 space-y-12 bg-background min-h-screen">
      <div className="space-y-2">
        <h1 className="text-2xl font-mono text-prysma-bright">}_ doca de simulação ::</h1>
        <p className="text-muted-foreground font-mono text-sm">espelhamento em tempo real do kernel v7.2</p>
      </div>

      <section className="space-y-4">
        <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest font-mono">:: cristais de energia (estatístico)</h2>
        <div className="max-w-xs p-6 rounded-2xl border border-space-border bg-card-widget">
          <CrystalEnergy />
        </div>
      </section>

      <section className="space-y-4">
        <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-widest font-mono">:: leme de navegação (sidebar mockup)</h2>
        <div className="w-64 h-40 rounded-2xl border border-prysma-dim/20 bg-prysma-faint/10 p-4 flex flex-col justify-between">
           <div className="h-2 w-full bg-space-mid rounded-full overflow-hidden">
              <div className="h-full bg-prysma-core w-1/3"></div>
           </div>
           <p className="text-[10px] font-mono text-prysma-bright/60">implementação: 1/5 fases concluídas</p>
        </div>
      </section>
    </div>
  );
}