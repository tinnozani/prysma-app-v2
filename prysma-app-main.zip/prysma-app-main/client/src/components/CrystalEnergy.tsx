import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Zap, Battery, BatteryMedium, BatteryLow, BatteryWarning } from "lucide-react";

interface CrystalEnergyProps {
  compact?: boolean;
  className?: string;
}

export function CrystalEnergy({ compact = false, className }: CrystalEnergyProps) {
  const { data: credits, isLoading } = trpc.credits.getWeekly.useQuery(undefined, {
    refetchInterval: 60_000,
  });

  const typedCredits = credits as CreditsData | undefined;

  if (isLoading || !typedCredits) {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <div className="w-5 h-5 rounded-full bg-space-mid animate-pulse" />
        {!compact && <div className="w-16 h-2 rounded bg-space-mid animate-pulse" />}
      </div>
    );
  }

  const overallPct = typedCredits.summary.totalAvailable > 0
    ? Math.round(((typedCredits.summary.totalAvailable - typedCredits.summary.totalUsed) / typedCredits.summary.totalAvailable) * 100)
    : 0;

  const energyColor =
    overallPct > 60
      ? "text-prysma-core"
      : overallPct > 30
      ? "text-[oklch(0.78_0.18_75)]"
      : "text-[oklch(0.65_0.22_25)]";

  if (compact) {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            className={cn(
              "flex items-center gap-1.5 px-2 py-1 rounded-lg",
              "bg-space-mid/50 hover:bg-space-surface/80 transition-colors",
              "border border-space-border/40",
              className
            )}
          >
            <CrystalIcon pct={overallPct} size="sm" />
            <span className={cn("text-xs font-mono font-medium", energyColor)}>
              {overallPct}%
            </span>
          </button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="bg-space-dark border-space-border p-3 w-56">
          <CrystalDetail credits={typedCredits} />
        </TooltipContent>
      </Tooltip>
    );
  }

  // Formatar data de renovação
  const renewalText = formatRenewal(typedCredits.weekEnd);

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CrystalIcon pct={overallPct} size="md" />
          <span className="text-sm font-medium text-foreground font-mono">cristais de energia</span>
        </div>
        <span className={cn("text-sm font-mono font-semibold", energyColor)}>
          {overallPct}%
        </span>
      </div>

      <CrystalDetail credits={typedCredits} />

      <p className="text-xs text-muted-foreground font-mono">
        {renewalText}
      </p>
    </div>
  );
}

// Formata: ":: energia renova domingo } 23/03/26 às 00:00"
function formatRenewal(weekEnd?: Date | string | null): string {
  if (!weekEnd) return ":: energia renova no domingo";
  const d = new Date(weekEnd);
  const weekday = d.toLocaleDateString("pt-BR", { weekday: "long" });
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yy = String(d.getFullYear()).slice(2);
  const hh = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");
  return `:: energia renova ${weekday} } ${dd}/${mm}/${yy} às ${hh}:${min}`;
}

interface CreditsData {
  sonnet: { total: number; used: number; remaining: number; orbitaUsed: boolean; orbitaAvailable: boolean };
  haiku: { total: number; used: number; remaining: number };
  summary: { totalUsed: number; totalAvailable: number; percentUsed: number };
  weekStart: Date;
  weekEnd: Date;
}

function CrystalDetail({ credits }: { credits: CreditsData }) {
  const sonnetPct = credits.sonnet.total > 0
    ? Math.round((credits.sonnet.remaining / credits.sonnet.total) * 100)
    : 0;
  const haikuPct = credits.haiku.total > 0
    ? Math.round((credits.haiku.remaining / credits.haiku.total) * 100)
    : 0;

  return (
    <div className="space-y-2.5">
      {/* Sonnet — modo expansão */}
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-sonnet-core" />
            <span className="text-xs text-muted-foreground font-mono">modo expansão</span>
          </div>
          <span className="text-xs font-mono text-sonnet-bright">
            {credits.sonnet.remaining}/{credits.sonnet.total}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-space-mid overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sonnet-glow to-sonnet-bright transition-all duration-500"
            style={{ width: `${sonnetPct}%` }}
          />
        </div>
        {credits.sonnet.orbitaAvailable && (
          <p className="text-xs text-haiku-core flex items-center gap-1 font-mono" style={{ display: 'none' }}>
            <Zap className="w-3 h-3" />
            órbita semanal disponível
          </p>
        )}
      </div>

      {/* Haiku — modo foco */}
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-haiku-core" />
            <span className="text-xs text-muted-foreground font-mono">modo foco</span>
          </div>
          <span className="text-xs font-mono text-haiku-bright">
            {credits.haiku.remaining}/{credits.haiku.total}
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-space-mid overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-haiku-glow to-haiku-bright transition-all duration-500"
            style={{ width: `${haikuPct}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function CrystalIcon({ pct, size = "md" }: { pct: number; size?: "sm" | "md" | "lg" }) {
  const sizeMap = { sm: "w-4 h-4", md: "w-5 h-5", lg: "w-7 h-7" };
  const color =
    pct > 60
      ? "text-prysma-core"
      : pct > 30
      ? "text-[oklch(0.78_0.18_75)]"
      : "text-[oklch(0.65_0.22_25)]";

  // Ícone de pilha (Battery) variando conforme nível de energia
  const IconComponent = pct > 60 ? Battery : pct > 30 ? BatteryMedium : BatteryLow;

  return <IconComponent className={cn(sizeMap[size], color)} />;
}
