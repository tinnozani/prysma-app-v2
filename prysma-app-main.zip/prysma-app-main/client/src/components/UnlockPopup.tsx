import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

// ─── Logo Prysma (triângulo roxo) ─────────────────────────────────────────────
function PrysmaTriangle() {
  return (
    <div className="w-14 h-14 relative">
      <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        <defs>
          <radialGradient id="popupGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="oklch(0.75 0.24 290)" stopOpacity="0.4" />
            <stop offset="100%" stopColor="oklch(0.62 0.25 270)" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="popupGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.75 0.24 290)" />
            <stop offset="50%" stopColor="oklch(0.68 0.22 295)" />
            <stop offset="100%" stopColor="oklch(0.62 0.25 270)" />
          </linearGradient>
        </defs>
        <circle cx="24" cy="24" r="22" fill="url(#popupGlow)" />
        <polygon points="24,6 40,36 8,36" fill="none" stroke="url(#popupGrad)" strokeWidth="2.5" strokeLinejoin="round" />
        <line x1="24" y1="6" x2="24" y2="36" stroke="url(#popupGrad)" strokeWidth="1.5" strokeOpacity="0.6" />
        <line x1="24" y1="22" x2="40" y2="36" stroke="url(#popupGrad)" strokeWidth="1" strokeOpacity="0.4" />
        <line x1="24" y1="22" x2="8" y2="36" stroke="url(#popupGrad)" strokeWidth="1" strokeOpacity="0.4" />
        <circle cx="24" cy="22" r="2.5" fill="url(#popupGrad)" />
      </svg>
    </div>
  );
}

// ─── Mapa de labels para cada fase desbloqueada ───────────────────────────────
const UNLOCK_LABELS: Record<string, string> = {
  missoes_semana:     "missões da semana desbloqueadas!",
  checkin_semanal:    "check-in semanal desbloqueado!",
  comandos:           "biblioteca de comandos desbloqueada!",
  revisao_trimestral: "revisão trimestral desbloqueada!",
};

interface UnlockPopupProps {
  unlockedPhaseId: string | null;
  onClose: () => void;
}

export function UnlockPopup({ unlockedPhaseId, onClose }: UnlockPopupProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (unlockedPhaseId) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setTimeout(onClose, 400); // aguarda a animação de saída
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [unlockedPhaseId, onClose]);

  if (!unlockedPhaseId) return null;

  const label = UNLOCK_LABELS[unlockedPhaseId] ?? `${unlockedPhaseId} desbloqueado!`;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[200] flex items-center justify-center p-4 transition-all duration-400",
        visible ? "opacity-100" : "opacity-0 pointer-events-none"
      )}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={() => { setVisible(false); setTimeout(onClose, 400); }}
      />

      {/* Card */}
      <div
        className={cn(
          "relative z-10 flex flex-col items-center gap-5 px-10 py-8 rounded-2xl border border-prysma-dim/40 bg-space-deep shadow-2xl shadow-prysma-core/20 max-w-sm w-full text-center transition-all duration-400",
          visible ? "scale-100 translate-y-0" : "scale-95 translate-y-4"
        )}
      >
        {/* Logo animado */}
        <div className="crystal-pulse">
          <PrysmaTriangle />
        </div>

        {/* Título */}
        <div className="space-y-1">
          <p className="text-prysma-bright font-mono text-base font-semibold tracking-wide">
            {"}_"} parabéns!
          </p>
          <p className="text-foreground/80 text-sm font-mono">
            você concluiu mais uma etapa!
          </p>
        </div>

        {/* Item desbloqueado */}
        <div className="px-4 py-2.5 rounded-xl bg-prysma-faint border border-prysma-dim/50">
          <p className="text-prysma-bright font-mono text-sm font-medium">
            {">> "}{label}
          </p>
        </div>

        {/* Botão fechar */}
        <button
          onClick={() => { setVisible(false); setTimeout(onClose, 400); }}
          className="text-xs text-muted-foreground/60 font-mono hover:text-muted-foreground transition-colors"
        >
          :: continuar
        </button>
      </div>
    </div>
  );
}
