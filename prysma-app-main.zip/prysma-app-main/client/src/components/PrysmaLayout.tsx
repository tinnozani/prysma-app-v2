import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { cn } from "@/lib/utils";
import { trpc } from "@/lib/trpc";
import {
  BookOpen,
  Lock,
  LogOut,
  MessageSquare,
  Sun,
  User,
  Map,
  CalendarCheck,
  RotateCcw,
  Terminal,
  Bell,
  Menu,
  X,
  Battery,
  HelpCircle,
  ChevronDown,
  Rocket,
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { CrystalEnergy } from "./CrystalEnergy";
import { BrainFloating } from "./BrainFloating";
import { toast } from "sonner";
import { useState } from "react";

// ─── Ícone Prysma (prisma) ────────────────────────────────────────────────────
function PrysmaLogo({ size = "md", animated = false }: { size?: "sm" | "md" | "lg" | "xl"; animated?: boolean }) {
  const sizeMap = { sm: "w-7 h-7", md: "w-9 h-9", lg: "w-14 h-14", xl: "w-20 h-20" };
  return (
    <div className={cn(sizeMap[size], "relative shrink-0", animated && "crystal-pulse")}>
      <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        <defs>
          <radialGradient id="prysmaGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="oklch(0.75 0.24 290)" stopOpacity="0.3" />
            <stop offset="100%" stopColor="oklch(0.62 0.25 270)" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="prysmaGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.75 0.24 290)" />
            <stop offset="50%" stopColor="oklch(0.68 0.22 295)" />
            <stop offset="100%" stopColor="oklch(0.62 0.25 270)" />
          </linearGradient>
        </defs>
        <circle cx="24" cy="24" r="22" fill="url(#prysmaGlow)" />
        <polygon points="24,6 40,36 8,36" fill="none" stroke="url(#prysmaGrad)" strokeWidth="2" strokeLinejoin="round" />
        <line x1="24" y1="6" x2="24" y2="36" stroke="url(#prysmaGrad)" strokeWidth="1" strokeOpacity="0.5" />
        <line x1="24" y1="22" x2="40" y2="36" stroke="url(#prysmaGrad)" strokeWidth="1" strokeOpacity="0.3" />
        <line x1="24" y1="22" x2="8" y2="36" stroke="url(#prysmaGrad)" strokeWidth="1" strokeOpacity="0.3" />
        <circle cx="24" cy="22" r="2" fill="url(#prysmaGrad)" />
      </svg>
    </div>
  );
}

// ─── Estrutura de Navegação ────────────────────────────────────────────────────
// Ordem de desbloqueio sequencial:
// plano_voo (100% fases) → missoes_semana (1º envio cmd missoes) → checkin_semanal (1º envio cmd checkin) → revisao_trimestral (3 meses)
// comandos (biblioteca) é desbloqueado pelo mesmo gatilho que checkin_semanal (ver handleCompletePhase)
const PHASE_UNLOCK_ORDER = ["plano_voo", "missoes_semana", "checkin_semanal", "revisao_trimestral"];
// Biblioteca de comandos tem gatilho próprio (1º envio de checkin), não faz parte da cadeia sequencial acima
const BIBLIOTECA_PHASE_ID = "comandos";

/** Retorna a data de desbloqueio da revisão trimestral (3 meses após createdAt) */
function getRevisaoUnlockDate(createdAt: string | Date): Date {
  const d = new Date(createdAt);
  d.setMonth(d.getMonth() + 3);
  return d;
}
/** Verifica se o usuário já completou 3 meses de uso */
function isRevisaoTemporallyUnlocked(createdAt: string | Date): boolean {
  return new Date() >= getRevisaoUnlockDate(createdAt);
}
/** Formata a data de desbloqueio no padrão dd/mm/aa */
function formatUnlockDate(date: Date): string {
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit" });
}

interface NavEntry {
  type: "section" | "item" | "divider" | "duvidas";
  label?: string;
  href?: string;
  Icon?: React.FC<{ className?: string }>;
  phaseId?: string;
  highlight?: boolean;
}

const NAV_STRUCTURE: NavEntry[] = [
  { type: "section", label: "início" },
  { type: "item", href: "/", Icon: Sun, label: "sala de comandos" },
  { type: "duvidas" },
  { type: "section", label: "chat" },
  { type: "item", href: "/chat", Icon: MessageSquare, label: "prysma.ia" },
  { type: "divider" },
  { type: "section", label: "implementação" },
  { type: "item", href: "/plano-de-voo", Icon: Map, label: "plano de vôo" },
  { type: "item", href: "/missoes", Icon: CalendarCheck, label: "missões da semana", phaseId: "missoes_semana" },
  { type: "item", href: "/checkin", Icon: Bell, label: "check-in semanal", phaseId: "checkin_semanal" },
  { type: "item", href: "/revisao", Icon: RotateCcw, label: "revisão trimestral", phaseId: "revisao_trimestral" },
  { type: "divider" },
  { type: "section", label: "biblioteca" },
  { type: "item", href: "/biblioteca", Icon: Terminal, label: "comandos", phaseId: "comandos" },
  { type: "divider" },
  { type: "item", href: "/consultoria", Icon: BookOpen, label: "consultoria humana", highlight: true },
  { type: "item", href: "/perfil", Icon: User, label: "perfil" },
];
// ─── Componente de Item de Nav ────────────────────────────────────────────────────
function NavItem({
  entry, isActive, isLocked, onLockedClick, unlockDate,
}: {
  entry: NavEntry;
  isActive: boolean;
  isLocked: boolean;
  onLockedClick: () => void;
  unlockDate?: string; // data prevista de desbloqueio (apenas para revisao_trimestral)
}) {
  const Icon = entry.Icon!;

  if (isLocked) {
    const isRevisao = entry.phaseId === "revisao_trimestral";
    return (
      <div className="space-y-0.5">
        <button
          onClick={onLockedClick}
          title={isRevisao ? "continue operando o prysma para desbloquear a revisão trimestral e ganhar 30 prysmas" : undefined}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 font-mono text-muted-foreground/40 cursor-not-allowed"
        >
          <Lock className="w-4 h-4 shrink-0 text-muted-foreground/30" />
          <span className="flex-1 text-left">{entry.label}</span>
          <Lock className="w-3 h-3 shrink-0 text-muted-foreground/20" />
        </button>
        {isRevisao && unlockDate && (
          <p className="px-3 text-[10px] text-muted-foreground/40 font-mono">
            :: disponível em {unlockDate}
          </p>
        )}
      </div>
    );
  } if (entry.highlight) {
    return (
      <Link
        href={entry.href!}
        className={cn(
          "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 font-mono",
          isActive
            ? "bg-prysma-faint text-prysma-bright border border-prysma-dim/40"
            : "text-prysma-bright/80 hover:text-prysma-bright hover:bg-prysma-faint/30 border border-prysma-dim/20 hover:border-prysma-dim/40"
        )}
      >
        <Icon className="w-4 h-4 shrink-0" />
        {entry.label}
      </Link>
    );
  }

  return (
    <Link
      href={entry.href!}
      className={cn(
        "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 font-mono",
        isActive
          ? "bg-prysma-faint text-prysma-bright border border-prysma-dim/40 glow-prysma"
          : "text-muted-foreground hover:text-foreground hover:bg-space-surface/60"
      )}
    >
      <Icon className={cn("w-4 h-4 shrink-0", isActive ? "text-prysma-bright" : "text-muted-foreground")} />
      {entry.label}
    </Link>
  );
}

// ─── Sidebar Content (reutilizado em desktop e mobile drawer) ─────────────────
function SidebarContent({
  user,
  firstName,
  avatarUrl,
  prysmasTotal,
  completedPhases,
  location,
  logout,
  onNavClick,
  hideLogo = false,
}: {
  user: any;
  firstName: string;
  avatarUrl: string | null;
  prysmasTotal: number;
  completedPhases: string[];
  location: string;
  logout: () => void;
  onNavClick?: () => void;
  hideLogo?: boolean;
}) {
  const [duvidasOpen, setDuvidasOpen] = useState(false);

  function isItemLocked(entry: NavEntry): boolean {
    if (!entry.phaseId) return false;
    // Biblioteca de comandos: desbloqueada quando checkin_semanal está concluído
    if (entry.phaseId === BIBLIOTECA_PHASE_ID) {
      return !completedPhases.includes("checkin_semanal");
    }
    const phaseIndex = PHASE_UNLOCK_ORDER.indexOf(entry.phaseId);
    if (phaseIndex <= 0) return false;
    // Trava sequencial: a fase anterior precisa estar completa
    const prevPhaseDone = completedPhases.includes(PHASE_UNLOCK_ORDER[phaseIndex - 1]);
    if (!prevPhaseDone) return true;
    // Trava temporal adicional para revisão trimestral
    if (entry.phaseId === "revisao_trimestral" && user?.createdAt) {
      return !isRevisaoTemporallyUnlocked(user.createdAt);
    }
    return false;
  }

  function handleLockedClick(entry: NavEntry) {
    // Biblioteca de comandos: desbloqueada pelo primeiro envio de check-in
    if (entry.phaseId === BIBLIOTECA_PHASE_ID) {
      toast.info(":: conclua seu primeiro check-in semanal para desbloquear a biblioteca de comandos.", { duration: 3000 });
      return;
    }
    if (entry.phaseId === "revisao_trimestral" && user?.createdAt) {
      const unlockDate = formatUnlockDate(getRevisaoUnlockDate(user.createdAt));
      const phaseIndex = PHASE_UNLOCK_ORDER.indexOf(entry.phaseId);
      const prevPhaseDone = completedPhases.includes(PHASE_UNLOCK_ORDER[phaseIndex - 1]);
      if (prevPhaseDone) {
        // Trava é temporal
        toast.info(`continue operando o prysma para desbloquear a revisão trimestral e ganhar 30 prysmas :: disponível em ${unlockDate}`, { duration: 4000 });
        return;
      }
    }
    const phaseIndex = PHASE_UNLOCK_ORDER.indexOf(entry.phaseId!);
    const prevPhase = PHASE_UNLOCK_ORDER[phaseIndex - 1];
    const prevLabel: Record<string, string> = {
      plano_voo: "plano de vôo",
      missoes_semana: "missões da semana",
      checkin_semanal: "check-in semanal",
    };
    toast.info(`:: conclua "${prevLabel[prevPhase] ?? prevPhase}" para desbloquear esta fase.`, { duration: 3000 });
  }

  // Data prevista de desbloqueio da revisão trimestral
  const revisaoUnlockDateStr = user?.createdAt
    ? formatUnlockDate(getRevisaoUnlockDate(user.createdAt))
    : undefined;

  return (
    <div className="flex flex-col h-full">
      {/* Logo + Prysmas — F9: logo clicável | G05: oculto no mobile drawer (header próprio) */}
      {!hideLogo && <div className="flex items-center gap-3 px-5 py-4 border-b border-space-border/30">
        <Link href="/" onClick={onNavClick} className="shrink-0">
          <PrysmaLogo size="md" />
        </Link>
        <div className="flex-1 min-w-0">
          <Link href="/" onClick={onNavClick}>
            <span className="font-semibold text-foreground tracking-wide font-mono hover:text-prysma-bright transition-colors">prysma_</span>
          </Link>
          <p className="text-xs text-muted-foreground font-mono">
            :: {user?.plan ?? "essencial"}
          </p>
        </div>
        {/* F12: Tooltip no contador de Prysmas — G01: tooltip abaixo para não cortar */}
        <div className="relative group flex items-center gap-1 px-2 py-1 rounded-lg bg-prysma-faint/40 border border-prysma-dim/30 cursor-default">
          <span className="text-prysma-bright text-xs">❆</span>
          <span className="text-prysma-bright text-xs font-semibold font-mono">{prysmasTotal}</span>
          {/* G01: Tooltip aparece ABAIXO do ícone */}
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-2.5 py-1.5 rounded-lg bg-space-deep border border-space-border/50 text-[10px] text-muted-foreground font-mono whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
            {prysmasTotal === 0 ? "nenhum prysma acumulado ainda" : `você já acumulou ${prysmasTotal} prysmas`}
          </div>
        </div>
      </div>}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {NAV_STRUCTURE.map((entry, idx) => {
          if (entry.type === "divider") {
            return <div key={idx} className="my-2 border-t border-space-border/20" />;
          }
          if (entry.type === "section") {
            return (
              <p key={idx} className="px-3 pt-3 pb-1 text-[10px] font-semibold text-muted-foreground/50 uppercase tracking-widest font-mono">
                :: {entry.label}
              </p>
            );
          }
          if (entry.type === "duvidas") {
            return (
              <div key={idx} className="mt-0.5">
                <Link
                  href="/chat?cmd=como+come%C3%A7ar+no+prysma"
                  onClick={onNavClick}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 font-mono text-muted-foreground hover:text-foreground hover:bg-space-surface/60"
                >
                  <HelpCircle className="w-4 h-4 shrink-0 text-muted-foreground" />
                  <span className="flex-1 text-left">dúvidas</span>
                </Link>
              </div>
            );
          }
          const isActive = location === entry.href || (entry.href !== "/" && location.startsWith(entry.href!));
          const locked = isItemLocked(entry);
          return (
            <div key={entry.href} onClick={locked ? undefined : onNavClick}>
              <NavItem
                entry={entry}
                isActive={isActive}
                isLocked={locked}
                onLockedClick={() => handleLockedClick(entry)}
                unlockDate={entry.phaseId === "revisao_trimestral" ? revisaoUnlockDateStr : undefined}
              />
            </div>
          );
        })}
      </nav>

      {/* G02: Barra de evolução da implementação — desafixada, acompanha scroll */}
      <div className="px-4 py-3 border-t border-space-border/20">
        <div className="flex items-center justify-between mb-1.5">
          <p className="text-[10px] text-muted-foreground/60 font-mono uppercase tracking-wider">:: implementação</p>
          <p className="text-[10px] text-prysma-bright/70 font-mono">
            {completedPhases.length}/{PHASE_UNLOCK_ORDER.length}
          </p>
        </div>
        <div className="w-full h-1 bg-space-mid/40 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-prysma-core to-prysma-bright rounded-full transition-all duration-500"
            style={{ width: `${(completedPhases.length / PHASE_UNLOCK_ORDER.length) * 100}%` }}
          />
        </div>
        {prysmasTotal > 0 && (
          <p className="text-[10px] text-prysma-bright/50 font-mono mt-1.5">✦ {prysmasTotal} prysmas acumulados</p>
        )}
      </div>

      {/* Crystal Energy */}
      <div className="px-4 py-3 border-t border-space-border/30">
        <CrystalEnergy />
      </div>

      {/* User footer */}
      <div className="px-3 py-3 border-t border-space-border/30">
        <div className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-space-surface/40 transition-colors">
          <div className="w-8 h-8 rounded-full bg-prysma-faint border border-prysma-dim/40 flex items-center justify-center shrink-0 overflow-hidden">
            {avatarUrl ? (
              <img src={avatarUrl} alt="avatar" className="w-full h-full object-cover" />
            ) : (
              <span className="text-xs font-semibold text-prysma-bright">
                {user?.name?.charAt(0)?.toUpperCase() ?? "P"}
              </span>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground truncate lowercase">{firstName}</p>
            <p className="text-xs text-muted-foreground truncate">{user?.email ?? ""}</p>
          </div>
          <button
            onClick={() => logout()}
            className="text-muted-foreground hover:text-foreground transition-colors p-1 rounded"
            title="sair"
          >
            <LogOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Layout Principal ─────────────────────────────────────────────────────────
interface PrysmaLayoutProps {
  children: React.ReactNode;
}

export function PrysmaLayout({ children }: PrysmaLayoutProps) {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: progress } = trpc.progress.get.useQuery(undefined, { enabled: isAuthenticated });

  if (loading) {
    return (
      <div className="min-h-screen nebula-bg flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <PrysmaLogo size="lg" animated />
          <p className="text-muted-foreground text-sm animate-pulse font-mono">calibrando o navegador...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen nebula-bg flex items-center justify-center px-4">
        <div className="max-w-sm w-full text-center space-y-8">
          <div className="space-y-3">
            <PrysmaLogo size="xl" animated />
            <h1 className="text-2xl font-semibold tracking-tight text-foreground font-mono">
              {'}'}_&nbsp;olá, comandante
            </h1>
            <p className="text-muted-foreground text-sm leading-relaxed font-mono">
              prysma_ :: gestão de energia criativa. acesse sua sala de comandos.
            </p>
          </div>
          <a
            href={getLoginUrl()}
            className="flex w-full items-center justify-center px-6 py-3 rounded-xl bg-prysma-core hover:bg-prysma-bright text-space-void font-semibold text-sm transition-colors glow-prysma font-mono"
          >
            :: entrar no sistema
          </a>
          <p className="text-xs text-muted-foreground font-mono">
            metodologia prysma_ :: gestão de energia criativa
          </p>
        </div>
      </div>
    );
  }

  const firstName = user?.name?.split(" ")[0]?.toLowerCase() ?? "comandante";
  const avatarUrl = (user as any)?.avatarUrl ?? null;
  const completedPhases: string[] = (progress?.completedPhases as string[]) ?? [];
  const prysmasTotal = progress?.prysmasEarned ?? 0;

  const sidebarProps = {
    user,
    firstName,
    avatarUrl,
    prysmasTotal,
    completedPhases,
    location,
    logout,
  };

  return (
    <div className="min-h-screen nebula-bg flex">
      {/* ─── Sidebar Desktop ──────────────────────────────────────────────── */}
      <aside className="hidden md:flex w-64 flex-col fixed inset-y-0 left-0 z-50 border-r border-space-border/50 bg-space-deep/90 backdrop-blur-sm">
        <SidebarContent {...sidebarProps} />
      </aside>

      {/* ─── Mobile Drawer Overlay ────────────────────────────────────────── */}
      {mobileMenuOpen && (
        <div
          className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* ─── Mobile Drawer Sidebar ────────────────────────────────────────── */}
      <aside
        className={cn(
          "md:hidden fixed inset-y-0 left-0 z-50 w-72 bg-space-deep/98 border-r border-space-border/50 backdrop-blur-sm transition-transform duration-300 flex flex-col",
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* G03/G05: Header mobile do drawer — logo à esquerda, X à direita, sem sobreposição */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-space-border/30 shrink-0">
          <Link href="/" onClick={() => setMobileMenuOpen(false)} className="flex items-center gap-2">
            <PrysmaLogo size="sm" />
            <span className="font-semibold text-foreground tracking-wide font-mono text-sm">prysma_</span>
          </Link>
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-space-surface/40 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        {/* SidebarContent sem o header de logo (já está acima) */}
        <div className="flex-1 overflow-y-auto">
          <SidebarContent {...sidebarProps} onNavClick={() => setMobileMenuOpen(false)} hideLogo />
        </div>
      </aside>

      {/* ─── Main Content ─────────────────────────────────────────────────── */}
      <main className="flex-1 md:ml-64 min-h-screen pb-4 md:pb-0">
        {/* ─── Mobile Header ────────────────────────────────────────────── */}
        {/* F3: hambúrguer esquerda | F1: prysmas + energia alinhados à direita | F4: saudação na mesma linha */}
        <header className="md:hidden sticky top-0 z-40 bg-space-deep/90 backdrop-blur-sm border-b border-space-border/30 px-4 py-3">
          {/* Linha 1: hambúrguer + prysmas + energia */}
          <div className="flex items-center justify-between">
            {/* Esquerda: hambúrguer */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-space-surface/40 transition-colors"
              aria-label="abrir menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Direita: prysmas + energia — F1: harmonia visual */}
            <div className="flex items-center gap-2">
              {/* Contador de Prysmas — sempre visível */}
              <div
                className="relative group flex items-center gap-1 px-2 py-1 rounded-lg bg-prysma-faint/40 border border-prysma-dim/30 cursor-default"
                title={prysmasTotal === 0 ? "nenhum prysma acumulado ainda" : `você já acumulou ${prysmasTotal} prysmas`}
              >
                <span className="text-prysma-bright text-[10px]">✶</span>
                <span className="text-prysma-bright text-[10px] font-semibold font-mono">{prysmasTotal}</span>
                {/* Tooltip mobile */}
                <div className="absolute bottom-full right-0 mb-2 px-2.5 py-1.5 rounded-lg bg-space-deep border border-space-border/50 text-[10px] text-muted-foreground font-mono whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
                  {prysmasTotal === 0 ? "nenhum prysma acumulado ainda" : `você já acumulou ${prysmasTotal} prysmas`}
                </div>
              </div>
              {/* Cristais de Energia compacto — F2: Battery icon está no CrystalEnergy */}
              <CrystalEnergy compact />
            </div>
          </div>

        </header>

        <div className="h-full">{children}</div>
        {/* Botão flutuante 2º Cérebro */}
        <BrainFloating />
      </main>
    </div>
  );
}
