import { useLocation } from "wouter";

// ─── Componente Principal ─────────────────────────────────────────────────────
export function BrainFloating() {
  const [location, navigate] = useLocation();
  const isOnCerebro = location === "/cerebro";

  return (
    <div className="fixed bottom-6 right-6 z-40 group">
      <button
        onClick={() => navigate(isOnCerebro ? "/" : "/cerebro")}
        className="w-14 h-14 rounded-full flex items-center justify-center text-2xl bg-[oklch(0.62_0.28_330)] hover:bg-[oklch(0.68_0.28_330)] shadow-lg shadow-[oklch(0.62_0.28_330)]/30 transition-all duration-200 hover:scale-110 active:scale-95"
        aria-label={isOnCerebro ? "voltar à sala de comandos" : "2º cérebro"}
      >
        {isOnCerebro ? "⬅" : "🧠"}
      </button>
      <div className="absolute bottom-full right-0 mb-2 px-2.5 py-1.5 rounded-lg bg-space-deep border border-space-border/50 text-[10px] text-muted-foreground font-mono whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        {isOnCerebro ? "sala de comandos" : "2º cérebro"}
      </div>
    </div>
  );
}
