import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  ChevronDown,
  ChevronRight,
  CheckCircle2,
  Lock,
  Play,
  Star,
  Map,
  Compass,
  Rocket,
  Target,
  Zap,
  BookOpen,
  Brain,
  Layers,
  Globe,
  Flame,
  Award,
  Sparkles,
  ExternalLink,
  Pencil,
  Eye,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { UnlockPopup } from "@/components/UnlockPopup";

// Mapeia o índice da fase (sortOrder) para o slug da sidebar
// A primeira fase criada pelo admin = plano_voo, segunda = missoes_semana, etc.
const PHASE_SLUGS = ["plano_voo", "missoes_semana", "checkin_semanal", "comandos", "revisao_trimestral"] as const;
const NEXT_PHASE_LABELS: Record<string, string> = {
  missoes_semana:     "missões da semana desbloqueadas! ✨",
  checkin_semanal:    "check-in semanal desbloqueado! ✨",
  comandos:           "biblioteca de comandos desbloqueada! ✨",
  revisao_trimestral: "revisão trimestral desbloqueada! ✨",
};

// Mapa de ícones disponíveis
const ICON_MAP: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Map, Compass, Rocket, Target, Zap, BookOpen, Brain, Layers, Globe, Flame, Award, Sparkles,
};

function PhaseIcon({ name, size = 20, className = "" }: { name: string; size?: number; className?: string }) {
  const Icon = ICON_MAP[name] ?? Map;
  return <Icon size={size} className={className} />;
}

function getYouTubeId(url: string): string | null {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/);
  return match?.[1] ?? null;
}

function VideoEmbed({ url }: { url: string }) {
  const ytId = getYouTubeId(url);
  if (ytId) {
    return (
      <div className="relative w-full aspect-video rounded-lg overflow-hidden bg-space-dark">
        <iframe
          src={`https://www.youtube.com/embed/${ytId}`}
          title="Vídeo da fase"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="absolute inset-0 w-full h-full"
        />
      </div>
    );
  }
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center gap-2 text-pink-400 hover:text-pink-300 text-sm"
    >
      <ExternalLink size={14} />
      assistir vídeo
    </a>
  );
}

// ─── Componente de Detalhe da Fase ────────────────────────────────────────────
function PhaseDetail({
  phase,
  phaseIdx,
  done,
  progress,
  expandedSubphases,
  completingId,
  onToggleSubphase,
  onCompleteSubphase,
  onCompletePhase,
  onChat,
}: {
  phase: { id: number; title: string; description?: string | null; icon: string };
  phaseIdx: number;
  done: boolean;
  progress: { phaseId: number; subphaseId?: number | null }[];
  expandedSubphases: Set<number>;
  completingId: string | null;
  onToggleSubphase: (id: number) => void;
  onCompleteSubphase: (phaseId: number, subphaseId: number) => void;
  onCompletePhase: (phaseId: number) => void;
  onChat: () => void;
}) {
  const { data: subphases = [] } = trpc.flight.getSubphases.useQuery({ phaseId: phase.id });
  const [showContent, setShowContent] = useState<Set<number>>(new Set());

  const isSubDone = (subId: number) =>
    progress.some((p) => p.phaseId === phase.id && p.subphaseId === subId);

  const allSubsDone = subphases.length > 0 && subphases.every((s) => isSubDone(s.id));

  return (
    <div className="bg-card border border-border rounded-2xl p-6 mb-6 fade-in-up">
      {/* Cabeçalho da fase */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-pink-500/20 border border-pink-500/30 flex items-center justify-center">
            <PhaseIcon name={phase.icon} size={18} className="text-pink-400" />
          </div>
          <div>
            <div className="text-xs text-muted-foreground font-mono mb-0.5">fase {phaseIdx + 1}</div>
            <h2 className="text-lg font-semibold text-foreground">{phase.title}</h2>
          </div>
        </div>
        {done && (
          <div className="flex items-center gap-1.5 text-pink-400 text-xs font-medium">
            <CheckCircle2 size={14} />
            concluída
          </div>
        )}
      </div>

      {phase.description && (
        <div
          className="text-muted-foreground text-sm mb-5 leading-relaxed prose prose-invert prose-sm max-w-none"
          dangerouslySetInnerHTML={{ __html: phase.description }}
        />
      )}

      {/* Subfases */}
      {subphases.length > 0 && (
        <div className="space-y-3 mb-5">
          {subphases.map((sub) => {
            const subDone = isSubDone(sub.id);
            const expanded = expandedSubphases.has(sub.id);
            const contentExpanded = showContent.has(sub.id);

            return (
              <div
                key={sub.id}
                className={`border rounded-xl overflow-hidden transition-all ${
                  subDone
                    ? "border-pink-500/30 bg-pink-500/5"
                    : "border-border bg-card/60"
                }`}
              >
                <button
                  onClick={() => onToggleSubphase(sub.id)}
                  className="w-full flex items-center justify-between p-3.5 text-left"
                >
                  <div className="flex items-center gap-2.5">
                    {subDone ? (
                      <CheckCircle2 size={16} className="text-pink-400 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-border shrink-0" />
                    )}
                    <span className={`text-sm font-medium ${subDone ? "text-muted-foreground line-through" : "text-foreground"}`}>
                      {sub.title}
                    </span>
                    {!subDone && <span className="text-xs text-muted-foreground/50 font-mono">+1 prysma</span>}
                  </div>
                  {expanded ? (
                    <ChevronDown size={14} className="text-muted-foreground shrink-0" />
                  ) : (
                    <ChevronRight size={14} className="text-muted-foreground shrink-0" />
                  )}
                </button>

                {expanded && (
                  <div className="px-4 pb-4 space-y-3">
                    {sub.videoUrl && <VideoEmbed url={sub.videoUrl} />}

                    {sub.content && (
                      <div>
                        <button
                          onClick={() => setShowContent((prev) => {
                            const next = new Set(prev);
                            next.has(sub.id) ? next.delete(sub.id) : next.add(sub.id);
                            return next;
                          })}
                          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mb-2"
                        >
                          {contentExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                          conteúdo complementar
                        </button>
                        {contentExpanded && (
                          <div
                            className="text-sm text-muted-foreground leading-relaxed prose prose-invert prose-sm max-w-none"
                            dangerouslySetInnerHTML={{ __html: sub.content }}
                          />
                        )}
                      </div>
                    )}

                    {Array.isArray(sub.suggestedCommands) && (sub.suggestedCommands as string[]).length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {(sub.suggestedCommands as string[]).map((cmd, i) => (
                          <button
                            key={i}
                            onClick={() => window.location.href = `/chat?msg=${encodeURIComponent(cmd)}`}
                            className="text-xs px-3 py-1.5 bg-space-mid/40 border border-border text-foreground rounded-lg hover:bg-space-surface/60 transition-colors"
                          >
                            :: {cmd}
                          </button>
                        ))}
                      </div>
                    )}

                    {!subDone && (
                      <button
                        onClick={() => onCompleteSubphase(phase.id, sub.id)}
                        disabled={completingId === `sub-${sub.id}`}
                        className="flex items-center gap-2 text-xs px-3 py-1.5 bg-pink-500/20 border border-pink-500/40 text-pink-400 rounded-lg hover:bg-pink-500/30 transition-colors disabled:opacity-50"
                      >
                        <CheckCircle2 size={12} />
                        {completingId === `sub-${sub.id}` ? "registrando..." : "marcar como concluída"}
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Ações da fase */}
      <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-border">
        <button
          onClick={onChat}
          className="flex items-center gap-2 px-4 py-2 bg-space-mid/40 border border-border text-foreground rounded-xl text-sm hover:bg-space-surface/60 transition-colors"
        >
          <Play size={14} />
          conversar com o navegador
        </button>

        {!done && (subphases.length === 0 || allSubsDone) && (
          <button
            onClick={() => onCompletePhase(phase.id)}
            disabled={completingId === `phase-${phase.id}`}
            className="flex items-center gap-2 px-4 py-2 bg-pink-500 text-white rounded-xl text-sm font-medium hover:bg-pink-400 transition-colors disabled:opacity-50 shadow-lg shadow-pink-500/25"
          >
            <Star size={14} />
            {completingId === `phase-${phase.id}` ? "registrando..." : "concluir fase (+3 prysmas)"}
          </button>
        )}

        {done && (
          <span className="text-xs text-muted-foreground italic">
            fase concluída — você pode rever o conteúdo quando quiser
          </span>
        )}
      </div>
    </div>
  );
}

// ─── Página Principal ─────────────────────────────────────────────────────────
export default function PlanoDeVoo() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const isAdmin = (user as any)?.role === "admin";
  const [adminMode, setAdminMode] = useState(false);
  const [selectedPhaseId, setSelectedPhaseId] = useState<number | null>(null);
  const [expandedSubphases, setExpandedSubphases] = useState<Set<number>>(new Set());
  const [completingId, setCompletingId] = useState<string | null>(null);
  const [unlockedPhaseId, setUnlockedPhaseId] = useState<string | null>(null);

  const { data: phases = [], refetch: refetchPhases } = trpc.flight.getPhases.useQuery();
  const { data: progressData = [], refetch: refetchProgress } = trpc.flight.getProgress.useQuery();

  const unlockMutation = trpc.progress.unlock.useMutation();

  const completeMutation = trpc.flight.complete.useMutation({
    onSuccess: () => {
      refetchPhases();
      refetchProgress();
      setCompletingId(null);
    },
    onError: (err) => {
      toast.error(err.message);
      setCompletingId(null);
    },
  });

  const isPhaseComplete = (phaseId: number) =>
    progressData.some((p) => p.phaseId === phaseId && p.subphaseId == null);

  const isSubphaseComplete = (phaseId: number, subphaseId: number) =>
    progressData.some((p) => p.phaseId === phaseId && p.subphaseId === subphaseId);

  const isPhaseUnlocked = (index: number) => {
    if (index === 0) return true;
    const prevPhase = phases[index - 1];
    return prevPhase ? isPhaseComplete(prevPhase.id) : false;
  };

  const completedPhases = phases.filter((p) => isPhaseComplete(p.id)).length;
  const progressPct = phases.length > 0 ? Math.round((completedPhases / phases.length) * 100) : 0;

  const toggleSubphase = (id: number) => {
    setExpandedSubphases((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handleCompleteSubphase = async (phaseId: number, subphaseId: number) => {
    if (isSubphaseComplete(phaseId, subphaseId)) return;
    setCompletingId(`sub-${subphaseId}`);
    await completeMutation.mutateAsync({ phaseId, subphaseId, prysmas: 1 });
    toast.success("✦ +1 prysma conquistado!");
  };

  const handleCompletePhase = async (phaseId: number) => {
    if (isPhaseComplete(phaseId)) return;
    setCompletingId(`phase-${phaseId}`);
    await completeMutation.mutateAsync({ phaseId, subphaseId: null, prysmas: 3 });
    toast.success("+3 prysmas conquistados! fase concluída.");
    // Verifica se TODAS as fases estão concluídas após esta operação
    // (inclui a fase recém concluída, que ainda não está em progressData)
    const totalPhases = phases.length;
    const alreadyCompleted = phases.filter((p) => p.id !== phaseId && isPhaseComplete(p.id)).length;
    const willBeComplete = alreadyCompleted + 1; // +1 pela fase recém concluída
    const isAllDone = totalPhases > 0 && willBeComplete >= totalPhases;
    if (isAllDone) {
      // Gatilho: 100% do Plano de Voo → desbloqueia missões da semana
      const result = await unlockMutation.mutateAsync({ phaseId: "plano_voo" });
      if (result.nextPhaseId) {
        setTimeout(() => {
          setUnlockedPhaseId(result.nextPhaseId!);
        }, 800);
      }
    }
  };

  if (phases.length === 0) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center">
        <Rocket size={48} className="text-pink-400 mb-4 opacity-60" />
        <h2 className="text-xl font-semibold text-foreground mb-2">plano de vôo vazio</h2>
        <p className="text-muted-foreground text-sm mb-6 max-w-sm">
          Nenhuma fase foi cadastrada ainda. Acesse o painel de administração para criar as fases do seu plano.
        </p>
        <button
          onClick={() => navigate("/admin")}
          className="px-4 py-2 bg-pink-500/20 border border-pink-500/40 text-pink-400 rounded-lg text-sm hover:bg-pink-500/30 transition-colors"
        >
          ir para o painel admin
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Rocket size={24} className="text-pink-400" />
          <h1 className="text-2xl font-bold text-foreground tracking-tight">plano de vôo</h1>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-muted-foreground text-sm">sua jornada de implementação do prysma_</p>
          {isAdmin && (
            <button
              onClick={() => setAdminMode((v) => !v)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono transition-all border ${
                adminMode
                  ? "bg-pink-500/20 border-pink-500/40 text-pink-400 hover:bg-pink-500/30"
                  : "bg-muted/60 border-border/50 text-muted-foreground hover:text-foreground"
              }`}
            >
              {adminMode ? <Eye size={12} /> : <Pencil size={12} />}
              {adminMode ? ":: ver como usuário" : ":: modo edição"}
            </button>
          )}
        </div>
        <div className="mt-4 flex items-center gap-3">
          <div className="flex-1 h-2 bg-space-mid/40 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-pink-500 to-pink-400 rounded-full transition-all duration-700"
              style={{ width: `${progressPct}%` }}
            />
          </div>
          <span className="text-xs text-muted-foreground font-mono whitespace-nowrap">
            {completedPhases}/{phases.length} fases
          </span>
          <span className="text-xs text-pink-400 font-mono">{progressPct}%</span>
        </div>
      </div>

      {/* Painel Admin inline — visível apenas quando adminMode=true */}
      {isAdmin && adminMode && (
        <div className="mb-8 rounded-2xl border border-pink-500/30 bg-pink-500/5 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Pencil size={16} className="text-pink-400" />
              <p className="text-sm font-semibold text-pink-400 font-mono">:: modo edição ativo</p>
            </div>
            <Link
              href="/admin"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-pink-500 text-white hover:bg-pink-400 transition-colors"
            >
              <Pencil size={11} />
              abrir painel admin
            </Link>
          </div>
          <p className="text-xs text-muted-foreground font-mono leading-relaxed">
            :: no painel admin você pode editar títulos, descrições, ícones, subfases, vídeos e botões de cada fase. as alterações são refletidas aqui em tempo real.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {phases.map((phase, idx) => (
              <Link
                key={phase.id}
                href={`/admin#phase-${phase.id}`}
                className="flex items-center gap-2 p-3 rounded-xl border border-pink-500/20 bg-pink-500/5 hover:bg-pink-500/10 hover:border-pink-500/40 transition-all text-sm font-mono text-muted-foreground hover:text-foreground"
              >
                <PhaseIcon name={phase.icon} size={14} className="text-pink-400 shrink-0" />
                <span className="truncate">fase {idx + 1} :: {phase.title.toLowerCase()}</span>
                <ExternalLink size={11} className="text-pink-400 ml-auto shrink-0" />
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Botões de fase + detalhe inline logo abaixo do botão clicado */}
      <div className="flex flex-col gap-2 mb-8">
        {phases.map((phase, idx) => {
          const unlocked = isPhaseUnlocked(idx);
          const done = isPhaseComplete(phase.id);
          const selected = selectedPhaseId === phase.id;
          return (
            <div key={phase.id} className="flex flex-col gap-2">
              <button
                onClick={() => unlocked && setSelectedPhaseId(selected ? null : phase.id)}
                disabled={!unlocked}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all border ${
                  done
                    ? "bg-pink-500/30 border-pink-500/50 text-pink-300"
                    : selected
                    ? "bg-pink-500 border-pink-400 text-white shadow-lg shadow-pink-500/25"
                    : unlocked
                    ? "bg-pink-500/15 border-pink-500/30 text-pink-400 hover:bg-pink-500/25"
                    : "bg-space-mid/30 border-space-border/40 text-muted-foreground/40 cursor-not-allowed"
                }`}
              >
                <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 bg-pink-500/20">
                  {done ? (
                    <CheckCircle2 size={14} className="text-pink-300" />
                  ) : !unlocked ? (
                    <Lock size={14} />
                  ) : (
                    <PhaseIcon name={phase.icon} size={14} />
                  )}
                </div>
                <div className="flex-1 text-left">
                  <span className="font-mono">{phase.title || `fase ${idx + 1}`}</span>
                </div>
                {done && <Star size={12} className="text-pink-300 shrink-0" />}
                {selected && !done && <ChevronDown size={14} className="shrink-0" />}
                {!selected && unlocked && !done && <ChevronRight size={14} className="shrink-0" />}
              </button>
              {/* Detalhe da fase — expande logo abaixo do botão clicado */}
              {selected && (
                <PhaseDetail
                  phase={phase}
                  phaseIdx={idx}
                  done={done}
                  progress={progressData}
                  expandedSubphases={expandedSubphases}
                  completingId={completingId}
                  onToggleSubphase={toggleSubphase}
                  onCompleteSubphase={handleCompleteSubphase}
                  onCompletePhase={handleCompletePhase}
                  onChat={() => navigate(`/chat?protocol=plano_de_voo&phase=${phase.id}`)}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Popup de desbloqueio com identidade Prysma */}
      <UnlockPopup
        unlockedPhaseId={unlockedPhaseId}
        onClose={() => setUnlockedPhaseId(null)}
      />
    </div>
  );
}
