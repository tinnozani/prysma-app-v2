import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { ArrowLeft, Edit3, Lock, Compass, Target, Eye, Zap, FolderOpen, Battery } from "lucide-react";
import { Link, useLocation } from "wouter";
import { trpc as trpcClient } from "@/lib/trpc";

// ─── Bloco de seção da carta ──────────────────────────────────────────────────
function CartaSection({
  icon: Icon,
  label,
  value,
  color = "prysma",
  multiline = false,
}: {
  icon: React.FC<{ className?: string }>;
  label: string;
  value?: string | null;
  color?: "prysma" | "sonnet" | "haiku";
  multiline?: boolean;
}) {
  const colorMap = {
    prysma: { border: "border-prysma-dim/30", bg: "bg-prysma-faint/10", icon: "text-prysma-bright", label: "text-prysma-bright/70" },
    sonnet: { border: "border-sonnet-glow/30", bg: "bg-sonnet-faint/10", icon: "text-sonnet-bright", label: "text-sonnet-bright/70" },
    haiku:  { border: "border-haiku-glow/30",  bg: "bg-haiku-faint/10",  icon: "text-haiku-bright",  label: "text-haiku-bright/70" },
  };
  const c = colorMap[color];

  return (
    <div className={cn("rounded-2xl border p-5 space-y-3", c.border, c.bg)}>
      <div className="flex items-center gap-2">
        <Icon className={cn("w-4 h-4 shrink-0", c.icon)} />
        <p className={cn("text-[10px] font-semibold uppercase tracking-widest font-mono", c.label)}>{label}</p>
      </div>
      {value ? (
        <p className={cn("text-sm text-foreground leading-relaxed", multiline && "whitespace-pre-wrap")}>{value}</p>
      ) : (
        <p className="text-sm text-muted-foreground/40 italic font-mono">:: não preenchido</p>
      )}
    </div>
  );
}

// ─── Tag de projeto ───────────────────────────────────────────────────────────
function ProjetoTag({ nome, color }: { nome: string; color: string }) {
  return (
    <span className={cn(
      "inline-flex items-center px-3 py-1 rounded-full text-xs font-mono border",
      color
    )}>
      {nome}
    </span>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────────
export default function CartaDeNavegacao() {
  const { data: carta, isLoading } = trpc.carta.get.useQuery();
  const { data: progress } = trpc.progress.get.useQuery();
  const [, navigate] = useLocation();

  const completedPhases: string[] = (progress?.completedPhases as string[]) ?? [];
  // Carta só pode ser refeita após toda a biblioteca ser desbloqueada
  const podeEditar = completedPhases.includes("comandos");

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <p className="text-muted-foreground font-mono text-sm animate-pulse">carregando carta...</p>
      </div>
    );
  }

  if (!carta) {
    return (
      <div className="min-h-screen p-4 md:p-8 space-y-8 fade-in-up">
        <div className="flex items-center gap-3">
          <Link href="/" className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-space-surface/40 transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <p className="text-[10px] text-muted-foreground/60 font-mono">:: documento</p>
            <h1 className="text-xl font-semibold font-mono text-foreground">carta de navegação</h1>
          </div>
        </div>

        <div className="rounded-2xl border border-prysma-dim/40 bg-prysma-faint/10 p-8 text-center space-y-4">
          <Compass className="w-10 h-10 text-prysma-bright/40 mx-auto" />
          <div className="space-y-2">
            <h2 className="text-base font-semibold font-mono text-foreground">carta não preenchida</h2>
            <p className="text-sm text-muted-foreground font-mono leading-relaxed max-w-sm mx-auto">
              :: o navegador ainda não conhece seu território. inicie a carta de navegação para ativar todos os widgets da sala de comandos.
            </p>
          </div>
          <Link
            href="/chat?protocol=carta"
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-prysma-core hover:bg-prysma-bright text-space-void font-semibold text-sm font-mono transition-colors"
          >
            :: iniciar carta de navegação
          </Link>
        </div>
      </div>
    );
  }

  // Parse de projetos (armazenados como JSON string ou array)
  let projetos: string[] = [];
  try {
    const raw = (carta as any).projetos;
    if (typeof raw === "string") projetos = JSON.parse(raw);
    else if (Array.isArray(raw)) projetos = raw;
  } catch { projetos = []; }

  return (
    <div className="min-h-screen p-4 md:p-8 space-y-8 fade-in-up max-w-2xl mx-auto">
      {/* ─── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Link href="/" className="p-2 rounded-xl text-muted-foreground hover:text-foreground hover:bg-space-surface/40 transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <p className="text-[10px] text-muted-foreground/60 font-mono">:: documento</p>
            <h1 className="text-xl font-semibold font-mono text-foreground">carta de navegação</h1>
          </div>
        </div>

        {/* Botão editar — travado até biblioteca ser desbloqueada */}
        {podeEditar ? (
          <Link
            href="/chat?protocol=carta"
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-prysma-dim/40 bg-prysma-faint/20 hover:bg-prysma-faint/40 text-prysma-bright text-sm font-mono transition-colors"
          >
            <Edit3 className="w-3.5 h-3.5" />
            editar
          </Link>
        ) : (
          <div
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-space-border/20 bg-space-mid/20 text-muted-foreground/40 text-sm font-mono cursor-not-allowed"
            title="disponível após concluir toda a jornada de implementação"
          >
            <Lock className="w-3.5 h-3.5" />
            editar
          </div>
        )}
      </div>

      {/* ─── Tríade Central ─────────────────────────────────────────────────── */}
      <div className="space-y-3">
        <p className="text-[10px] text-muted-foreground/60 font-mono uppercase tracking-widest px-1">:: tríade central</p>
        <div className="space-y-3">
          <CartaSection
            icon={Compass}
            label="quem sou"
            value={(carta as any).identidade}
            color="prysma"
          />
          <CartaSection
            icon={Target}
            label="missão de vida"
            value={(carta as any).missaoVida}
            color="sonnet"
            multiline
          />
          <CartaSection
            icon={Eye}
            label="visão de futuro"
            value={(carta as any).visaoFuturo}
            color="haiku"
            multiline
          />
        </div>
      </div>

      {/* ─── TUD ────────────────────────────────────────────────────────────── */}
      <div className="space-y-3">
        <p className="text-[10px] text-muted-foreground/60 font-mono uppercase tracking-widest px-1">:: tempo útil disponível</p>
        <div className="rounded-2xl border border-haiku-glow/20 bg-haiku-faint/10 p-5 space-y-3">
          <div className="flex items-center gap-2">
            <Battery className="w-4 h-4 text-haiku-bright shrink-0" />
            <p className="text-[10px] font-semibold uppercase tracking-widest font-mono text-haiku-bright/70">energia disponível</p>
          </div>
          {(carta as any).tudHorasSemana ? (
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground font-mono">{(carta as any).tudHorasSemana}h</span>
              <span className="text-xs text-muted-foreground font-mono">por semana</span>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground/40 italic font-mono">:: não preenchido</p>
          )}
          {(carta as any).nivelEnergia && (
            <p className="text-xs text-muted-foreground font-mono">
              nível de energia :: <span className="text-foreground">{(carta as any).nivelEnergia}</span>
            </p>
          )}
        </div>
      </div>

      {/* ─── Projetos ───────────────────────────────────────────────────────── */}
      {projetos.length > 0 && (
        <div className="space-y-3">
          <p className="text-[10px] text-muted-foreground/60 font-mono uppercase tracking-widest px-1">:: projetos ativos</p>
          <div className="rounded-2xl border border-space-border/30 bg-space-dark/40 p-5 space-y-3">
            <div className="flex items-center gap-2">
              <FolderOpen className="w-4 h-4 text-muted-foreground shrink-0" />
              <p className="text-[10px] font-semibold uppercase tracking-widest font-mono text-muted-foreground/70">rota de projetos</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {projetos.map((p, i) => (
                <ProjetoTag
                  key={i}
                  nome={p}
                  color={
                    i % 3 === 0
                      ? "border-prysma-dim/40 bg-prysma-faint/20 text-prysma-bright"
                      : i % 3 === 1
                      ? "border-sonnet-glow/40 bg-sonnet-faint/20 text-sonnet-bright"
                      : "border-haiku-glow/40 bg-haiku-faint/20 text-haiku-bright"
                  }
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ─── Nota de rodapé ─────────────────────────────────────────────────── */}
      {!podeEditar && (
        <div className="rounded-xl border border-space-border/20 bg-space-mid/20 p-4 flex items-start gap-3">
          <Lock className="w-4 h-4 text-muted-foreground/40 shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground/60 font-mono leading-relaxed">
            :: a carta de navegação pode ser refeita após concluir toda a jornada de implementação. isso garante que o mapeamento reflita um território mais maduro.
          </p>
        </div>
      )}
    </div>
  );
}
