import { MessageCircle, Star, Zap, Compass, ArrowRight } from "lucide-react";

const WHATSAPP_NUMBER = "5511996914143";
const WHATSAPP_MESSAGE = encodeURIComponent(
  "Olá, Tinno! Vim pelo prysma_ e gostaria de conversar sobre consultoria humana."
);
const WHATSAPP_URL = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

const BENEFITS = [
  {
    Icon: Compass,
    title: "diagnóstico personalizado",
    desc: "Uma sessão de imersão para mapear seu território criativo com precisão cirúrgica.",
  },
  {
    Icon: Zap,
    title: "desbloqueio de rota",
    desc: "Identificar onde a energia vaza e o que precisa ser reconfigurado no sistema.",
  },
  {
    Icon: Star,
    title: "co-criação estratégica",
    desc: "Construir junto o plano de voo para o próximo ciclo com clareza e intenção.",
  },
];

export default function Consultoria() {
  return (
    <div className="min-h-screen px-4 md:px-8 py-8 max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-10">
        <p className="text-xs text-muted-foreground/60 font-mono mb-1">:: suporte humano</p>
        <h1 className="text-2xl font-bold font-mono text-foreground mb-2">consultoria humana</h1>
        <p className="text-sm text-muted-foreground font-mono leading-relaxed">
          {'}'}_&nbsp;quando o navegador não é suficiente, o criador entra em cena.
        </p>
      </div>

      {/* Card principal */}
      <div className="rounded-2xl border border-prysma-dim/40 bg-space-surface/30 overflow-hidden mb-6">
        {/* Faixa de destaque */}
        <div className="px-5 py-4 bg-gradient-to-r from-prysma-faint/30 to-transparent border-b border-prysma-dim/20">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-prysma-faint/40 border border-prysma-dim/50 flex items-center justify-center shrink-0">
              <span className="text-lg font-bold text-prysma-bright">T</span>
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground font-mono">Tinno Zani</p>
              <p className="text-xs text-muted-foreground/70 font-mono">
                criador do prysma_ :: estrategista criativo
              </p>
            </div>
          </div>
        </div>

        {/* Descrição */}
        <div className="px-5 py-5 space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed font-mono">
            O prysma_ nasceu da minha própria necessidade de organizar a criatividade sem matar a alma do processo.
            Se você chegou até aqui, é porque o sistema ressoou com algo real em você.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed font-mono">
            A consultoria humana é para quando você precisa de mais do que um agente de IA —
            precisa de um olhar humano, estratégico e empático sobre o seu território.
          </p>
        </div>
      </div>

      {/* Benefícios */}
      <div className="space-y-3 mb-8">
        {BENEFITS.map(({ Icon, title, desc }) => (
          <div
            key={title}
            className="flex items-start gap-4 p-4 rounded-xl border border-space-border/20 bg-space-surface/20"
          >
            <div className="w-8 h-8 rounded-lg bg-prysma-faint/30 border border-prysma-dim/30 flex items-center justify-center shrink-0">
              <Icon className="w-4 h-4 text-prysma-bright/70" />
            </div>
            <div>
              <p className="text-sm font-semibold font-mono text-foreground mb-0.5">{title}</p>
              <p className="text-xs text-muted-foreground/70 leading-relaxed">{desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* CTA WhatsApp */}
      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl font-semibold text-sm font-mono transition-all duration-200 bg-[oklch(0.55_0.18_142)] hover:bg-[oklch(0.60_0.20_142)] text-white shadow-lg shadow-[oklch(0.55_0.18_142)]/20 hover:shadow-[oklch(0.55_0.18_142)]/30 hover:scale-[1.01] active:scale-[0.99]"
      >
        <MessageCircle className="w-5 h-5" />
        :: conversar no whatsapp
        <ArrowRight className="w-4 h-4" />
      </a>

      <p className="text-center text-xs text-muted-foreground/40 font-mono mt-4">
        você será direcionado ao WhatsApp do Tinno Zani
      </p>
    </div>
  );
}
