import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Archive, ChevronUp, MessageSquare, Plus, Send } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { Streamdown } from "streamdown";
import { UnlockPopup } from "@/components/UnlockPopup";

// Tipos locais para mensagens no estado
type LocalMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  model?: "sonnet" | "haiku";
  pending?: boolean;
};

export default function Chat() {
  const [, params] = useLocation();
  const urlParams = new URLSearchParams(window.location.search);
  const protocolFromUrl = urlParams.get("protocol");
  const cmdFromUrl = urlParams.get("cmd");

  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  const [localMessages, setLocalMessages] = useState<LocalMessage[]>([]);
  const [input, setInput] = useState(cmdFromUrl ? `// ${cmdFromUrl}` : "");
  const [currentModel, setCurrentModel] = useState<"sonnet" | "haiku">("haiku");
  const [chatUnlockedPhaseId, setChatUnlockedPhaseId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const utils = trpc.useUtils();

  const { data: activeSessions, isLoading } = trpc.sessions.list.useQuery({ status: "active" });

  const createSession = trpc.sessions.create.useMutation({
    onSuccess: (session) => {
      setActiveSessionId(session.id);
      setLocalMessages([]);
      utils.sessions.list.invalidate();
    },
    onError: () => toast.error("não foi possível criar a sessão."),
  });

  const archiveSession = trpc.sessions.archive.useMutation({
    onSuccess: () => {
      setActiveSessionId(null);
      setLocalMessages([]);
      utils.sessions.list.invalidate();
      toast.success("sessão arquivada.");
    },
  });

  const saveMessage = trpc.sessions.addMessage.useMutation();

  const aiChat = trpc.ai.chat.useMutation({
    onSuccess: (data) => {
      // Exibir popup de desbloqueio se o gatilho foi ativado
      if (data.unlockedPhaseId) {
        setTimeout(() => setChatUnlockedPhaseId(data.unlockedPhaseId!), 800);
        utils.progress.get.invalidate();
      }
      const assistantMsg: LocalMessage = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: data.content,
        model: currentModel,
      };
      setLocalMessages((prev) => {
        // Remove pending
        const withoutPending = prev.filter((m) => !m.pending);
        return [...withoutPending, assistantMsg];
      });
      // Salvar no banco
      if (activeSessionId) {
        saveMessage.mutate({
          sessionId: activeSessionId,
          role: "assistant",
          content: data.content,
          model: currentModel,
        });
      }
    },
    onError: (err) => {
      setLocalMessages((prev) => prev.filter((m) => !m.pending));
      toast.error(err.message ?? ":: erro ao contactar o navegador.");
    },
  });

  // Carregar mensagens existentes ao selecionar sessão
  const { data: dbMessages } = trpc.sessions.getMessages.useQuery(
    { sessionId: activeSessionId! },
    { enabled: !!activeSessionId }
  );

  useEffect(() => {
    if (dbMessages && activeSessionId) {
      const mapped: LocalMessage[] = (dbMessages as any[])
        .filter((m: any) => m.role !== "system")
        .map((m: any) => ({
          id: String(m.id),
          role: m.role as "user" | "assistant",
          content: m.content,
          model: m.model ?? undefined,
        }));
      setLocalMessages(mapped);
    }
  }, [dbMessages, activeSessionId]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [localMessages]);

  // Auto-criar sessão se vier de um protocolo
  useEffect(() => {
    if (protocolFromUrl && !activeSessionId) {
      const protocolNames: Record<string, string> = {
        carta: "carta de navegação",
        "08": "órbita semanal",
        "01": "mapeamento",
        "02": "sinastria projeto",
        "03": "sinastria vida",
        "04": "lançamento",
        "05": "atualização",
        "06": "captura",
        "07": "revisão semanal",
        "09": "revisão trimestral",
        "10": "modo expansão",
        "11": "input livre",
      };
      const model = ["carta", "02", "03", "09", "10"].includes(protocolFromUrl) ? "sonnet" : "haiku";
      setCurrentModel(model);
      createSession.mutate({
        protocolId: protocolFromUrl,
        protocolName: protocolNames[protocolFromUrl] ?? protocolFromUrl,
        model,
      });
    }
  }, [protocolFromUrl]);

  function handleSend() {
    const text = input.trim();
    if (!text || aiChat.isPending) return;
    if (!activeSessionId) {
      toast.error(":: inicie uma sessão primeiro.");
      return;
    }

    const userMsg: LocalMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      content: text,
    };
    const pendingMsg: LocalMessage = {
      id: `pending-${Date.now()}`,
      role: "assistant",
      content: "",
      pending: true,
    };

    setLocalMessages((prev) => [...prev, userMsg, pendingMsg]);
    setInput("");

    // Salvar mensagem do usuário no banco
    saveMessage.mutate({
      sessionId: activeSessionId,
      role: "user",
      content: text,
    });

    // Enviar para IA
    const history = localMessages
      .filter((m) => !m.pending)
      .map((m) => ({ role: m.role, content: m.content }));

    aiChat.mutate({
      messages: [...history, { role: "user", content: text }],
      protocolId: protocolFromUrl ?? undefined,
      sessionId: activeSessionId,
      model: currentModel,
    });
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  function handleUpgradeModel() {
    if (currentModel === "haiku") {
      setCurrentModel("sonnet");
      toast.success(":: modo expansão ativado.");
    } else {
      setCurrentModel("haiku");
      toast.success(":: modo foco ativado.");
    }
  }

  const activeSession = (activeSessions as any[] | undefined)?.find(
    (s: any) => s.id === activeSessionId
  );

  return (
    <div className="flex h-[calc(100vh-4rem)] md:h-screen">
      {/* Sessions sidebar */}
      <aside className="w-64 hidden lg:flex flex-col border-r border-space-border/40 bg-space-deep/50">
        <div className="p-4 border-b border-space-border/30 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_&nbsp;sessões ::</h2>
          <button
            className="w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-prysma-bright hover:bg-prysma-faint/30 transition-colors"
            onClick={() => createSession.mutate({ model: "haiku" })}
            disabled={createSession.isPending}
            title="nova sessão"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {isLoading && (
            <div className="space-y-2 p-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-12 rounded-lg bg-space-mid animate-pulse" />
              ))}
            </div>
          )}
          {(activeSessions as any[] | undefined)?.map((session: any) => (
            <button
              key={session.id}
              onClick={() => {
                setActiveSessionId(session.id);
                setLocalMessages([]);
              }}
              className={cn(
                "w-full text-left flex items-start gap-2.5 p-3 rounded-xl transition-all",
                activeSessionId === session.id
                  ? "bg-prysma-faint/40 border border-prysma-dim/30"
                  : "hover:bg-space-surface/40 border border-transparent"
              )}
            >
              <div className={cn(
                "w-2 h-2 rounded-full mt-1.5 shrink-0",
                session.model === "sonnet" ? "bg-sonnet-core" : "bg-haiku-core"
              )} />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground truncate font-mono lowercase">
                  {session.title ?? session.protocolName ?? "nova sessão"}
                </p>
                <p className="text-xs text-muted-foreground font-mono">
                  {new Date(session.createdAt).toLocaleDateString("pt-BR")}
                </p>
              </div>
            </button>
          ))}
          {!isLoading && (activeSessions as any[] | undefined)?.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-8 font-mono">
              nenhuma sessão ativa
            </p>
          )}
        </div>
      </aside>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {activeSessionId ? (
          <>
            {/* Chat header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-space-border/30 bg-space-deep/50 shrink-0">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-prysma-bright" />
                <span className="text-sm font-medium text-foreground font-mono lowercase truncate max-w-[200px]">
                  {activeSession?.title ?? activeSession?.protocolName ?? "sessão ativa"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {/* Model toggle */}
                <button
                  onClick={handleUpgradeModel}
                  className={cn(
                    "flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-colors font-mono border",
                    currentModel === "sonnet"
                      ? "bg-sonnet-faint/30 border-sonnet-glow/30 text-sonnet-bright"
                      : "bg-haiku-faint/30 border-haiku-glow/30 text-haiku-bright"
                  )}
                  title={currentModel === "haiku" ? "modo expansão (sonnet)" : "modo foco (haiku)"}
                >
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    currentModel === "sonnet" ? "bg-sonnet-core" : "bg-haiku-core"
                  )} />
                  {currentModel === "sonnet" ? "modo expansão" : "modo foco"}
                  <ChevronUp className="w-3 h-3" />
                </button>
                <button
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-muted-foreground hover:text-foreground text-xs transition-colors font-mono"
                  onClick={() => archiveSession.mutate({ sessionId: activeSessionId })}
                >
                  <Archive className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">:: arquivar</span>
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {localMessages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full py-16 space-y-4 text-center">
                  <div className="w-12 h-12 rounded-full bg-prysma-faint border border-prysma-dim/40 flex items-center justify-center">
                    <span className="text-prysma-bright text-lg">✦</span>
                  </div>
                  <div>
                    <p className="text-foreground font-medium font-mono">
                      {'}'}_&nbsp;navegador prysma_
                    </p>
                    <p className="text-sm text-muted-foreground mt-1 font-mono">
                      :: sessão iniciada. como posso ajudar, comandante?
                    </p>
                  </div>
                </div>
              )}

              {localMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    "flex gap-3",
                    msg.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  {msg.role === "assistant" && (
                    <div className="w-7 h-7 rounded-full bg-prysma-faint border border-prysma-dim/40 flex items-center justify-center shrink-0 mt-0.5">
                      <span className="text-prysma-bright text-xs">✦</span>
                    </div>
                  )}
                  <div
                    className={cn(
                      "max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
                      msg.role === "user"
                        ? "bg-prysma-faint/50 border border-prysma-dim/30 text-foreground font-mono"
                        : "bg-space-surface/60 border border-space-border/30 text-foreground"
                    )}
                  >
                    {msg.pending ? (
                      <div className="flex items-center gap-1.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-prysma-bright animate-pulse" />
                        <div className="w-1.5 h-1.5 rounded-full bg-prysma-bright animate-pulse delay-75" />
                        <div className="w-1.5 h-1.5 rounded-full bg-prysma-bright animate-pulse delay-150" />
                      </div>
                    ) : msg.role === "assistant" ? (
                      <div className="prose prose-sm prose-invert max-w-none font-mono">
                        <Streamdown>{msg.content}</Streamdown>
                      </div>
                    ) : (
                      msg.content
                    )}
                    {!msg.pending && msg.model && (
                      <div className="mt-1.5 flex items-center gap-1">
                        <div className={cn(
                          "w-1.5 h-1.5 rounded-full",
                          msg.model === "sonnet" ? "bg-sonnet-core" : "bg-haiku-core"
                        )} />
                        <span className="text-[10px] text-muted-foreground lowercase font-mono">
                          {msg.model === "sonnet" ? "modo expansão" : "modo foco"}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input area */}
            <div className="p-4 border-t border-space-border/30 bg-space-deep/50 shrink-0">
              <div className="flex items-center gap-3 bg-space-surface/60 border border-space-border/40 rounded-2xl px-4 py-2.5 focus-within:border-prysma-dim/50 transition-colors min-h-[48px]">
                <textarea
                  ref={inputRef}
                  rows={1}
                  className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none resize-none font-mono max-h-32 leading-5 py-1.5 self-center"
                  placeholder=":: mensagem para o navegador..."
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  disabled={aiChat.isPending}
                  style={{ height: "auto" }}
                  onInput={(e) => {
                    const t = e.currentTarget;
                    t.style.height = "auto";
                    t.style.height = Math.min(t.scrollHeight, 128) + "px";
                  }}
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || aiChat.isPending}
                  className={cn(
                    "w-8 h-8 rounded-xl flex items-center justify-center transition-all shrink-0",
                    input.trim() && !aiChat.isPending
                      ? "bg-prysma-core hover:bg-prysma-bright text-space-void"
                      : "bg-space-border/30 text-muted-foreground cursor-not-allowed"
                  )}
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[10px] text-muted-foreground text-center mt-2 font-mono">
                enter para enviar · shift+enter para nova linha
              </p>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-6 text-center">
            <div className="w-16 h-16 rounded-full bg-prysma-faint border border-prysma-dim/40 flex items-center justify-center">
              <span className="text-prysma-bright text-2xl">✦</span>
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-semibold text-foreground font-mono">{'}'}_&nbsp;navegador prysma_</h2>
              <p className="text-sm text-muted-foreground max-w-sm font-mono">
                :: inicie uma nova sessão para conversar com o navegador ou selecione uma sessão ativa na barra lateral.
              </p>
            </div>
            <button
              onClick={() => createSession.mutate({ model: "haiku" })}
              disabled={createSession.isPending}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-prysma-core hover:bg-prysma-bright text-space-void text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed glow-prysma font-mono"
            >
              <Plus className="w-4 h-4" />
              :: nova sessão
            </button>
          </div>
        )}
      </div>
      {chatUnlockedPhaseId && (
        <UnlockPopup
          unlockedPhaseId={chatUnlockedPhaseId}
          onClose={() => setChatUnlockedPhaseId(null)}
        />
      )}
    </div>
  );
}
