import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { Send, Trash2, Brain } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { TipTapEditor } from "@/components/TipTapEditor";

type BrainNote = { id: number; content: string };

export default function Cerebro() {
  const [content, setContent] = useState("");
  const [, navigate] = useLocation();

  const { data: notes = [], refetch } = trpc.brain.list.useQuery();

  const createNote = trpc.brain.create.useMutation({
    onSuccess: () => {
      refetch();
      setContent("");
      toast.success(":: nota salva.");
    },
    onError: () => toast.error("erro ao salvar nota."),
  });

  const deleteNote = trpc.brain.delete.useMutation({
    onSuccess: () => refetch(),
    onError: () => toast.error("erro ao remover nota."),
  });

  const handleSave = () => {
    const isEmpty = !content || content === "<p></p>" || content.trim() === "";
    if (isEmpty) return;
    createNote.mutate({ content, type: "note" });
  };

  const handleSendToNavigator = () => {
    const notesList = notes as BrainNote[];
    if (notesList.length === 0) {
      toast.info(":: adicione notas antes de enviar ao navegador.");
      return;
    }
    const parser = new DOMParser();
    const allContent = notesList
      .map((n) => {
        const doc = parser.parseFromString(n.content, "text/html");
        return doc.body.textContent ?? n.content;
      })
      .join("\n\n");
    navigate(`/chat?protocol=segundo_cerebro&prefill=${encodeURIComponent(allContent)}`);
  };

  const isContentEmpty = !content || content === "<p></p>" || content.trim() === "";
  const notesList = notes as BrainNote[];

  return (
    <div className="min-h-screen flex flex-col fade-in-up">

      {/* ─── Header ──────────────────────────────────────────────────── */}
      <div className="p-4 md:p-8 space-y-1">
        <div className="flex items-center gap-3">
          <Brain className="w-5 h-5 text-[oklch(0.62_0.28_330)]" />
          <h1 className="text-2xl font-semibold font-mono text-foreground">
            {'}'}_&nbsp;2º cérebro
          </h1>
        </div>
        <p className="text-sm font-mono pl-8 text-[oklch(0.62_0.28_330)]">
          :: tire da cabeça agora. deixe que prysma organize depois.
        </p>
      </div>

      {/* ─── Área de captura — full width ───────────────────────────────── */}
      <div className="flex-1 flex flex-col">

        {/* Editor principal — ocupa toda a largura */}
        <div className="w-full border-b border-space-border/20 bg-space-dark/40">
          <div className="w-full" style={{ minHeight: "260px" }}>
            <TipTapEditor
              content={content}
              onChange={setContent}
              placeholder="capture um pensamento, ideia, tarefa ou insight..."
              minHeight="260px"
            />
          </div>
          {/* Barra de ação abaixo do editor */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-space-border/20">
            <p className="text-[10px] text-muted-foreground/40 font-mono hidden sm:block">
              :: salve suas notas e deixe prysma_ organizar depois.
            </p>
            <div className="flex items-center gap-2 ml-auto">
              <button
                onClick={handleSave}
                disabled={isContentEmpty || createNote.isPending}
                className={cn(
                  "shrink-0 whitespace-nowrap px-4 py-2 rounded-lg text-sm font-mono font-medium transition-colors",
                  !isContentEmpty
                    ? "bg-[oklch(0.62_0.28_330)] hover:bg-[oklch(0.68_0.28_330)] text-white"
                    : "bg-space-mid/40 text-muted-foreground/40 cursor-not-allowed"
                )}
              >
                {createNote.isPending ? "salvando..." : "salvar"}
              </button>
            </div>
          </div>
        </div>

        {/* ─── Notas salvas ─────────────────────────────────────────────── */}
        <div className="flex-1 px-4 py-6 space-y-4 max-w-3xl w-full mx-auto">

          {/* Botão enviar ao navegador */}
          {notesList.length > 0 && (
            <button
              onClick={handleSendToNavigator}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-prysma-core hover:bg-prysma-bright text-space-void text-sm font-semibold font-mono transition-colors"
            >
              <Send className="w-4 h-4 shrink-0" />
              <span className="whitespace-nowrap">
                :: enviar {notesList.length} {notesList.length === 1 ? "nota" : "notas"} ao navegador
              </span>
            </button>
          )}

          <p className="text-[10px] text-muted-foreground/50 font-mono uppercase tracking-wider">
            :: notas salvas ({notesList.length})
          </p>

          {notesList.length === 0 ? (
            <div className="rounded-2xl border border-space-border/20 bg-space-dark/40 p-12 flex flex-col items-center justify-center gap-3">
              <span className="text-4xl opacity-20">🧠</span>
              <p className="text-sm text-muted-foreground/30 font-mono text-center">
                :: nenhuma nota ainda
                <br />
                <span className="text-xs">escreva algo e salve para começar</span>
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {notesList.map((note) => (
                <div
                  key={note.id}
                  className="group flex items-start gap-4 p-5 rounded-xl border border-space-border/20 bg-space-dark/60 hover:border-space-border/40 transition-colors"
                >
                  <div
                    className="flex-1 text-sm text-foreground leading-relaxed prose prose-invert prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: note.content }}
                  />
                  <button
                    onClick={() => deleteNote.mutate({ id: note.id })}
                    className="shrink-0 p-1.5 rounded-lg text-muted-foreground/20 hover:text-red-400 hover:bg-red-400/10 opacity-0 group-hover:opacity-100 transition-all"
                    title="remover nota"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
