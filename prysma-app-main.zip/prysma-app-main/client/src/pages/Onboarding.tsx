import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Check, ChevronRight, Loader2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";

// ─── Tipos ────────────────────────────────────────────────────────────────────

type Step = {
  id: string;
  question: string;
  subtext?: string;
  type: "text" | "choice" | "multiChoice" | "confirm";
  choices?: { value: string; label: string; emoji?: string }[];
  placeholder?: string;
  required?: boolean;
};

// ─── Passos da Carta de Navegação ─────────────────────────────────────────────
// Baseado nos 11 loops do Kernel V7.2 — versão simplificada para onboarding

const STEPS: Step[] = [
  {
    id: "nome",
    question: "como posso te chamar?",
    subtext: "seu nome ou como prefere ser chamado aqui.",
    type: "text",
    placeholder: "seu nome...",
    required: true,
  },
  {
    id: "identidade",
    question: "como você se define profissionalmente?",
    subtext: "não precisa ser um título formal. pode ser uma essência.",
    type: "text",
    placeholder: "ex: criador de conteúdo, empreendedor, designer...",
    required: true,
  },
  {
    id: "perfil_energia",
    question: "qual é o seu perfil de energia criativa?",
    subtext: "escolha o que mais ressoa com você agora.",
    type: "choice",
    choices: [
      { value: "criador_sensivel", label: "criador sensível", emoji: "🎨", },
      { value: "realizador", label: "realizador", emoji: "⚡" },
      { value: "estrategista", label: "estrategista", emoji: "🧭" },
      { value: "explorador", label: "explorador", emoji: "🔭" },
    ],
    required: true,
  },
  {
    id: "missao_principal",
    question: "qual é a sua missão principal agora?",
    subtext: "o projeto ou objetivo que está no centro da sua vida neste momento.",
    type: "text",
    placeholder: "ex: lançar meu primeiro produto digital...",
    required: true,
  },
  {
    id: "maior_desafio",
    question: "qual é o seu maior desafio de gestão hoje?",
    subtext: "seja honesto. é aqui que o prysma_ começa a trabalhar.",
    type: "choice",
    choices: [
      { value: "dispersao", label: "dispersão e foco", emoji: "🌀" },
      { value: "priorizacao", label: "priorização de projetos", emoji: "📊" },
      { value: "energia", label: "gestão de energia", emoji: "🔋" },
      { value: "execucao", label: "execução e consistência", emoji: "🎯" },
    ],
    required: true,
  },
  {
    id: "ritmo",
    question: "qual é o seu ritmo natural de trabalho?",
    subtext: "sem julgamentos — cada ritmo tem seu valor.",
    type: "choice",
    choices: [
      { value: "matinal", label: "matinal :: começo cedo", emoji: "🌅" },
      { value: "noturno", label: "noturno :: floresço à noite", emoji: "🌙" },
      { value: "variavel", label: "variável :: depende do dia", emoji: "🌊" },
      { value: "intenso", label: "intenso :: sprints concentrados", emoji: "⚡" },
    ],
    required: true,
  },
  {
    id: "ferramentas",
    question: "quais ferramentas você já usa no seu fluxo?",
    subtext: "selecione todas que se aplicam.",
    type: "multiChoice",
    choices: [
      { value: "notion", label: "notion", emoji: "📓" },
      { value: "google_agenda", label: "google agenda", emoji: "📅" },
      { value: "trello", label: "trello / kanban", emoji: "📋" },
      { value: "obsidian", label: "obsidian / notas", emoji: "💎" },
      { value: "nenhuma", label: "nenhuma estruturada", emoji: "🌱" },
    ],
    required: false,
  },
  {
    id: "intencao",
    question: "o que você espera do prysma_?",
    subtext: "uma frase. pode ser simples.",
    type: "text",
    placeholder: "ex: quero parar de me perder nos meus projetos...",
    required: true,
  },
  {
    id: "confirmacao",
    question: "sua carta de navegação está pronta.",
    subtext: "com essas informações, o navegador pode começar a operar com plena capacidade. pronto para ativar o sistema?",
    type: "confirm",
    required: true,
  },
];

// ─── Componente Principal ─────────────────────────────────────────────────────

export default function Onboarding() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [currentAnswer, setCurrentAnswer] = useState<string | string[]>("");
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isCompleting, setIsCompleting] = useState(false);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  const updateOnboarding = trpc.user.completeOnboarding.useMutation();

  const step = STEPS[currentStep];
  const isLastStep = currentStep === STEPS.length - 1;
  const progress = ((currentStep) / STEPS.length) * 100;

  // Foca no input ao trocar de passo
  useEffect(() => {
    if (step?.type === "text") {
      setTimeout(() => inputRef.current?.focus(), 400);
    }
    setCurrentAnswer(step?.type === "multiChoice" ? [] : "");
  }, [currentStep]);

  const handleNext = async () => {
    if (isTransitioning) return;

    const answer = currentAnswer;
    const newAnswers = { ...answers, [step.id]: answer };
    setAnswers(newAnswers);

    if (isLastStep) {
      setIsCompleting(true);
      try {
        await updateOnboarding.mutateAsync({ cartaDeNavegacao: newAnswers });
        navigate("/");
      } catch (err) {
        console.error("Erro ao salvar carta de navegação:", err);
        navigate("/");
      }
      return;
    }

    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentStep((s) => s + 1);
      setIsTransitioning(false);
    }, 300);
  };

  const canProceed = () => {
    if (!step?.required) return true;
    if (step.type === "multiChoice") return true; // opcional
    if (step.type === "confirm") return true;
    return String(currentAnswer).trim().length > 0;
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey && canProceed()) {
      e.preventDefault();
      handleNext();
    }
  };

  const toggleMultiChoice = (value: string) => {
    const current = (currentAnswer as string[]) || [];
    if (current.includes(value)) {
      setCurrentAnswer(current.filter((v) => v !== value));
    } else {
      setCurrentAnswer([...current, value]);
    }
  };

  if (!step) return null;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6 py-12 relative overflow-hidden">
      {/* Fundo espacial */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-prysma/5 blur-3xl" />
        <div className="absolute bottom-1/3 right-1/4 w-64 h-64 rounded-full bg-prysma/3 blur-3xl" />
      </div>

      {/* Barra de progresso */}
      <div className="fixed top-0 left-0 right-0 h-0.5 bg-border z-50">
        <motion.div
          className="h-full bg-prysma"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>

      {/* Logo */}
      <div className="fixed top-6 left-6 font-mono text-sm text-muted-foreground">
        prysma_
      </div>

      {/* Contador de passos */}
      <div className="fixed top-6 right-6 font-mono text-xs text-muted-foreground">
        {String(currentStep + 1).padStart(2, "0")} / {String(STEPS.length).padStart(2, "0")}
      </div>

      {/* Conteúdo principal */}
      <div className="w-full max-w-xl relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -24 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="space-y-8"
          >
            {/* Pergunta */}
            <div className="space-y-3">
              <p className="font-mono text-xs text-prysma tracking-widest uppercase">
                {"}_"} carta de navegação ::
              </p>
              <h1 className="text-2xl md:text-3xl font-mono font-light text-foreground leading-snug">
                {step.question}
              </h1>
              {step.subtext && (
                <p className="text-sm text-muted-foreground font-mono leading-relaxed">
                  {step.subtext}
                </p>
              )}
            </div>

            {/* Input por tipo */}
            <div className="space-y-4">
              {step.type === "text" && (
                <div className="relative">
                  <textarea
                    ref={inputRef as React.RefObject<HTMLTextAreaElement>}
                    value={currentAnswer as string}
                    onChange={(e) => setCurrentAnswer(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={step.placeholder}
                    rows={2}
                    className="w-full bg-transparent border-0 border-b border-border/50 focus:border-prysma outline-none resize-none font-mono text-lg text-foreground placeholder:text-muted-foreground/40 pb-3 transition-colors"
                  />
                  <div className="absolute bottom-3 right-0 text-xs text-muted-foreground/40 font-mono">
                    enter ↵
                  </div>
                </div>
              )}

              {step.type === "choice" && (
                <div className="grid grid-cols-1 gap-3">
                  {step.choices?.map((choice) => (
                    <button
                      key={choice.value}
                      onClick={() => {
                        setCurrentAnswer(choice.value);
                        setTimeout(handleNext, 300);
                      }}
                      className={`flex items-center gap-4 p-4 rounded-lg border font-mono text-sm text-left transition-all ${
                        currentAnswer === choice.value
                          ? "border-prysma bg-prysma/10 text-foreground"
                          : "border-border/30 bg-card/30 text-muted-foreground hover:border-prysma/50 hover:bg-card/50"
                      }`}
                    >
                      {choice.emoji && (
                        <span className="text-xl">{choice.emoji}</span>
                      )}
                      <span>{choice.label}</span>
                      {currentAnswer === choice.value && (
                        <Check className="ml-auto w-4 h-4 text-prysma" />
                      )}
                    </button>
                  ))}
                </div>
              )}

              {step.type === "multiChoice" && (
                <div className="grid grid-cols-1 gap-3">
                  {step.choices?.map((choice) => {
                    const selected = (currentAnswer as string[]).includes(choice.value);
                    return (
                      <button
                        key={choice.value}
                        onClick={() => toggleMultiChoice(choice.value)}
                        className={`flex items-center gap-4 p-4 rounded-lg border font-mono text-sm text-left transition-all ${
                          selected
                            ? "border-prysma bg-prysma/10 text-foreground"
                            : "border-border/30 bg-card/30 text-muted-foreground hover:border-prysma/50 hover:bg-card/50"
                        }`}
                      >
                        {choice.emoji && (
                          <span className="text-xl">{choice.emoji}</span>
                        )}
                        <span>{choice.label}</span>
                        {selected && (
                          <Check className="ml-auto w-4 h-4 text-prysma" />
                        )}
                      </button>
                    );
                  })}
                </div>
              )}

              {step.type === "confirm" && (
                <div className="space-y-4 p-6 rounded-xl border border-prysma/20 bg-prysma/5">
                  <div className="space-y-2">
                    {Object.entries(answers).slice(0, 4).map(([key, val]) => (
                      <div key={key} className="flex gap-3 font-mono text-xs text-muted-foreground">
                        <span className="text-prysma/60">::</span>
                        <span className="truncate">
                          {Array.isArray(val) ? val.join(", ") : val}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Botão de avançar (para tipos não-choice) */}
            {(step.type === "text" || step.type === "multiChoice" || step.type === "confirm") && (
              <button
                onClick={handleNext}
                disabled={!canProceed() || isCompleting}
                className={`flex items-center gap-3 font-mono text-sm transition-all ${
                  canProceed() && !isCompleting
                    ? "text-prysma hover:text-prysma/80"
                    : "text-muted-foreground/30 cursor-not-allowed"
                }`}
              >
                {isCompleting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>ativando sistema...</span>
                  </>
                ) : isLastStep ? (
                  <>
                    <span>{"}_"} ativar sistema</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                ) : (
                  <>
                    <span>:: continuar</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
