import { CalendarCheck, Lock, ChevronRight } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function MissoesDaSemana() {
  const [, navigate] = useLocation();
  const { data: progress } = trpc.progress.get.useQuery();
  const completedPhases: string[] = (progress?.completedPhases as string[]) ?? [];
  const isUnlocked = completedPhases.includes("plano_voo");

  if (isUnlocked) {
    return (
      <div className="min-h-screen px-4 md:px-8 py-8 max-w-2xl mx-auto">
        <div className="mb-8">
          <p className="text-xs text-muted-foreground/60 font-mono mb-1">:: implementação · fase 2</p>
          <h1 className="text-2xl font-bold font-mono text-foreground mb-2">missões da semana</h1>
          <p className="text-sm text-muted-foreground font-mono">
            {'}'}_&nbsp;selecione o sprint da semana com o Navegador.
          </p>
        </div>
        <button
          onClick={() => navigate("/chat?protocol=missoes_semana&cmd=escolher+miss%C3%B5es+da+semana")}
          className="flex items-center gap-3 w-full p-5 rounded-2xl border border-prysma-dim/40 bg-space-surface/30 hover:bg-space-surface/50 transition-colors text-left"
        >
          <CalendarCheck className="w-6 h-6 text-prysma-bright/70 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold font-mono text-foreground">:: iniciar missões da semana</p>
            <p className="text-xs text-muted-foreground/60 font-mono mt-0.5">
              o Navegador cruza TUD, agenda e prioridades para montar o sprint
            </p>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground/40 shrink-0" />
        </button>
      </div>
    );
  }

  return (
    <LockedPage
      phase={2}
      label="missões da semana"
      sublabel="selecione o sprint"
      description="Com o plano traçado, organize as missões da semana cruzando TUD, agenda e prioridades. O Navegador cuida da distribuição de energia."
      prerequisite="plano de vôo"
      prerequisiteHref="/plano-de-voo"
      Icon={CalendarCheck}
    />
  );
}

// ─── Componente de Página Travada ─────────────────────────────────────────────
function LockedPage({
  phase,
  label,
  sublabel,
  description,
  prerequisite,
  prerequisiteHref,
  Icon,
}: {
  phase: number;
  label: string;
  sublabel: string;
  description: string;
  prerequisite: string;
  prerequisiteHref: string;
  Icon: React.FC<{ className?: string }>;
}) {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen px-4 md:px-8 py-8 max-w-2xl mx-auto flex flex-col items-center justify-center text-center">
      <div className="space-y-6 max-w-sm">
        {/* Ícone travado */}
        <div className="relative mx-auto w-16 h-16">
          <div className="w-16 h-16 rounded-2xl bg-space-surface/30 border border-space-border/20 flex items-center justify-center">
            <Icon className="w-7 h-7 text-muted-foreground/20" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-space-deep border border-space-border/30 flex items-center justify-center">
            <Lock className="w-3 h-3 text-muted-foreground/40" />
          </div>
        </div>

        {/* Label */}
        <div>
          <p className="text-[10px] text-muted-foreground/40 font-mono mb-1">:: fase {phase}</p>
          <h1 className="text-xl font-bold font-mono text-muted-foreground/50 mb-1">{label}</h1>
          <p className="text-xs text-muted-foreground/40 font-mono">{sublabel}</p>
        </div>

        {/* Descrição */}
        <p className="text-sm text-muted-foreground/50 leading-relaxed font-mono">{description}</p>

        {/* CTA */}
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground/40 font-mono">
            {'}'}_&nbsp;conclua <span className="text-prysma-bright/50">{prerequisite}</span> para desbloquear
          </p>
          <button
            onClick={() => navigate(prerequisiteHref)}
            className="flex items-center gap-2 mx-auto px-4 py-2 rounded-xl text-xs font-mono font-semibold bg-prysma-faint/20 text-prysma-bright/60 hover:bg-prysma-faint/30 border border-prysma-dim/20 hover:border-prysma-dim/40 transition-colors"
          >
            ir para {prerequisite}
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
}
