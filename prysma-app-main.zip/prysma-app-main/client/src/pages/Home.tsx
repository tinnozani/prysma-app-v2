import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { BookOpen, MessageSquare, Zap, ChevronRight, ChevronDown, ChevronUp, AlertCircle, Bell, BellOff, Lock, Terminal, X } from "lucide-react";
import { Link } from "wouter";
import { useLocation } from "wouter";
import { useState } from "react";

// ─── Ícone de Órbita ──────────────────────────────────────────────────────────
function OrbitIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="5" />
      <path d="M4.5 9.5 C6 7.5, 18 16.5, 19.5 14.5" />
    </svg>
  );
}

// ─── Ícone de Carta ───────────────────────────────────────────────────────────
function CartaIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} strokeWidth="1.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 3L3 6v15l6-3 6 3 6-3V3l-6 3-6-3z" />
      <line x1="9" y1="3" x2="9" y2="18" />
      <line x1="15" y1="6" x2="15" y2="21" />
    </svg>
  );
}

export default function Home() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const { data: integrations } = trpc.integrations.getStatus.useQuery();
  const { data: credits } = trpc.credits.getWeekly.useQuery();
  const { data: sessions } = trpc.sessions.list.useQuery({ status: "active" });
  const { data: carta } = trpc.carta.get.useQuery();
  const { data: tudResult } = trpc.notion.getTUD.useQuery();
  const { data: triadeProjResult } = trpc.notion.getProjetosTriade.useQuery();
  const { data: ciclosProjResult } = trpc.notion.getProjetosCiclos.useQuery();
  const { data: progress } = trpc.progress.get.useQuery();
  const completedPhases: string[] = (progress?.completedPhases as string[]) ?? [];
  const checkinUnlocked = completedPhases.includes("checkin_semanal");
  const comandosUnlocked = completedPhases.includes("comandos");

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "bom dia" : hour < 18 ? "boa tarde" : "boa noite";
  const firstName = user?.name?.split(" ")[0]?.toLowerCase() ?? "comandante";

  const today = new Date();
  const weekday = today.toLocaleDateString("pt-BR", { weekday: "long" });
  const day = today.getDate();
  const month = today.toLocaleDateString("pt-BR", { month: "long" });
  const year = today.getFullYear();

  const cartaCompleta = !!carta;
  const notionConectado = (integrations as any)?.notion?.connected ?? false;

  const tudData = tudResult?.data ?? null;
  const projetosTriade = triadeProjResult?.items ?? [];
  const projetosCiclos = ciclosProjResult?.items ?? [];

  return (
    <div className="min-h-screen p-4 md:p-8 space-y-10 fade-in-up">
      {/* ─── Header ─────────────────────────────────────────────────────────── */}
      <div className="space-y-1.5">
        <p className="text-muted-foreground text-sm font-mono">
          {'}'}_&nbsp;{greeting}, comandante <span className="font-bold text-foreground">{firstName}</span> 🖖🏼
        </p>
        <h1 className="text-2xl md:text-3xl font-semibold text-foreground">
          sala de comandos
          <span className="gradient-prysma"> ::</span>
        </h1>
        <p className="text-muted-foreground text-xs font-mono italic">
          {weekday} {'}'} {day} de {month} de {year}
        </p>
      </div>

      {/* ─── Quick Actions — F7: nova sessão → integrações → notificação check-in → biblioteca ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* 1. Nova sessão */}
        <QuickAction
          href="/chat"
          icon={MessageSquare}
          label=":: nova sessão"
          description="conversar com o navegador"
          color="prysma"
        />
        {/* 2. Integrações */}
        <QuickAction
          href="/perfil"
          icon={Zap}
          label=":: integrações"
          description="notion e google"
          color="neutral"
          badge={!notionConectado ? "configurar" : undefined}
        />
        {/* 3. Notificação check-in — F5: travada até check-in ser desbloqueado */}
        <CheckinNotificationWidget unlocked={checkinUnlocked} />
        {/* 4. Biblioteca — F6: travada até comandos ser desbloqueado */}
        <BibliotecaWidget unlocked={comandosUnlocked} />
      </div>

      {/* ─── Widgets da Carta de Navegação ──────────────────────────────────── */}
      {cartaCompleta ? (
        <div className="space-y-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-muted-foreground font-mono uppercase tracking-widest">
              :: carta de navegação
            </h2>
            <Link
              href="/carta"
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-prysma-bright transition-colors font-mono px-2.5 py-1 rounded-lg border border-space-border/40 hover:border-prysma-dim/40 hover:bg-prysma-faint/20"
            >
              visualizar →
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Widget Bússola — dados da carta */}
            <WidgetBussola carta={carta} />
            {/* Widget TUD — dados do Notion */}
            <WidgetTUD tudData={tudData} notionConectado={notionConectado} />
          </div>

          {/* Linhas alternantes — Projetos */}
          <div className="space-y-3">
            <LinhaAlternante
              titulo="}_ como está fluindo sua tríade central ::"
              projetos={projetosTriade}
              notionConectado={notionConectado}
              cor="sonnet"
            />
            <LinhaAlternante
              titulo="}_ como estão fluindo seus ciclos de sustentação ::"
              projetos={projetosCiclos}
              notionConectado={notionConectado}
              cor="prysma"
            />
          </div>
        </div>
      ) : (
        /* Banner — carta não preenchida */
        <div className="rounded-2xl border border-prysma-dim/40 bg-prysma-faint/10 p-6 space-y-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-prysma-faint border border-prysma-dim/40 flex items-center justify-center shrink-0 mt-0.5">
              <CartaIcon className="w-4 h-4 text-prysma-bright" />
            </div>
            <div className="space-y-1">
              <h3 className="font-semibold text-foreground text-sm font-mono">
                {'}'}_&nbsp; carta de navegação pendente
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed font-mono">
                :: o navegador precisa conhecer seu território antes de operar. preencha sua carta de navegação para ativar os widgets da sala de comandos.
              </p>
            </div>
          </div>
          <Link
            href="/chat?protocol=carta"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-prysma-core hover:bg-prysma-bright text-space-void text-sm font-medium transition-colors font-mono"
          >
            :: iniciar carta de navegação
          </Link>
        </div>
      )}

      {/* ─── Status Cards ────────────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <StatusCard title="}_ conexões ativas ::">
          <div className="space-y-3">
            <IntegrationRow
              name="notion"
              connected={(integrations as any)?.notion?.connected ?? false}
              detail={(integrations as any)?.notion?.workspaceName}
            />
            <IntegrationRow
              name="google agenda"
              connected={(integrations as any)?.google?.connected ?? false}
              detail={(integrations as any)?.google?.providerUserId}
            />
          </div>
          {(!notionConectado || !(integrations as any)?.google?.connected) && (
            <Link
              href="/perfil"
              className="mt-4 flex items-center justify-center w-full px-3 py-1.5 rounded-lg border border-space-border text-muted-foreground hover:text-foreground text-sm transition-colors font-mono lowercase"
            >
              :: configurar integrações
            </Link>
          )}
        </StatusCard>

        <StatusCard title="}_ últimas sessões ::">
          {sessions && (sessions as any[]).length > 0 ? (
            <div className="space-y-2">
              {(sessions as any[]).slice(0, 3).map((session: any) => (
                <Link
                  key={session.id}
                  href={`/chat?session=${session.id}`}
                  className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/50 hover:bg-muted transition-colors border border-border/50"
                >
                  <div className={cn(
                    "w-2 h-2 rounded-full shrink-0",
                    session.model === "sonnet" ? "bg-sonnet-core" : "bg-haiku-core"
                  )} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground truncate lowercase">
                      {session.title ?? session.protocolName ?? "sessão sem título"}
                    </p>
                    <p className="text-xs text-muted-foreground font-mono">
                      {new Date(session.createdAt).toLocaleDateString("pt-BR")}
                    </p>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 space-y-2">
              <p className="text-sm text-muted-foreground font-mono">nenhuma sessão registrada.</p>
              <Link
                href="/chat"
                className="inline-flex items-center justify-center px-3 py-1.5 rounded-lg bg-prysma-core hover:bg-prysma-bright text-space-void text-sm font-medium transition-colors"
              >
                :: nova sessão
              </Link>
            </div>
          )}
        </StatusCard>
      </div>
    </div>
  );
}

// ─── Widget Bússola ───────────────────────────────────────────────────────────
function WidgetBussola({ carta }: { carta: any }) {
  return (
    <div className="rounded-2xl border border-sonnet-glow/20 bg-sonnet-faint/10 p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold text-sonnet-bright font-mono uppercase tracking-widest">
          bússola ::
        </h3>
        <span className="text-[10px] text-muted-foreground font-mono">identidade</span>
      </div>
      <div className="space-y-3">
        <TriadeItem label="quem sou" value={carta?.identidade} />
        <TriadeItem label="missão" value={carta?.missaoVida} />
        <TriadeItem label="visão" value={carta?.visaoFuturo} />
      </div>
    </div>
  );
}

function TriadeItem({ label, value }: { label: string; value?: string | null }) {
  return (
    <div className="space-y-0.5">
      <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-wider">{label}</p>
      {value ? (
        <p className="text-sm text-foreground leading-snug line-clamp-2">{value}</p>
      ) : (
        <p className="text-sm text-muted-foreground/50 italic font-mono">aguardando...</p>
      )}
    </div>
  );
}

// ─── Widget TUD ────────────────────────────────────────────────────────────────
function WidgetTUD({ tudData, notionConectado }: { tudData: any; notionConectado: boolean }) {
  if (!notionConectado) {
    return (
      <div className="rounded-2xl border border-haiku-glow/20 bg-haiku-faint/10 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-haiku-bright font-mono uppercase tracking-widest">tud ::</h3>
          <span className="text-[10px] text-muted-foreground font-mono">tempo útil disponível</span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground/60">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <p className="text-xs font-mono">notion não conectado</p>
        </div>
        <Link href="/perfil" className="text-xs text-haiku-bright font-mono hover:underline">
          :: conectar notion →
        </Link>
      </div>
    );
  }

  if (!tudData) {
    return (
      <div className="rounded-2xl border border-haiku-glow/20 bg-haiku-faint/10 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-haiku-bright font-mono uppercase tracking-widest">tud ::</h3>
          <span className="text-[10px] text-muted-foreground font-mono">tempo útil disponível</span>
        </div>
        <p className="text-xs text-muted-foreground/50 italic font-mono">carregando dados...</p>
      </div>
    );
  }

  const triadePct = tudData.maxTriadeSemana
    ? Math.min(100, Math.round(((tudData.somaTriadeSemana ?? 0) / tudData.maxTriadeSemana) * 100))
    : 0;
  const ciclosPct = tudData.maxCiclosSemana
    ? Math.min(100, Math.round(((tudData.somaCiclosSemana ?? 0) / tudData.maxCiclosSemana) * 100))
    : 0;

  return (
    <div className="rounded-2xl border border-haiku-glow/20 bg-haiku-faint/10 p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold text-haiku-bright font-mono uppercase tracking-widest">tud ::</h3>
        <span className="text-[10px] text-muted-foreground font-mono">tempo útil disponível</span>
      </div>

      {/* Total TUD */}
      {tudData.tudTotalH != null && (
        <div className="flex items-baseline gap-1.5">
          <span className="text-2xl font-bold text-foreground font-mono">{tudData.tudTotalH}h</span>
          <span className="text-xs text-muted-foreground font-mono">/ semana</span>
        </div>
      )}

      {/* Barras de progresso */}
      <div className="space-y-3">
        <TUDBar
          label="tríade central"
          usado={tudData.somaTriadeSemana ?? 0}
          maximo={tudData.maxTriadeSemana ?? 0}
          qtd={tudData.qtdTriadeAtiva ?? 0}
          pct={triadePct}
          barClass="bg-sonnet-core"
        />
        <TUDBar
          label="ciclos de sustentação"
          usado={tudData.somaCiclosSemana ?? 0}
          maximo={tudData.maxCiclosSemana ?? 0}
          qtd={tudData.qtdCiclosAtivos ?? 0}
          pct={ciclosPct}
          barClass="bg-haiku-core"
        />
      </div>

      {/* Resumo TUD se disponível */}
      {tudData.resumoTud && (
        <p className="text-[10px] text-muted-foreground font-mono border-t border-space-border/20 pt-2 leading-relaxed">
          {tudData.resumoTud}
        </p>
      )}
    </div>
  );
}

function TUDBar({
  label, usado, maximo, qtd, pct, barClass,
}: {
  label: string; usado: number; maximo: number; qtd: number; pct: number; barClass: string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground font-mono">{label}</span>
        <span className="text-[10px] text-muted-foreground font-mono">
          {usado}h / {maximo}h &middot; {qtd} proj.
        </span>
      </div>
      <div className="h-1.5 w-full bg-space-border/30 rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-500", barClass)}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

// ─── Linha Alternante de Projetos ─────────────────────────────────────────────
function LinhaAlternante({
  titulo, projetos, notionConectado, cor,
}: {
  titulo: string;
  projetos: any[];
  notionConectado: boolean;
  cor: "sonnet" | "prysma";
}) {
  const [aberta, setAberta] = useState(false);

  const colorMap = {
    sonnet: { border: "border-sonnet-glow/20", bg: "bg-sonnet-faint/10", title: "text-sonnet-bright", dot: "bg-sonnet-core" },
    prysma: { border: "border-prysma-dim/20", bg: "bg-prysma-faint/10", title: "text-prysma-bright", dot: "bg-prysma-core" },
  };
  const c = colorMap[cor];

  return (
    <div className={cn("rounded-2xl border p-4 space-y-3 transition-all duration-200", c.border, c.bg)}>
      <button
        onClick={() => setAberta(!aberta)}
        className="w-full flex items-center justify-between"
      >
        <span className={cn("text-xs font-semibold font-mono truncate pr-2", c.title)}>{titulo}</span>
        <div className="flex items-center gap-2">
          {notionConectado && projetos.length > 0 && (
            <span className="text-[10px] text-muted-foreground font-mono">{projetos.length} ativo{projetos.length !== 1 ? "s" : ""}</span>
          )}
          {aberta ? (
            <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          )}
        </div>
      </button>

      {aberta && (
        <div className="space-y-2 pt-1">
          {!notionConectado ? (
            <div className="flex items-center gap-2 text-muted-foreground/60">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <p className="text-xs font-mono">notion não conectado —{" "}
                <Link href="/perfil" className="text-prysma-bright hover:underline">conectar →</Link>
              </p>
            </div>
          ) : projetos.length === 0 ? (
            <p className="text-xs text-muted-foreground/50 italic font-mono">nenhum projeto ativo nesta categoria.</p>
          ) : (
            projetos.map((p) => (
              <ProjetoCard key={p.id} projeto={p} dotClass={c.dot} />
            ))
          )}
        </div>
      )}
    </div>
  );
}

function ProjetoCard({ projeto, dotClass }: { projeto: any; dotClass: string }) {
  const progresso = projeto.progresso ?? 0;

  return (
    <div className="flex items-start gap-3 p-3 rounded-xl bg-space-mid/40 border border-space-border/20">
      <div className={cn("w-2 h-2 rounded-full shrink-0 mt-1", dotClass)} />
      <div className="flex-1 min-w-0 space-y-1.5">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm text-foreground font-medium truncate">{projeto.nome}</p>
          {projeto.orbita && (
            <span className="text-[10px] text-muted-foreground font-mono shrink-0 lowercase">{projeto.orbita}</span>
          )}
        </div>
        {projeto.horizonte && (
          <p className="text-xs text-muted-foreground truncate">{projeto.horizonte}</p>
        )}
        <div className="flex items-center gap-3">
          {/* Barra de progresso */}
          <div className="flex-1 h-1 bg-space-border/30 rounded-full overflow-hidden">
            <div
              className={cn("h-full rounded-full transition-all", dotClass)}
              style={{ width: `${progresso}%` }}
            />
          </div>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0">{Math.round(progresso)}%</span>
          {projeto.tudHoras != null && (
            <span className="text-[10px] text-muted-foreground font-mono shrink-0">{projeto.tudHoras}h/sem</span>
          )}
        </div>
      </div>
    </div>
  );
}

/// ─── Widget Notificação Check-in (F5) ───────────────────────────────────────
const DAYS = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];

function CheckinNotificationWidget({ unlocked }: { unlocked: boolean }) {
  const [open, setOpen] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [day, setDay] = useState("sexta");
  const [hour, setHour] = useState("08");
  const [minute, setMinute] = useState("00");
  const [permissionGranted, setPermissionGranted] = useState(false);

  const handleEnable = async () => {
    if (!enabled) {
      const perm = await Notification.requestPermission();
      if (perm === "granted") {
        setPermissionGranted(true);
        setEnabled(true);
        setOpen(true);
      } else {
        alert("Permissão de notificação negada. Habilite nas configurações do navegador.");
      }
    } else {
      setEnabled(false);
    }
  };

  const handleSave = async () => {
    // Registra o service worker se ainda não estiver registrado
    if ("serviceWorker" in navigator) {
      try {
        const reg = await navigator.serviceWorker.register("/sw.js");
        await navigator.serviceWorker.ready;
        // Envia configuração ao SW
        reg.active?.postMessage({
          type: "SCHEDULE_CHECKIN",
          payload: { day, hour, minute },
        });
        // Dispara notificação de teste
        reg.active?.postMessage({
          type: "TEST_NOTIFICATION",
          body: `}_ lembrete configurado para ${day} às ${hour}:${minute}`,
        });
      } catch (e) {
        console.warn("SW não registrado:", e);
      }
    }
    // Salva preferência localmente como fallback
    localStorage.setItem("checkin_notification", JSON.stringify({ enabled, day, hour, minute }));
    setOpen(false);
  };

  if (!unlocked) {
    return (
      <div className="relative flex flex-col gap-3 p-4 rounded-2xl border border-space-border/20 bg-space-mid/20 opacity-60 cursor-not-allowed">
        <div className="absolute top-2 right-2">
          <Lock className="w-3 h-3 text-muted-foreground/40" />
        </div>
        <div className="w-6 h-6 flex items-center justify-center text-muted-foreground/30">
          <Bell className="w-5 h-5" />
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground/40 font-mono">:: notificação</p>
          <p className="text-xs text-muted-foreground/30 lowercase">check-in semanal</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className={cn(
          "relative flex flex-col gap-3 p-4 rounded-2xl border transition-all duration-200 text-left",
          enabled
            ? "bg-prysma-faint/40 border-prysma-dim/40 hover:bg-prysma-faint/60"
            : "bg-space-mid/40 border-space-border/30 hover:bg-space-surface/60"
        )}
      >
        {/* Toggle on/off */}
        <div className="absolute top-2 right-2">
          <div
            onClick={(e) => { e.stopPropagation(); handleEnable(); }}
            className={cn(
              "w-8 h-4 rounded-full transition-colors cursor-pointer relative",
              enabled ? "bg-prysma-core" : "bg-space-border/60"
            )}
          >
            <div className={cn(
              "absolute top-0.5 w-3 h-3 rounded-full bg-white transition-transform",
              enabled ? "translate-x-4" : "translate-x-0.5"
            )} />
          </div>
        </div>
        <div className="w-6 h-6 flex items-center justify-center">
          {enabled ? (
            <Bell className="w-5 h-5 text-prysma-bright" />
          ) : (
            <BellOff className="w-5 h-5 text-muted-foreground" />
          )}
        </div>
        <div>
          <p className={cn("text-sm font-medium font-mono", enabled ? "text-foreground" : "text-muted-foreground")}>
            :: notificação
          </p>
          <p className="text-xs text-muted-foreground lowercase">
            {enabled ? `${day} às ${hour}:${minute}` : "check-in semanal"}
          </p>
        </div>
      </button>

      {/* Popup de configuração */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl border border-space-border/50 bg-space-deep p-6 space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-muted-foreground/60 font-mono mb-0.5">:: configuração</p>
                <h3 className="text-base font-semibold font-mono text-foreground">notificação de check-in</h3>
              </div>
              <button onClick={() => setOpen(false)} className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-space-surface/40 transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-muted-foreground font-mono leading-relaxed">
              receba por notificação push um lembrete para seu check-in semanal.
            </p>

            {/* Dia da semana */}
            <div className="space-y-2">
              <label className="text-xs text-muted-foreground font-mono uppercase tracking-wider">dia da semana</label>
              <div className="grid grid-cols-4 gap-1.5">
                {DAYS.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDay(d)}
                    className={cn(
                      "py-1.5 rounded-lg text-[10px] font-mono transition-colors",
                      day === d
                        ? "bg-prysma-faint text-prysma-bright border border-prysma-dim/40"
                        : "bg-space-mid/40 text-muted-foreground hover:bg-space-surface/60 border border-space-border/20"
                    )}
                  >
                    {d.slice(0, 3)}
                  </button>
                ))}
              </div>
            </div>

            {/* Horário */}
            <div className="space-y-2">
              <label className="text-xs text-muted-foreground font-mono uppercase tracking-wider">horário</label>
              <div className="flex items-center gap-2">
                <select
                  value={hour}
                  onChange={(e) => setHour(e.target.value)}
                  className="flex-1 bg-space-mid/40 border border-space-border/30 rounded-lg px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:border-prysma-dim/50"
                >
                  {Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0")).map((h) => (
                    <option key={h} value={h}>{h}h</option>
                  ))}
                </select>
                <span className="text-muted-foreground font-mono">:</span>
                <select
                  value={minute}
                  onChange={(e) => setMinute(e.target.value)}
                  className="flex-1 bg-space-mid/40 border border-space-border/30 rounded-lg px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:border-prysma-dim/50"
                >
                  {["00", "15", "30", "45"].map((m) => (
                    <option key={m} value={m}>{m}min</option>
                  ))}
                </select>
              </div>
            </div>

            <button
              onClick={handleSave}
              className="w-full py-3 rounded-xl bg-prysma-core hover:bg-prysma-bright text-space-void font-semibold text-sm font-mono transition-colors"
            >
              :: salvar configuração
            </button>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Widget Biblioteca (F6) ─────────────────────────────────────────────────────
function BibliotecaWidget({ unlocked }: { unlocked: boolean }) {
  if (!unlocked) {
    return (
      <div className="relative flex flex-col gap-3 p-4 rounded-2xl border border-space-border/20 bg-space-mid/20 opacity-60 cursor-not-allowed">
        <div className="absolute top-2 right-2">
          <Lock className="w-3 h-3 text-muted-foreground/40" />
        </div>
        <div className="w-6 h-6 flex items-center justify-center text-muted-foreground/30">
          <Terminal className="w-5 h-5" />
        </div>
        <div>
          <p className="text-sm font-medium text-muted-foreground/40 font-mono">:: biblioteca</p>
          <p className="text-xs text-muted-foreground/30 lowercase">acessar protocolos</p>
        </div>
      </div>
    );
  }

  return (
    <Link
      href="/biblioteca"
      className="relative flex flex-col gap-3 p-4 rounded-2xl border border-sonnet-glow/30 bg-sonnet-faint/40 hover:bg-sonnet-faint/60 hover:border-sonnet-glow/60 transition-all duration-200"
    >
      <div className="w-6 h-6 flex items-center justify-center text-sonnet-bright">
        <Terminal className="w-5 h-5" />
      </div>
      <div>
        <p className="text-sm font-medium text-foreground font-mono">:: biblioteca</p>
        <p className="text-xs text-muted-foreground lowercase">acessar protocolos</p>
      </div>
    </Link>
  );
}

// ─── Sub-components ─────────────────────────────────────────────────────
function QuickAction({
  href, icon: Icon, iconComponent, label, description, color, badge,
}: {
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
  iconComponent?: React.ReactNode;
  label: string;
  description: string;
  color: "prysma" | "sonnet" | "haiku" | "neutral";
  badge?: string;
}) {
  const colorMap = {
    prysma:  { bg: "bg-prysma-faint/40",  border: "border-prysma-dim/30",   icon: "text-prysma-bright",      hover: "hover:border-prysma-dim/60 hover:bg-prysma-faint/60" },
    sonnet:  { bg: "bg-sonnet-faint/40",  border: "border-sonnet-glow/30",  icon: "text-sonnet-bright",      hover: "hover:border-sonnet-glow/60 hover:bg-sonnet-faint/60" },
    haiku:   { bg: "bg-haiku-faint/40",   border: "border-haiku-glow/30",   icon: "text-haiku-bright",       hover: "hover:border-haiku-glow/60 hover:bg-haiku-faint/60" },
    neutral: { bg: "bg-space-mid/40",     border: "border-space-border/30", icon: "text-muted-foreground",   hover: "hover:border-space-border/60 hover:bg-space-surface/60" },
  };
  const c = colorMap[color];

  return (
    <Link
      href={href}
      className={cn(
        "relative flex flex-col gap-3 p-4 rounded-2xl border transition-all duration-200",
        c.bg, c.border, c.hover
      )}
    >
      {badge && (
        <span className="absolute top-2 right-2 text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-prysma-faint text-prysma-bright border border-prysma-dim/40 lowercase font-mono">
          {badge}
        </span>
      )}
      <div className={cn("w-6 h-6 flex items-center justify-center", c.icon)}>
        {iconComponent ?? (Icon && <Icon className="w-5 h-5" />)}
      </div>
      <div>
        <p className="text-sm font-medium text-foreground font-mono">{label}</p>
        <p className="text-xs text-muted-foreground lowercase">{description}</p>
      </div>
    </Link>
  );
}

function StatusCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card-widget p-5 space-y-4">
      <h2 className="text-sm font-semibold text-prysma-bright/70 font-mono">{title}</h2>
      {children}
    </div>
  );
}

function IntegrationRow({ name, connected, detail }: { name: string; connected: boolean; detail?: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <div className={cn("w-2 h-2 rounded-full", connected ? "bg-[oklch(0.70_0.18_155)]" : "bg-space-border")} />
        <span className="text-sm text-foreground lowercase">{name}</span>
        {detail && <span className="text-xs text-muted-foreground truncate max-w-[100px] lowercase">{detail}</span>}
      </div>
      <span className={cn("text-xs font-medium font-mono lowercase", connected ? "text-[oklch(0.70_0.18_155)]" : "text-muted-foreground")}>
        {connected ? ":: ativo" : ":: inativo"}
      </span>
    </div>
  );
}
