import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { CheckCircle, ExternalLink, LogOut, XCircle, Camera, Trash2, Sun, Moon, MessageSquareOff, RotateCcw, DatabaseBackup, UserX, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CrystalEnergy } from "@/components/CrystalEnergy";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { useRef, useState, useCallback, Fragment } from "react";
import { useTheme } from "@/contexts/ThemeContext";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// ─── Avatar Upload com Crop 1:1 ───────────────────────────────────────────────
function AvatarUpload({ currentUrl, userName }: { currentUrl?: string | null; userName?: string | null }) {
  const utils = trpc.useUtils();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const uploadAvatar = trpc.user.uploadAvatar.useMutation({
    onSuccess: () => {
      toast.success("foto atualizada.");
      utils.auth.me.invalidate();
      setPreview(null);
    },
    onError: (e) => toast.error(e.message ?? "erro ao enviar foto."),
    onSettled: () => setUploading(false),
  });

  const removeAvatar = trpc.user.removeAvatar.useMutation({
    onSuccess: () => {
      toast.success("foto removida.");
      utils.auth.me.invalidate();
    },
    onError: () => toast.error("erro ao remover foto."),
  });

  // Crop central 1:1 via canvas
  const cropToSquare = useCallback((file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const size = Math.min(img.width, img.height);
        const canvas = document.createElement("canvas");
        canvas.width = 256;
        canvas.height = 256;
        const ctx = canvas.getContext("2d");
        if (!ctx) { reject(new Error("canvas ctx")); return; }
        const sx = (img.width - size) / 2;
        const sy = (img.height - size) / 2;
        ctx.drawImage(img, sx, sy, size, size, 0, 0, 256, 256);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = reject;
      img.src = url;
    });
  }, []);

  const handleFileChange = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("selecione uma imagem válida.");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("imagem muito grande. máximo 5MB.");
      return;
    }
    try {
      const cropped = await cropToSquare(file);
      setPreview(cropped);
    } catch {
      toast.error("erro ao processar imagem.");
    }
    // Reset input para permitir re-seleção do mesmo arquivo
    e.target.value = "";
  }, [cropToSquare]);

  const handleConfirm = useCallback(() => {
    if (!preview) return;
    setUploading(true);
    uploadAvatar.mutate({ imageBase64: preview, mimeType: "image/jpeg" });
  }, [preview, uploadAvatar]);

  const displayUrl = preview ?? currentUrl;
  const initial = userName?.charAt(0)?.toUpperCase() ?? "P";

  return (
    <div className="flex items-center gap-5">
      {/* Avatar */}
      <div className="relative group shrink-0">
        <div className="w-20 h-20 rounded-full overflow-hidden border-2 border-prysma-dim/40 bg-prysma-faint flex items-center justify-center">
          {displayUrl ? (
            <img src={displayUrl} alt="avatar" className="w-full h-full object-cover" />
          ) : (
            <span className="text-3xl font-semibold text-prysma-bright">{initial}</span>
          )}
        </div>
        {/* Overlay de câmera */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="absolute inset-0 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
        >
          <Camera className="w-5 h-5 text-white" />
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
      </div>

      {/* Ações */}
      <div className="space-y-2">
        {preview ? (
          <div className="flex items-center gap-2">
            <button
              onClick={handleConfirm}
              disabled={uploading}
              className="px-3 py-1.5 rounded-lg bg-prysma-core hover:bg-prysma-bright text-space-void text-xs font-medium transition-colors font-mono disabled:opacity-50"
            >
              {uploading ? "enviando..." : ":: confirmar"}
            </button>
            <button
              onClick={() => setPreview(null)}
              disabled={uploading}
              className="px-3 py-1.5 rounded-lg border border-space-border text-muted-foreground hover:text-foreground text-xs transition-colors font-mono"
            >
              cancelar
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-lg border border-space-border text-muted-foreground hover:text-foreground text-xs transition-colors font-mono"
            >
              <Camera className="w-3.5 h-3.5 inline mr-1.5" />
              alterar foto
            </button>
            {currentUrl && (
              <button
                onClick={() => removeAvatar.mutate()}
                className="p-1.5 rounded-lg border border-space-border text-muted-foreground hover:text-destructive hover:border-destructive/50 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
        <p className="text-[10px] text-muted-foreground font-mono">
          {preview ? ":: pré-visualização — confirme para salvar" : ":: jpg ou png · máx 5mb · crop automático 1:1"}
        </p>
      </div>
    </div>
  );
}

// ─── Página Principal ─────────────────────────────────────────────────────────
export default function Perfil() {
  const { user, logout } = useAuth();
  const utils = trpc.useUtils();
  const { theme, toggleTheme } = useTheme();

  const { data: integrations, isLoading } = trpc.integrations.getStatus.useQuery();

  const disconnect = trpc.integrations.disconnect.useMutation({
    onSuccess: (_, vars) => {
      toast.success(`${vars.provider === "notion" ? "notion" : "google agenda"} desconectado.`);
      utils.integrations.getStatus.invalidate();
    },
    onError: () => toast.error("erro ao desconectar."),
  });

  const notionConnected = (integrations as any)?.notion?.connected ?? false;
  const googleConnected = (integrations as any)?.google?.connected ?? false;
  const plan = (user as any)?.plan ?? "essencial";
  const avatarUrl = (user as any)?.avatarUrl ?? null;

  // Mutations de gerenciamento de dados
  const clearChats = trpc.data.clearChats.useMutation({
    onSuccess: () => toast.success(":: histórico de chats apagado."),
    onError: () => toast.error("erro ao limpar chats."),
  });
  const resetPrysmas = trpc.data.resetPrysmas.useMutation({
    onSuccess: () => {
      toast.success(":: prysmas zerados.");
      utils.auth.me.invalidate();
      utils.progress.get.invalidate();
      utils.flight.getProgress.invalidate();
    },
    onError: () => toast.error("erro ao reiniciar prysmas."),
  });
  const clearAll = trpc.data.clearAll.useMutation({
    onSuccess: () => {
      toast.success(":: prysma reiniciado. bem-vindo de volta.");
      utils.auth.me.invalidate();
      utils.progress.get.invalidate();
      utils.flight.getProgress.invalidate();
      utils.sessions.list.invalidate();
      utils.carta.get.invalidate();
    },
    onError: () => toast.error("erro ao reiniciar prysma."),
  });
  const deleteAccount = trpc.data.deleteAccount.useMutation({
    onSuccess: () => { toast.success(":: conta excluída."); logout(); },
    onError: () => toast.error("erro ao excluir conta."),
  });

  return (
    <div className="p-4 md:p-8 space-y-8 fade-in-up max-w-2xl">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold text-foreground font-mono">
          {'}'}_&nbsp;perfil
        </h1>
        <p className="text-sm text-muted-foreground font-mono">
          :: gerencie suas integrações e configurações.
        </p>
      </div>

      {/* User card com avatar upload */}
      <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-5">
        <AvatarUpload currentUrl={avatarUrl} userName={user?.name} />
        <div className="border-t border-space-border/20 pt-4 flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="font-semibold text-foreground lowercase">{user?.name ?? "navegador"}</p>
            <p className="text-sm text-muted-foreground font-mono">{user?.email ?? ""}</p>
            <div className="mt-1.5 flex items-center gap-2">
              <Badge
                variant="outline"
                className={cn(
                  "text-xs lowercase font-mono",
                  plan === "premium"
                    ? "border-prysma-dim/50 text-prysma-bright"
                    : "border-space-border text-muted-foreground"
                )}
              >
                {plan === "premium" ? "✦ premium" : "essencial"}
              </Badge>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logout()}
            className="text-muted-foreground hover:text-foreground gap-2 font-mono lowercase"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">sair</span>
          </Button>
        </div>
      </div>

      {/* Cristais de Energia */}
      <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_&nbsp;cristais de energia ::</h2>
        <CrystalEnergy />
      </div>

      {/* Integrations */}
      <div className="space-y-3">
        <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_&nbsp;integrações ::</h2>

        <IntegrationCard
          name="notion"
          description="conecte seu workspace para que o navegador possa criar e atualizar seus projetos, missões e a carta de navegação."
          connected={notionConnected}
          detail={(integrations as any)?.notion?.workspaceName}
          onConnect={() => { window.location.href = "/api/integrations/notion/connect"; }}
          onDisconnect={() => disconnect.mutate({ provider: "notion" })}
          isLoading={isLoading}
          connectLabel=":: conectar notion"
          learnMoreUrl="https://www.notion.so"
        />

        <IntegrationCard
          name="google agenda"
          description="conecte sua agenda para que o navegador possa ler suas estações e alocar as naves com inteligência."
          connected={googleConnected}
          detail={(integrations as any)?.google?.providerUserId}
          onConnect={() => { window.location.href = "/api/integrations/google/connect"; }}
          onDisconnect={() => disconnect.mutate({ provider: "google_calendar" })}
          isLoading={isLoading}
          connectLabel=":: conectar google agenda"
          learnMoreUrl="https://calendar.google.com"
        />
      </div>

      {/* Aparência */}
      <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-4">
        <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_ aparência ::</h2>
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <p className="text-sm text-foreground font-mono">
              {theme === "dark" ? ":: fundo escuro" : ":: fundo claro"}
            </p>
            <p className="text-xs text-muted-foreground font-mono">
              {theme === "dark" ? "modo espacial — padrão prysma" : "modo luz — alta legibilidade"}
            </p>
          </div>
          <button
            onClick={toggleTheme}
            className={cn(
              "relative w-14 h-7 rounded-full transition-colors duration-300 flex items-center",
              theme === "dark"
                ? "bg-prysma-core"
                : "bg-muted border border-space-border/40"
            )}
            aria-label="alternar tema"
          >
            <span
              className={cn(
                "absolute w-5 h-5 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm",
                theme === "dark"
                  ? "translate-x-8 bg-space-void"
                  : "translate-x-1 bg-white"
              )}
            >
              {theme === "dark" ? (
                <Moon className="w-3 h-3 text-prysma-bright" />
              ) : (
                <Sun className="w-3 h-3 text-amber-500" />
              )}
            </span>
          </button>
        </div>
      </div>

      {/* Plan info */}
      <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_&nbsp;plano atual ::</h2>
          <Badge
            variant="outline"
            className={cn(
              "lowercase font-mono",
              plan === "premium"
                ? "border-prysma-dim/50 text-prysma-bright"
                : "border-space-border text-muted-foreground"
            )}
          >
            {plan}
          </Badge>
        </div>
        <div className="space-y-2 text-sm">
          {plan === "essencial" ? (
            <>
              <PlanFeature included label="todos os protocolos de gestão" />
              <PlanFeature included label="4 sessões de modo expansão por semana" />
              <PlanFeature included label="10 sessões de modo foco por semana" />
              <PlanFeature included label="órbita semanal garantida" />
              <PlanFeature included={false} label="modo expansão livre (sem limite)" />
              <PlanFeature included={false} label="9 sessões de modo expansão por semana" />
            </>
          ) : (
            <>
              <PlanFeature included label="todos os protocolos de gestão" />
              <PlanFeature included label="9 sessões de modo expansão por semana" />
              <PlanFeature included label="15 sessões de modo foco por semana" />
              <PlanFeature included label="órbita semanal garantida" />
              <PlanFeature included label="modo expansão livre" />
            </>
          )}
        </div>
        {plan === "essencial" && (
          <button
            onClick={() => toast.info("upgrade para premium — disponível em breve.")}
            className="w-full px-4 py-2.5 rounded-xl bg-prysma-core hover:bg-prysma-bright text-space-void font-semibold text-sm transition-colors glow-prysma font-mono"
          >
            :: upgrade para premium — em breve ::
          </button>
        )}
      </div>

      {/* Gerenciamento de Dados (LGPD) */}
      <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-4">
        <div className="space-y-1">
          <h2 className="text-sm font-semibold text-foreground font-mono">{'}'}_&nbsp;gerenciamento de dados ::</h2>
          <p className="text-xs text-muted-foreground font-mono">:: controle total sobre seus dados de operação no prysma_. suas conexões com notion e google agenda não são afetadas.</p>
        </div>
        <div className="space-y-2">
          {/* Limpar chats */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-space-border/40 hover:border-destructive/30 hover:bg-destructive/5 transition-all text-left group">
                <MessageSquareOff size={16} className="text-muted-foreground group-hover:text-destructive/70 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground font-mono">limpar histórico de chats</p>
                  <p className="text-xs text-muted-foreground font-mono">apaga todas as sessões e mensagens com a prysma</p>
                </div>
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-popover border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 font-mono">
                  <AlertTriangle size={16} className="text-amber-400" />
                  confirmar operação
                </AlertDialogTitle>
                <AlertDialogDescription className="font-mono text-sm leading-relaxed">
                  tem certeza que deseja apagar todo o histórico de chats? esta operação é irreversível. seus dados no notion e google agenda serão preservados.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="font-mono text-xs">cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => clearChats.mutate()}
                  className="bg-destructive hover:bg-destructive/80 font-mono text-xs"
                >
                  sim, apagar chats
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Reiniciar prysmas */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-space-border/40 hover:border-destructive/30 hover:bg-destructive/5 transition-all text-left group">
                <RotateCcw size={16} className="text-muted-foreground group-hover:text-destructive/70 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground font-mono">reiniciar recontagem de prysmas</p>
                  <p className="text-xs text-muted-foreground font-mono">zera o contador de prysmas acumulados e o progresso de fases</p>
                </div>
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-popover border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 font-mono">
                  <AlertTriangle size={16} className="text-amber-400" />
                  confirmar operação
                </AlertDialogTitle>
                <AlertDialogDescription className="font-mono text-sm leading-relaxed">
                  tem certeza que deseja zerar seus prysmas e reiniciar o progresso de fases? esta operação é irreversível. seus dados no notion e google agenda serão preservados.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="font-mono text-xs">cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => resetPrysmas.mutate()}
                  className="bg-destructive hover:bg-destructive/80 font-mono text-xs"
                >
                  sim, reiniciar prysmas
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Reiniciar Prysma */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="w-full flex items-center gap-3 p-3 rounded-xl border border-space-border/40 hover:border-destructive/30 hover:bg-destructive/5 transition-all text-left group">
                <DatabaseBackup size={16} className="text-muted-foreground group-hover:text-destructive/70 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground font-mono">reiniciar prysma</p>
                  <p className="text-xs text-muted-foreground font-mono">volta ao estado inicial: apaga chats, prysmas, progresso e notas</p>
                </div>
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-popover border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 font-mono">
                  <AlertTriangle size={16} className="text-amber-400" />
                  confirmar operação
                </AlertDialogTitle>
                <AlertDialogDescription className="font-mono text-sm leading-relaxed">
                  tem certeza que deseja reiniciar o prysma_? todas as operações anteriores serão apagadas: histórico de chats, contagem de prysmas acumulados, progresso de fases, carta de navegação e notas. esta operação é irreversível. seus dados no notion e google agenda serão preservados.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="font-mono text-xs">cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => clearAll.mutate()}
                  className="bg-destructive hover:bg-destructive/80 font-mono text-xs"
                >
                  sim, reiniciar prysma
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Excluir conta — link discreto */}
        <div className="pt-2 border-t border-space-border/20">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="flex items-center gap-1.5 text-xs text-muted-foreground/50 hover:text-destructive/70 transition-colors font-mono">
                <UserX size={11} />
                excluir conta prysma
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-popover border-border">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 font-mono text-destructive">
                  <AlertTriangle size={16} className="text-destructive" />
                  excluir conta
                </AlertDialogTitle>
                <AlertDialogDescription className="font-mono text-sm leading-relaxed">
                  tem certeza que deseja excluir sua conta prysma_? todos os seus dados serão permanentemente removidos. esta operação é irreversível. seus dados no notion e google agenda serão preservados.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="font-mono text-xs">cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => deleteAccount.mutate()}
                  className="bg-destructive hover:bg-destructive/80 font-mono text-xs"
                >
                  sim, excluir minha conta
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}

function IntegrationCard({
  name, description, connected, detail, onConnect, onDisconnect, isLoading, connectLabel, learnMoreUrl,
}: {
  name: string; description: string; connected: boolean; detail?: string;
  onConnect: () => void; onDisconnect: () => void; isLoading?: boolean;
  connectLabel: string; learnMoreUrl: string;
}) {
  return (
    <div className="rounded-2xl border border-space-border/40 bg-space-dark/60 p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="font-medium text-foreground text-sm font-mono lowercase">{name}</span>
            {connected ? (
              <CheckCircle className="w-4 h-4 text-[oklch(0.70_0.18_155)]" />
            ) : (
              <XCircle className="w-4 h-4 text-muted-foreground" />
            )}
          </div>
          {detail && <p className="text-xs text-muted-foreground font-mono lowercase">{detail}</p>}
        </div>
        <a href={learnMoreUrl} target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-foreground transition-colors">
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed font-mono">{description}</p>
      {isLoading ? (
        <div className="h-8 rounded-lg bg-space-mid animate-pulse" />
      ) : connected ? (
        <button onClick={onDisconnect} className="px-3 py-1.5 rounded-lg border border-space-border text-muted-foreground hover:text-foreground hover:border-destructive/50 text-sm transition-colors font-mono lowercase">
          :: desconectar
        </button>
      ) : (
        <button onClick={onConnect} className="px-3 py-1.5 rounded-lg bg-prysma-core hover:bg-prysma-bright text-space-void text-sm font-medium transition-colors font-mono">
          {connectLabel}
        </button>
      )}
    </div>
  );
}

function PlanFeature({ included, label }: { included: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className={cn("w-4 h-4 rounded-full flex items-center justify-center shrink-0", included ? "bg-[oklch(0.70_0.18_155)]/20" : "bg-space-mid/40")}>
        <span className={cn("text-[10px]", included ? "text-[oklch(0.70_0.18_155)]" : "text-muted-foreground")}>
          {included ? "✓" : "×"}
        </span>
      </div>
      <span className={cn("text-sm font-mono lowercase", included ? "text-foreground" : "text-muted-foreground line-through")}>
        {label}
      </span>
    </div>
  );
}
