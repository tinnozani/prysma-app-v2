import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { TipTapEditor } from "@/components/TipTapEditor";
import { toast } from "sonner";
import {
  Plus,
  Trash2,
  Save,
  ChevronDown,
  ChevronRight,
  GripVertical,
  Map,
  Compass,
  Rocket,
  Target,
  Zap,
  BookOpen,
  Brain,
  Layers,
  Globe,
  Flame,
  Award,
  Sparkles,
  Settings,
  X,
  Star,
  Heart,
  Lightbulb,
  Eye,
  Shield,
  Crown,
  Diamond,
  Leaf,
  Mountain,
  Sun,
  Moon,
  Wind,
  Link,
  Terminal,
  ArrowLeft,
} from "lucide-react";

// ─── Ícones disponíveis (20+) ─────────────────────────────────────────────────
const AVAILABLE_ICONS = [
  { name: "Map", Icon: Map },
  { name: "Compass", Icon: Compass },
  { name: "Rocket", Icon: Rocket },
  { name: "Target", Icon: Target },
  { name: "Zap", Icon: Zap },
  { name: "BookOpen", Icon: BookOpen },
  { name: "Brain", Icon: Brain },
  { name: "Layers", Icon: Layers },
  { name: "Globe", Icon: Globe },
  { name: "Flame", Icon: Flame },
  { name: "Award", Icon: Award },
  { name: "Sparkles", Icon: Sparkles },
  { name: "Star", Icon: Star },
  { name: "Heart", Icon: Heart },
  { name: "Lightbulb", Icon: Lightbulb },
  { name: "Eye", Icon: Eye },
  { name: "Shield", Icon: Shield },
  { name: "Crown", Icon: Crown },
  { name: "Diamond", Icon: Diamond },
  { name: "Leaf", Icon: Leaf },
  { name: "Mountain", Icon: Mountain },
  { name: "Sun", Icon: Sun },
  { name: "Moon", Icon: Moon },
  { name: "Wind", Icon: Wind },
];

function IconPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const current = AVAILABLE_ICONS.find((i) => i.name === value);
  const CurrentIcon = current?.Icon ?? Map;

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 bg-space-dark border border-border rounded-lg text-sm text-foreground/80 hover:bg-space-surface transition-colors"
      >
        <CurrentIcon size={16} className="text-pink-400" />
        <span>{value}</span>
        <ChevronDown size={12} className="text-muted-foreground/70" />
      </button>
      {open && (
        <div className="absolute top-full left-0 mt-1 z-50 bg-space-dark border border-border rounded-xl p-2 grid grid-cols-6 gap-1 shadow-xl w-56">
          {AVAILABLE_ICONS.map(({ name, Icon }) => (
            <button
              key={name}
              type="button"
              onClick={() => { onChange(name); setOpen(false); }}
              title={name}
              className={`p-2 rounded-lg flex items-center justify-center transition-colors ${
                value === name ? "bg-pink-500/20 text-pink-400" : "text-muted-foreground hover:bg-space-dark hover:text-foreground"
              }`}
            >
              <Icon size={16} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Tipo de botão configurável ───────────────────────────────────────────────
type ButtonConfig = { label: string; type: "command" | "link"; value: string };

function ButtonEditor({
  buttons,
  onChange,
}: {
  buttons: ButtonConfig[];
  onChange: (b: ButtonConfig[]) => void;
}) {
  const [newLabel, setNewLabel] = useState("");
  const [newType, setNewType] = useState<"command" | "link">("command");
  const [newValue, setNewValue] = useState("");

  const add = () => {
    if (!newLabel.trim() || !newValue.trim()) return;
    onChange([...buttons, { label: newLabel.trim(), type: newType, value: newValue.trim() }]);
    setNewLabel(""); setNewValue("");
  };

  return (
    <div className="space-y-3">
      {/* Lista de botões existentes */}
      {buttons.map((btn, i) => (
        <div key={i} className="flex items-center gap-2 p-2 bg-space-dark/60 border border-border/50 rounded-lg">
          <div className="flex items-center gap-1.5 shrink-0">
            {btn.type === "command" ? <Terminal size={12} className="text-pink-400" /> : <Link size={12} className="text-blue-400" />}
            <span className="text-[10px] text-muted-foreground/70 font-mono">{btn.type}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-foreground font-medium truncate">{btn.label}</p>
            <p className="text-[10px] text-muted-foreground/70 truncate">{btn.value}</p>
          </div>
          <button
            type="button"
            onClick={() => onChange(buttons.filter((_, j) => j !== i))}
            className="shrink-0 p-1 text-muted-foreground/50 hover:text-red-400 transition-colors"
          >
            <X size={12} />
          </button>
        </div>
      ))}

      {/* Adicionar novo botão */}
      <div className="border border-border/50 rounded-lg p-3 space-y-2 bg-card/60">
        <p className="text-[10px] text-muted-foreground/70 font-mono uppercase tracking-wider">novo botão</p>
        <input
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          className="w-full px-2.5 py-1.5 bg-space-dark border border-border rounded-lg text-xs text-foreground focus:outline-none focus:border-pink-500/50"
          placeholder="texto do botão (ex: assistir aula)"
        />
        <div className="flex gap-2">
          <select
            value={newType}
            onChange={(e) => setNewType(e.target.value as "command" | "link")}
            className="px-2.5 py-1.5 bg-space-dark border border-border rounded-lg text-xs text-foreground focus:outline-none focus:border-pink-500/50"
          >
            <option value="command">comando (chat)</option>
            <option value="link">link externo</option>
          </select>
          <input
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && add()}
            className="flex-1 px-2.5 py-1.5 bg-space-dark border border-border rounded-lg text-xs text-foreground focus:outline-none focus:border-pink-500/50"
            placeholder={newType === "command" ? "ex: iniciar plano de vôo" : "https://..."}
          />
          <button
            type="button"
            onClick={add}
            className="px-3 py-1.5 bg-space-surface border border-border text-foreground/80 rounded-lg text-xs hover:bg-space-elevated transition-colors"
          >
            <Plus size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Editor de Subfase ────────────────────────────────────────────────────────
function SubphaseEditor({
  subphase,
  phaseId,
  onDeleted,
}: {
  subphase: {
    id: number;
    title: string;
    videoUrl?: string | null;
    content?: string | null;
    suggestedCommands?: unknown;
    buttons?: unknown;
  };
  phaseId: number;
  onDeleted: () => void;
}) {
  const [title, setTitle] = useState(subphase.title);
  const [videoUrl, setVideoUrl] = useState(subphase.videoUrl ?? "");
  const [content, setContent] = useState(subphase.content ?? "");
  const [commands, setCommands] = useState<string[]>(
    Array.isArray(subphase.suggestedCommands) ? (subphase.suggestedCommands as string[]) : []
  );
  const [buttons, setButtons] = useState<ButtonConfig[]>(
    Array.isArray(subphase.buttons) ? (subphase.buttons as ButtonConfig[]) : []
  );
  const [newCmd, setNewCmd] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState(false);

  const utils = trpc.useUtils();

  const updateMutation = trpc.flight.adminUpsertSubphase.useMutation({
    onSuccess: () => {
      utils.flight.getSubphases.invalidate({ phaseId });
      toast.success("subfase atualizada");
      setSaving(false);
    },
    onError: (err: { message: string }) => { toast.error(err.message); setSaving(false); },
  });

  const deleteMutation = trpc.flight.adminDeleteSubphase.useMutation({
    onSuccess: () => {
      utils.flight.getSubphases.invalidate({ phaseId });
      onDeleted();
      toast.success("subfase removida");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleSave = () => {
    setSaving(true);
    updateMutation.mutate({
      id: subphase.id,
      phaseId,
      title,
      videoUrl: videoUrl || undefined,
      content: content || undefined,
      suggestedCommands: commands,
      buttons,
    });
  };

  const addCommand = () => {
    if (newCmd.trim()) { setCommands([...commands, newCmd.trim()]); setNewCmd(""); }
  };

  return (
    <div className="border border-border/50 rounded-xl overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-2 p-3 text-left hover:bg-space-mid/30 transition-colors"
      >
        <GripVertical size={14} className="text-muted-foreground/50" />
        {expanded ? <ChevronDown size={14} className="text-muted-foreground/70" /> : <ChevronRight size={14} className="text-muted-foreground/70" />}
        <span className="text-sm text-foreground/80 flex-1">{title || "subfase sem título"}</span>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); deleteMutation.mutate({ id: subphase.id }); }}
          className="p-1 text-muted-foreground/50 hover:text-red-400 transition-colors"
        >
          <Trash2 size={12} />
        </button>
      </button>

      {expanded && (
        <div className="p-4 border-t border-border/50 space-y-4">
          {/* Título */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">título da subfase</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-space-dark border border-border rounded-lg text-sm text-foreground focus:outline-none focus:border-pink-500/50"
              placeholder="ex: assistir aula de boas-vindas"
            />
          </div>

          {/* URL do vídeo */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">url do vídeo (youtube, vimeo...)</label>
            <input
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              className="w-full px-3 py-2 bg-space-dark border border-border rounded-lg text-sm text-foreground focus:outline-none focus:border-pink-500/50"
              placeholder="https://youtube.com/watch?v=..."
            />
          </div>

          {/* Conteúdo complementar */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">conteúdo complementar (expandível para o usuário)</label>
            <div className="border border-border rounded-lg overflow-hidden bg-space-mid/30">
              <TipTapEditor
                content={content}
                onChange={setContent}
                placeholder="adicione textos, instruções, links..."
                minHeight="100px"
              />
            </div>
            <p className="text-[10px] text-muted-foreground/50 mt-1">o usuário verá um bloco expansível com o título da subfase</p>
          </div>

          {/* Botões configuráveis */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-2 block">botões de ação (comando ou link externo)</label>
            <ButtonEditor buttons={buttons} onChange={setButtons} />
          </div>

          {/* Comandos sugeridos (legado) */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">comandos rápidos (legado)</label>
            <div className="flex flex-wrap gap-2 mb-2">
              {commands.map((cmd, i) => (
                <span key={i} className="flex items-center gap-1 text-xs px-2 py-1 bg-space-surface border border-border text-foreground/80 rounded-lg">
                  :: {cmd}
                  <button type="button" onClick={() => setCommands(commands.filter((_, j) => j !== i))}>
                    <X size={10} className="text-muted-foreground/70 hover:text-red-400" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                value={newCmd}
                onChange={(e) => setNewCmd(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addCommand()}
                className="flex-1 px-3 py-1.5 bg-space-dark border border-border rounded-lg text-xs text-foreground focus:outline-none focus:border-pink-500/50"
                placeholder="ex: iniciar plano de vôo"
              />
              <button type="button" onClick={addCommand} className="px-3 py-1.5 bg-space-surface border border-border text-foreground/80 rounded-lg text-xs hover:bg-space-elevated transition-colors">
                <Plus size={12} />
              </button>
            </div>
          </div>

          {/* Salvar */}
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 bg-pink-500/20 border border-pink-500/40 text-pink-400 rounded-lg text-sm hover:bg-pink-500/30 transition-colors disabled:opacity-50"
          >
            <Save size={14} />
            {saving ? "salvando..." : "salvar subfase"}
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Editor de Fase ───────────────────────────────────────────────────────────
function PhaseEditor({
  phase,
  onDeleted,
}: {
  phase: {
    id: number;
    title: string;
    description?: string | null;
    icon: string;
    buttonLabel?: string | null;
    sortOrder: number;
  };
  onDeleted: () => void;
}) {
  const [title, setTitle] = useState(phase.title);
  const [description, setDescription] = useState(phase.description ?? "");
  const [icon, setIcon] = useState(phase.icon);
  const [buttonLabel, setButtonLabel] = useState(phase.buttonLabel ?? "iniciar fase");
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState(false);

  const utils = trpc.useUtils();
  const { data: subphases = [], refetch: refetchSubs } = trpc.flight.getSubphases.useQuery({ phaseId: phase.id });

  const updateMutation = trpc.flight.adminUpsertPhase.useMutation({
    onSuccess: () => {
      utils.flight.getPhases.invalidate();
      toast.success("fase atualizada");
      setSaving(false);
    },
    onError: (err: { message: string }) => { toast.error(err.message); setSaving(false); },
  });

  const deleteMutation = trpc.flight.adminDeletePhase.useMutation({
    onSuccess: () => {
      utils.flight.getPhases.invalidate();
      onDeleted();
      toast.success("fase removida");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const addSubphaseMutation = trpc.flight.adminUpsertSubphase.useMutation({
    onSuccess: () => { refetchSubs(); toast.success("subfase criada"); },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  const handleSave = () => {
    setSaving(true);
    updateMutation.mutate({
      id: phase.id,
      title,
      description: description || undefined,
      icon,
      buttonLabel,
      sortOrder: phase.sortOrder,
    });
  };

  return (
    <div className="border border-border/50 rounded-2xl overflow-hidden bg-card/60">
      {/* Header da fase */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 p-4 text-left hover:bg-space-mid/30 transition-colors"
      >
        <div className="w-8 h-8 rounded-lg bg-pink-500/20 border border-pink-500/30 flex items-center justify-center shrink-0">
          {(() => {
            const Ic = AVAILABLE_ICONS.find((i) => i.name === icon)?.Icon ?? Map;
            return <Ic size={14} className="text-pink-400" />;
          })()}
        </div>
        {expanded ? <ChevronDown size={14} className="text-muted-foreground/70" /> : <ChevronRight size={14} className="text-muted-foreground/70" />}
        <span className="text-sm font-medium text-foreground flex-1">{title || "fase sem título"}</span>
        <span className="text-xs text-muted-foreground/50 font-mono">{(subphases as unknown[]).length} subfases</span>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); deleteMutation.mutate({ id: phase.id }); }}
          className="p-1.5 text-muted-foreground/50 hover:text-red-400 transition-colors"
        >
          <Trash2 size={14} />
        </button>
      </button>

      {expanded && (
        <div className="p-4 border-t border-border/50 space-y-5">
          {/* Título */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">título da fase</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 bg-space-dark border border-border rounded-lg text-sm text-foreground focus:outline-none focus:border-pink-500/50"
              placeholder="ex: mapeando o horizonte"
            />
          </div>

          {/* Ícone */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">ícone ({AVAILABLE_ICONS.length} opções)</label>
            <IconPicker value={icon} onChange={setIcon} />
          </div>

          {/* Texto do botão rosa */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">texto do botão rosa (ex: "fase 1", "começar agora")</label>
            <input
              value={buttonLabel}
              onChange={(e) => setButtonLabel(e.target.value)}
              className="w-full px-3 py-2 bg-space-dark border border-border rounded-lg text-sm text-foreground focus:outline-none focus:border-pink-500/50"
              placeholder="ex: fase 1 · mapeamento"
            />
          </div>

          {/* Descrição */}
          <div>
            <label className="text-xs text-muted-foreground/70 mb-1 block">descrição da fase</label>
            <div className="border border-border rounded-lg overflow-hidden bg-space-mid/30">
              <TipTapEditor
                content={description}
                onChange={setDescription}
                placeholder="descreva o objetivo desta fase..."
                minHeight="80px"
              />
            </div>
          </div>

          {/* Salvar fase */}
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2 bg-pink-500/20 border border-pink-500/40 text-pink-400 rounded-lg text-sm hover:bg-pink-500/30 transition-colors disabled:opacity-50"
          >
            <Save size={14} />
            {saving ? "salvando..." : "salvar fase"}
          </button>

          {/* Subfases */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs text-muted-foreground/70">subfases</label>
              <button
                type="button"
                onClick={() =>
                  addSubphaseMutation.mutate({
                    phaseId: phase.id,
                    title: "nova subfase",
                    sortOrder: (subphases as unknown[]).length,
                  })
                }
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 bg-space-mid/50 border border-border/50 text-foreground/80 rounded-lg hover:bg-space-surface transition-colors"
              >
                <Plus size={12} />
                adicionar subfase
              </button>
            </div>
            <div className="space-y-2">
              {(subphases as { id: number; title: string; videoUrl?: string | null; content?: string | null; suggestedCommands?: unknown; buttons?: unknown }[]).map((sub) => (
                <SubphaseEditor
                  key={sub.id}
                  subphase={sub}
                  phaseId={phase.id}
                  onDeleted={refetchSubs}
                />
              ))}
              {(subphases as unknown[]).length === 0 && (
                <p className="text-xs text-muted-foreground/50 italic text-center py-3">
                  nenhuma subfase ainda — clique em "adicionar subfase"
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Página Admin ─────────────────────────────────────────────────────────────
export default function Admin() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: phases = [] } = trpc.flight.getPhases.useQuery();

  const createPhaseMutation = trpc.flight.adminUpsertPhase.useMutation({
    onSuccess: () => {
      utils.flight.getPhases.invalidate();
      toast.success("nova fase criada");
    },
    onError: (err: { message: string }) => toast.error(err.message),
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[oklch(0.07_0.015_260)] flex items-center justify-center">
        <div className="text-muted-foreground/70 text-sm">verificando acesso...</div>
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-8 text-center">
        <Settings size={48} className="text-muted-foreground/50 mb-4" />
        <h2 className="text-xl font-semibold text-muted-foreground mb-2">acesso restrito</h2>
        <p className="text-muted-foreground/50 text-sm">esta área é exclusiva para administradores do prysma_</p>
        <p className="text-muted-foreground/50 text-xs mt-3 font-mono">
          :: seu role atual: <span className="text-muted-foreground/70">{user?.role ?? "não autenticado"}</span>
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <button
          type="button"
          onClick={() => navigate("/plano-de-voo")}
          className="flex items-center gap-1.5 text-xs text-muted-foreground/60 hover:text-muted-foreground font-mono mb-4 transition-colors"
        >
          <ArrowLeft size={12} />
          voltar ao plano de vôo
        </button>
        <div className="flex items-center gap-3 mb-2">
          <Settings size={22} className="text-pink-400" />
          <h1 className="text-2xl font-bold text-foreground tracking-tight">painel admin</h1>
        </div>
        <p className="text-muted-foreground/70 text-sm">gerencie as fases e subfases do plano de vôo</p>
        <p className="text-muted-foreground/50 text-xs font-mono mt-1">:: logado como {user.name} · role: admin</p>
      </div>

      {/* Seção: Plano de Voo */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-foreground/80 uppercase tracking-wider">
            fases do plano de vôo
          </h2>
          <button
            type="button"
            onClick={() =>
              createPhaseMutation.mutate({
                title: "nova fase",
                icon: "Map",
                buttonLabel: "iniciar fase",
                sortOrder: (phases as unknown[]).length,
              })
            }
            className="flex items-center gap-2 px-4 py-2 bg-pink-500/20 border border-pink-500/40 text-pink-400 rounded-xl text-sm hover:bg-pink-500/30 transition-colors"
          >
            <Plus size={14} />
            adicionar fase
          </button>
        </div>

        <div className="space-y-3">
          {(phases as { id: number; title: string; description?: string | null; icon: string; buttonLabel?: string | null; sortOrder: number }[]).map((phase) => (
            <PhaseEditor
              key={phase.id}
              phase={phase}
              onDeleted={() => utils.flight.getPhases.invalidate()}
            />
          ))}
          {(phases as unknown[]).length === 0 && (
            <div className="text-center py-12 text-muted-foreground/50 text-sm">
              nenhuma fase cadastrada — clique em "adicionar fase" para começar
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
