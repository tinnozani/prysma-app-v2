import { cn } from "@/lib/utils";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

// ─── Helpers de trava temporal (revisão trimestral) ────────────────────────────────────────────
function getRevisaoUnlockDate(createdAt: string | Date): Date {
  const d = new Date(createdAt);
  d.setMonth(d.getMonth() + 3);
  return d;
}
function isRevisaoUnlocked(createdAt: string | Date): boolean {
  return new Date() >= getRevisaoUnlockDate(createdAt);
}
function formatDate(date: Date): string {
  return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "2-digit" });
}

// ─── Categorias exatas do Notion ──────────────────────────────────────────────
type Category = "todos" | "início" | "rota" | "ação" | "revisão";

const CATEGORY_CONFIG: Record<Category, { label: string; emoji: string; color: string; border: string; text: string; activeBg: string }> = {
  todos:   { label: "todos",   emoji: "",   color: "bg-muted/60",        border: "border-border/50",         text: "text-muted-foreground", activeBg: "bg-prysma-faint border-prysma-dim/50 text-prysma-bright" },
  início:  { label: "início",  emoji: "🏁", color: "bg-prysma-faint/60", border: "border-prysma-dim/30",     text: "text-prysma-bright",    activeBg: "bg-prysma-faint border-prysma-dim/60 text-prysma-bright" },
  rota:    { label: "rota",    emoji: "🧭", color: "bg-haiku-faint/60",  border: "border-haiku-glow/30",    text: "text-haiku-bright",     activeBg: "bg-haiku-faint border-haiku-glow/60 text-haiku-bright" },
  ação:    { label: "ação",    emoji: "⚡", color: "bg-sonnet-faint/60", border: "border-sonnet-glow/30",   text: "text-sonnet-bright",    activeBg: "bg-sonnet-faint border-sonnet-glow/60 text-sonnet-bright" },
  revisão: { label: "revisão", emoji: "🔭", color: "bg-haiku-faint/40",  border: "border-haiku-glow/20",    text: "text-haiku-bright/80",  activeBg: "bg-haiku-faint border-haiku-glow/50 text-haiku-bright" },
};

// ─── Protocolos com dados exatos do template Notion ──────────────────────────
// "Atualizar Template Notion" foi descontinuado e não aparece aqui.
const PROTOCOLS = [
  // ── INÍCIO ──
  {
    id: "01",
    name: "Gerar Carta de Navegação",
    gatilho: "//gerar carta de navegação prysma",
    category: "início" as Category,
    objective: "Criar o \"Ponto Zero\" do sistema, mapeando seu Perfil de Navegador e o Contexto atual via entrevista guiada.",
    needs: "Estar disposto a responder sobre seus objetivos de 12 meses, o que drena sua energia e como você reage em situações adversas.",
    result: "Um documento de identidade estratégico definindo suas Forças, Fragilidades e Travas de Governança.",
    duration: "45–90 min",
    oneTime: true,
    model: "sonnet",
  },
  {
    id: "00",
    name: "Onboarding & Dúvidas",
    gatilho: "//como começar na prysma",
    category: "início" as Category,
    objective: "Apresentação executiva e central de esclarecimentos sobre a metodologia Prysma.",
    needs: "Curiosidade sobre como o sistema funciona e disposição para fazer perguntas.",
    result: "Clareza sobre os conceitos, estrutura e próximos passos dentro do Prysma.",
    duration: "10–30 min",
    oneTime: false,
    model: "sonnet",
  },
  // ── ROTA ──
  {
    id: "02",
    name: "Posicionamento de Projetos",
    gatilho: "//posicionar projetos nas órbitas",
    category: "rota" as Category,
    objective: "Organizar e priorizar todos os seus projetos dentro da Tríade, Ciclos e Constelação de Ideias.",
    needs: "Uma lista completa (dump mental) de tudo que está ativo ou pendente na sua mente hoje.",
    result: "Um mapa sistêmico claro separando o que estará na Tríade (importância), Ciclo de Sustentação (órbitas de velocidade reduzida) ou Constelação (para um momento oportuno).",
    duration: "20–40 min",
    oneTime: false,
    model: "sonnet",
  },
  {
    id: "06",
    name: "Mapear Rota de Projeto",
    gatilho: "//mapear rota de projeto",
    category: "rota" as Category,
    objective: "Criar um roadmap por telemetria reversa até um Horizonte definido.",
    needs: "Um projeto específico em mente e clareza sobre o resultado esperado.",
    result: "Um mapa de rota com marcos, dependências e estimativas de tempo até o Horizonte.",
    duration: "30–60 min",
    oneTime: false,
    model: "sonnet",
    premiumOnly: true,
  },
  {
    id: "07",
    name: "Auditoria do Núcleo Vital",
    gatilho: "//auditar tempo do meu núcleo vital",
    category: "rota" as Category,
    objective: "Auditar os inputs de TUD com ceticismo gentil, identificando o viés do otimismo.",
    needs: "Acesso à sua agenda e clareza sobre seus compromissos fixos da semana.",
    result: "Uma leitura honesta do seu Tempo Útil Disponível real, sem ilusões.",
    duration: "15–25 min",
    oneTime: false,
    model: "haiku",
  },
  // ── AÇÃO ──
  {
    id: "03",
    name: "Análise de Sinastria Criativa",
    gatilho: "//analisar sinastria criativa",
    category: "ação" as Category,
    objective: "Validar a aderência de uma ideia / projeto específico ao seu Núcleo Vital antes de gastar energia nela.",
    needs: "Um projeto ou oportunidade específica em mente e clareza sobre o retorno esperado.",
    result: "Um veredito estratégico (Conjunção, Quadratura, etc.) indicando se deve avançar ou pausar.",
    duration: "20–40 min",
    oneTime: false,
    model: "sonnet",
  },
  {
    id: "04",
    name: "Duelo de Sinastria",
    gatilho: "//comparar sinastrias",
    category: "ação" as Category,
    objective: "Comparar 2 opções valiosas e decidir o timing: uma entra agora (Tríade) e outra espera.",
    needs: "Duas opções concretas em conflito de prioridade.",
    result: "Uma decisão clara sobre qual projeto entra na Tríade agora e qual vai para os Ciclos.",
    duration: "20–35 min",
    oneTime: false,
    model: "sonnet",
  },
  {
    id: "05",
    name: "Diagnosticar Energia de Projeto",
    gatilho: "//diagnosticar energia de um projeto",
    category: "ação" as Category,
    objective: "Detectar o estado operacional dominante de um projeto (🌀 Concepção / ⚡ Tração / 🫀 Cadência).",
    needs: "Um projeto específico e disposição para uma análise honesta do seu estado atual.",
    result: "Um diagnóstico do estado do projeto e recomendações de próximos passos alinhados à energia.",
    duration: "15–30 min",
    oneTime: false,
    model: "haiku",
  },
  // ── REVISÃO ──
  {
    id: "08",
    name: "Check-in Semanal",
    gatilho: "//iniciar check-in da semana",
    category: "revisão" as Category,
    objective: "Fechar o ciclo anterior e desenhar a próxima semana com realismo de TUD.",
    needs: "Disposição para uma revisão honesta da semana que passou e clareza sobre a próxima.",
    result: "Um plano semanal realista com missões alocadas, energia distribuída e agenda sincronizada.",
    duration: "20–30 min",
    oneTime: false,
    model: "sonnet",
    guaranteed: true,
  },
  {
    id: "14",
    name: "Escolher Missões da Semana",
    gatilho: "//escolher missões da semana",
    category: "revisão" as Category,
    objective: "Selecionar as missões mais estratégicas para a semana respeitando o TUD e o equilíbrio de energia.",
    needs: "Lista de missões pendentes e clareza sobre o TUD disponível.",
    result: "Uma seleção curada de missões para a semana, distribuídas por Campo de Energia.",
    duration: "15–25 min",
    oneTime: false,
    model: "haiku",
  },
  {
    id: "09",
    name: "Revisão Trimestral",
    gatilho: "//iniciar revisão trimestral",
    category: "revisão" as Category,
    objective: "Balanço macro de 90 dias + reconfiguração segura da Tríade.",
    needs: "Disposição para um olhar honesto sobre os últimos 3 meses.",
    result: "Um diagnóstico dos últimos 90 dias com celebrações, aprendizados e reconfigurações da Tríade.",
    duration: "60–90 min",
    oneTime: false,
    model: "sonnet",
  },
  {
    id: "13",
    name: "Direcionar 2º Cérebro",
    gatilho: "//direcionar 2º cérebro",
    category: "revisão" as Category,
    objective: "Ler o conteúdo do bloco de notas rápidas e classificar cada item no lugar certo do sistema.",
    needs: "Notas acumuladas no 2º Cérebro aguardando triagem.",
    result: "Todas as notas classificadas: Naves criadas, Missões alocadas ou Constelação alimentada.",
    duration: "10–20 min",
    oneTime: false,
    model: "haiku",
  },
];

const CATEGORIES: Category[] = ["todos", "início", "rota", "ação", "revisão"];

export default function Biblioteca() {
  const [selected, setSelected] = useState<typeof PROTOCOLS[0] | null>(null);
  const [filter, setFilter] = useState<Category>("todos");
  const { user } = useAuth();

  // Trava temporal: revisão trimestral só desbloqueia 3 meses após createdAt
  const revisaoLocked = user?.createdAt ? !isRevisaoUnlocked(user.createdAt) : true;
  const revisaoUnlockDate = user?.createdAt
    ? formatDate(getRevisaoUnlockDate(user.createdAt))
    : undefined;

  const filtered = filter === "todos" ? PROTOCOLS : PROTOCOLS.filter((p) => p.category === filter);

  return (
    <div className="p-4 md:p-8 space-y-6 fade-in-up">
      <div className="space-y-1">
        <h1 className="text-2xl font-semibold text-foreground font-mono">
          {"}"}_  biblioteca de comandos
        </h1>
        <p className="text-sm text-muted-foreground font-mono">
          {PROTOCOLS.length} protocolos disponíveis ::
        </p>
      </div>

      {/* Category filter — categorias do Notion */}
      <div className="flex gap-2 flex-wrap">
        {CATEGORIES.map((cat) => {
          const cfg = CATEGORY_CONFIG[cat];
          const isActive = filter === cat;
          return (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={cn(
                "px-3 py-1.5 rounded-full text-xs font-medium transition-all font-mono lowercase border",
                isActive
                  ? cfg.activeBg
                  : `${cfg.color} ${cfg.border} ${cfg.text} hover:opacity-80`
              )}
            >
              {cfg.emoji && <span className="mr-1">{cfg.emoji}</span>}
              {cfg.label}
            </button>
          );
        })}
      </div>

      {/* Protocol grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map((protocol) => {
          const isRevisao = protocol.id === "09";
          const locked = isRevisao && revisaoLocked;
          return (
            <ProtocolCard
              key={protocol.id}
              protocol={protocol}
              locked={locked}
              unlockDate={isRevisao ? revisaoUnlockDate : undefined}
              onClick={() => {
                if (locked) {
                  toast.info(
                    revisaoUnlockDate
                      ? `continue operando o prysma para desbloquear a revisão trimestral e ganhar 30 prysmas :: disponível em ${revisaoUnlockDate}`
                      : "continue operando o prysma para desbloquear a revisão trimestral e ganhar 30 prysmas",
                    { duration: 4000 }
                  );
                  return;
                }
                setSelected(protocol);
              }}
            />
          );
        })}
      </div>

      {/* Protocol detail dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        {selected && (
          <DialogContent className="bg-popover border-border max-w-md">
            <DialogHeader>
              <div className="flex items-center gap-2 mb-2">
                <CategoryBadge category={selected.category} />
                {selected.guaranteed && (
                  <Badge variant="outline" className="text-[10px] border-haiku-glow/40 text-haiku-bright font-mono">
                    :: garantido
                  </Badge>
                )}
                {selected.premiumOnly && (
                  <Badge variant="outline" className="text-[10px] border-prysma-dim/40 text-prysma-bright font-mono">
                    :: premium
                  </Badge>
                )}
                {selected.oneTime && (
                  <Badge variant="outline" className="text-[10px] border-space-border/60 text-muted-foreground font-mono">
                    :: único
                  </Badge>
                )}
              </div>
              <DialogTitle className="text-foreground text-lg font-mono lowercase">
                {selected.name}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4 mt-1">
              {/* Objetivo */}
              <div className="rounded-xl bg-haiku-faint/30 border border-haiku-glow/20 p-3 space-y-1">
                <p className="text-xs font-mono text-haiku-bright/80">objetivo ::</p>
                <p className="text-sm text-foreground leading-relaxed">{selected.objective}</p>
              </div>
              {/* O que é necessário */}
              <div className="rounded-xl bg-haiku-faint/40 border border-haiku-glow/20 p-3 space-y-1">
                <p className="text-xs font-mono text-haiku-bright/80">o que é necessário ::</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{selected.needs}</p>
              </div>
              {/* Resultado final */}
              <div className="rounded-xl bg-prysma-faint/40 border border-prysma-dim/20 p-3 space-y-1">
                <p className="text-xs font-mono text-prysma-bright/80">resultado final ::</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{selected.result}</p>
              </div>

              <div className="flex items-center justify-between text-sm pt-1">
                <span className="text-muted-foreground font-mono text-xs">duração estimada</span>
                <span className="text-foreground font-medium font-mono text-xs">{selected.duration}</span>
              </div>
            </div>

            <div className="flex gap-3 mt-4">
              <Link
                href={`/chat?protocol=${selected.id}`}
                onClick={() => setSelected(null)}
                className={cn(
                  "flex-1 inline-flex items-center justify-center px-4 py-2 rounded-lg text-sm font-medium transition-colors font-mono lowercase",
                  selected.premiumOnly
                    ? "bg-muted/60 text-muted-foreground cursor-not-allowed pointer-events-none"
                    : "bg-prysma-core hover:bg-prysma-bright text-space-void"
                )}
              >
                :: iniciar sessão
              </Link>
              <Button
                variant="outline"
                onClick={() => setSelected(null)}
                className="border-border text-muted-foreground hover:text-foreground font-mono lowercase"
              >
                fechar
              </Button>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}

function ProtocolCard({
  protocol,
  onClick,
  locked = false,
  unlockDate,
}: {
  protocol: typeof PROTOCOLS[0];
  onClick: () => void;
  locked?: boolean;
  unlockDate?: string;
}) {
  const cfg = CATEGORY_CONFIG[protocol.category];

  return (
    <button
      onClick={onClick}
      title={locked ? "continue operando o prysma para desbloquear a revisão trimestral e ganhar 30 prysmas" : undefined}
      className={cn(
        "text-left p-4 rounded-2xl border transition-all duration-200 space-y-3",
        locked
          ? "bg-muted/30 border-border/30 opacity-60 cursor-not-allowed"
          : "bg-card-widget border-border/60 hover:border-prysma-dim/40 hover:bg-muted/60"
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <CategoryBadge category={protocol.category} />
        <div className="flex gap-1">
          {locked && (
            <Lock className="w-3.5 h-3.5 text-muted-foreground/40" />
          )}
          {!locked && protocol.guaranteed && (
            <Badge variant="outline" className="text-[10px] border-haiku-glow/40 text-haiku-bright px-1.5 font-mono">
              ✦
            </Badge>
          )}
          {!locked && protocol.premiumOnly && (
            <Badge variant="outline" className="text-[10px] border-prysma-dim/40 text-prysma-bright px-1.5 font-mono">
              ★
            </Badge>
          )}
          {!locked && protocol.oneTime && (
            <Badge variant="outline" className="text-[10px] border-space-border/50 text-muted-foreground px-1.5 font-mono">
              ①
            </Badge>
          )}
        </div>
      </div>
      <div>
        <p className={cn("text-sm font-semibold font-mono lowercase", locked ? "text-muted-foreground/50" : "text-foreground")}>{protocol.name}</p>
        <p className="text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed">{locked ? "disponível após 3 meses de uso do prysma" : protocol.objective}</p>
      </div>
      <div className="flex items-center justify-between">
        {locked && unlockDate ? (
          <span className="text-[10px] text-muted-foreground/50 font-mono">:: disponível em {unlockDate}</span>
        ) : (
          <>
            <span className="text-xs text-muted-foreground font-mono">{protocol.duration}</span>
            <span className="text-xs text-prysma-bright/60 font-mono">:: iniciar →</span>
          </>
        )}
      </div>
    </button>
  );
}

function CategoryBadge({ category }: { category: Category }) {
  const cfg = CATEGORY_CONFIG[category];
  return (
    <span className={cn(
      "text-[10px] font-medium px-2 py-0.5 rounded-full border font-mono lowercase",
      cfg.color, cfg.border, cfg.text
    )}>
      {cfg.emoji && <span className="mr-1">{cfg.emoji}</span>}
      {cfg.label}
    </span>
  );
}
