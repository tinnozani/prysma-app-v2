import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { PrysmaLayout } from "./components/PrysmaLayout";
import Home from "./pages/Home";
import Chat from "./pages/Chat";
import Biblioteca from "./pages/Biblioteca";
import Perfil from "./pages/Perfil";
import Onboarding from "./pages/Onboarding";
import PlanoDeVoo from "./pages/PlanoDeVoo";
import MissoesDaSemana from "./pages/MissoesDaSemana";
import CheckinSemanal from "./pages/CheckinSemanal";
import RevisaoTrimestral from "./pages/RevisaoTrimestral";
import Consultoria from "./pages/Consultoria";
import CartaDeNavegacao from "./pages/CartaDeNavegacao";
import Admin from "./pages/Admin";
import Cerebro from "./pages/Cerebro";

function Router() {
  return (
    <Switch>
      {/* Onboarding fora do layout principal */}
      <Route path="/onboarding" component={Onboarding} />
      {/* Rotas principais com layout */}
      <Route>
        <PrysmaLayout>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/chat" component={Chat} />
            <Route path="/biblioteca" component={Biblioteca} />
            <Route path="/perfil" component={Perfil} />
            <Route path="/plano-de-voo" component={PlanoDeVoo} />
            <Route path="/missoes" component={MissoesDaSemana} />
            <Route path="/checkin" component={CheckinSemanal} />
            <Route path="/revisao" component={RevisaoTrimestral} />
            <Route path="/consultoria" component={Consultoria} />
            <Route path="/carta" component={CartaDeNavegacao} />
            <Route path="/admin" component={Admin} />
            <Route path="/cerebro" component={Cerebro} />
            <Route path="/404" component={NotFound} />
            <Route component={NotFound} />
          </Switch>
        </PrysmaLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable={true}>
        <TooltipProvider>
          <Toaster
            theme="system"
            toastOptions={{
              style: {
                background: "oklch(0.13 0.025 256)",
                border: "1px solid oklch(0.28 0.020 248)",
                color: "oklch(0.95 0.005 250)",
              },
            }}
          />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
