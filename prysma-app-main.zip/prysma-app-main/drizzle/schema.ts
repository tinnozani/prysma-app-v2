import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  json,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  plan: mysqlEnum("plan", ["essencial", "premium"]).default("essencial").notNull(),
  onboardingCompleted: boolean("onboardingCompleted").default(false).notNull(),
  cartaDeNavegacaoCompleted: boolean("cartaDeNavegacaoCompleted").default(false).notNull(),
  avatarUrl: text("avatarUrl"),
  prysmasTotal: int("prysmasTotal").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── User Integrations (Notion + Google Calendar) ─────────────────────────────
export const userIntegrations = mysqlTable("user_integrations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  provider: mysqlEnum("provider", ["notion", "google_calendar"]).notNull(),
  accessToken: text("accessToken").notNull(),
  refreshToken: text("refreshToken"),
  tokenExpiresAt: timestamp("tokenExpiresAt"),
  workspaceId: varchar("workspaceId", { length: 255 }),
  workspaceName: varchar("workspaceName", { length: 255 }),
  templatePageId: varchar("templatePageId", { length: 255 }),
  providerUserId: varchar("providerUserId", { length: 255 }),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserIntegration = typeof userIntegrations.$inferSelect;
export type InsertUserIntegration = typeof userIntegrations.$inferInsert;

// ─── Weekly Credits (Cristais de Energia) ─────────────────────────────────────
export const weeklyCredits = mysqlTable("weekly_credits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  weekStart: timestamp("weekStart").notNull(),
  weekEnd: timestamp("weekEnd").notNull(),
  // Sonnet credits
  sonnetTotal: int("sonnetTotal").notNull().default(4),
  sonnetUsed: int("sonnetUsed").notNull().default(0),
  sonnetOrbitaUsed: boolean("sonnetOrbitaUsed").notNull().default(false),
  // Haiku credits
  haikuTotal: int("haikuTotal").notNull().default(10),
  haikuUsed: int("haikuUsed").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WeeklyCredits = typeof weeklyCredits.$inferSelect;
export type InsertWeeklyCredits = typeof weeklyCredits.$inferInsert;

// ─── Chat Sessions ─────────────────────────────────────────────────────────────
export const chatSessions = mysqlTable("chat_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  protocolId: varchar("protocolId", { length: 64 }),
  protocolName: varchar("protocolName", { length: 255 }),
  title: varchar("title", { length: 500 }),
  model: mysqlEnum("model", ["sonnet", "haiku"]).notNull().default("haiku"),
  status: mysqlEnum("status", ["active", "archived", "escalated"]).notNull().default("active"),
  creditsConsumed: int("creditsConsumed").notNull().default(0),
  notionPageId: varchar("notionPageId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  archivedAt: timestamp("archivedAt"),
});

export type ChatSession = typeof chatSessions.$inferSelect;
export type InsertChatSession = typeof chatSessions.$inferInsert;

// ─── Chat Messages ─────────────────────────────────────────────────────────────
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  model: mysqlEnum("model", ["sonnet", "haiku"]),
  tokensUsed: int("tokensUsed"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

// ─── Carta de Navegação ──────────────────────────────────────────────────────────
export const cartaDeNavegacao = mysqlTable("carta_de_navegacao", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  // Tríade
  identidade: text("identidade"),        // quem você é como criativo
  missaoVida: text("missaoVida"),         // missão de vida
  visaoFuturo: text("visaoFuturo"),       // visão de futuro
  // TUD
  tudUrgente: json("tudUrgente"),         // lista de urgentes
  tudImportante: json("tudImportante"),   // lista de importantes
  tudDesejavel: json("tudDesejavel"),     // lista de desejáveis
  // Projetos ativos (Tríade de projetos)
  projetoFoco: text("projetoFoco"),       // projeto principal
  projetoSecundario: text("projetoSecundario"),
  projetoTerciario: text("projetoTerciario"),
  // Energia e ritmo
  nivelEnergia: mysqlEnum("nivelEnergia", ["baixo", "medio", "alto"]).default("medio"),
  ritmoIdeal: text("ritmoIdeal"),         // como a pessoa trabalha melhor
  // Metadados
  rawAnswers: json("rawAnswers"),         // respostas brutas do onboarding
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CartaDeNavegacao = typeof cartaDeNavegacao.$inferSelect;
export type InsertCartaDeNavegacao = typeof cartaDeNavegacao.$inferInsert;

// ─── Protocol History ──────────────────────────────────────────────────────────
export const protocolHistory = mysqlTable("protocol_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sessionId: int("sessionId"),
  protocolId: varchar("protocolId", { length: 64 }).notNull(),
  protocolName: varchar("protocolName", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["started", "completed", "abandoned"]).notNull().default("started"),
  resultSummary: text("resultSummary"),
  notionPageId: varchar("notionPageId", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type ProtocolHistory = typeof protocolHistory.$inferSelect;
export type InsertProtocolHistory = typeof protocolHistory.$inferInsert;

// ─── User Progress (Gamificação — Fases de Implementação) ─────────────────────
export const userProgress = mysqlTable("user_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  // Fase atual desbloqueada (0 = nenhuma, 1-5 = fases do Plano de Voo)
  currentPhase: int("currentPhase").default(0).notNull(),
  // Subfases concluídas como JSON array de strings (ex: ["plano_voo", "missoes"])
  completedPhases: json("completedPhases").$type<string[]>().default([]).notNull(),
  // Prysmas acumulados neste progresso
  prysmasEarned: int("prysmasEarned").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProgress = typeof userProgress.$inferSelect;

// ─── 2º Cérebro (Captura Rápida) ─────────────────────────────────────────────
export const brainNotes = mysqlTable("brain_notes", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  content: text("content").notNull(),
  // tipo: "note" (texto livre), "checklist" (item com checkbox), "bullet" (marcador)
  type: mysqlEnum("type", ["note", "checklist", "bullet"]).default("note").notNull(),
  checked: boolean("checked").default(false).notNull(), // para tipo checklist
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BrainNote = typeof brainNotes.$inferSelect;
export type InsertBrainNote = typeof brainNotes.$inferInsert;
export type InsertUserProgress = typeof userProgress.$inferInsert;

// ─── Plano de Vôo — Fases (editadas pelo admin) ─────────────────────────────────────
export const flightPhases = mysqlTable("flight_phases", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 64 }).default("Map").notNull(), // nome do ícone Lucide
  buttonLabel: varchar("buttonLabel", { length: 255 }).default("iniciar fase").notNull(), // texto do botão rosa
  sortOrder: int("sortOrder").default(0).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FlightPhase = typeof flightPhases.$inferSelect;
export type InsertFlightPhase = typeof flightPhases.$inferInsert;

// ─── Plano de Vôo — Subfases ─────────────────────────────────────────────────────
export const flightSubphases = mysqlTable("flight_subphases", {
  id: int("id").autoincrement().primaryKey(),
  phaseId: int("phaseId").notNull(), // FK para flight_phases.id
  title: varchar("title", { length: 255 }).notNull(),
  videoUrl: text("videoUrl"),          // URL YouTube/Vimeo
  content: text("content"),            // Rich text (HTML do TipTap)
  suggestedCommands: json("suggestedCommands").$type<string[]>().default([]), // botões de comando
  buttons: json("buttons").$type<{ label: string; type: "command" | "link"; value: string }[]>().default([]), // botões configuráveis
  sortOrder: int("sortOrder").default(0).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FlightSubphase = typeof flightSubphases.$inferSelect;
export type InsertFlightSubphase = typeof flightSubphases.$inferInsert;

// ─── Plano de Vôo — Progresso do Usuário por Subfase ──────────────────────────────
export const userPhaseProgress = mysqlTable("user_phase_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phaseId: int("phaseId").notNull(),
  subphaseId: int("subphaseId"),       // null = fase inteira concluída
  completedAt: timestamp("completedAt").defaultNow().notNull(),
  prysmasAwarded: int("prysmasAwarded").default(0).notNull(),
});

export type UserPhaseProgress = typeof userPhaseProgress.$inferSelect;
export type InsertUserPhaseProgress = typeof userPhaseProgress.$inferInsert;
