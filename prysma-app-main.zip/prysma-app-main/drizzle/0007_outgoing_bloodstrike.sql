ALTER TABLE `flight_phases` ADD `buttonLabel` varchar(255) DEFAULT 'iniciar fase' NOT NULL;--> statement-breakpoint
ALTER TABLE `flight_subphases` ADD `buttons` json DEFAULT ('[]');