CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`model` enum('sonnet','haiku'),
	`tokensUsed` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`protocolId` varchar(64),
	`protocolName` varchar(255),
	`title` varchar(500),
	`model` enum('sonnet','haiku') NOT NULL DEFAULT 'haiku',
	`status` enum('active','archived','escalated') NOT NULL DEFAULT 'active',
	`creditsConsumed` int NOT NULL DEFAULT 0,
	`notionPageId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`archivedAt` timestamp,
	CONSTRAINT `chat_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `protocol_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sessionId` int,
	`protocolId` varchar(64) NOT NULL,
	`protocolName` varchar(255) NOT NULL,
	`status` enum('started','completed','abandoned') NOT NULL DEFAULT 'started',
	`resultSummary` text,
	`notionPageId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `protocol_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_integrations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`provider` enum('notion','google_calendar') NOT NULL,
	`accessToken` text NOT NULL,
	`refreshToken` text,
	`tokenExpiresAt` timestamp,
	`workspaceId` varchar(255),
	`workspaceName` varchar(255),
	`templatePageId` varchar(255),
	`providerUserId` varchar(255),
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_integrations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `weekly_credits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`weekStart` timestamp NOT NULL,
	`weekEnd` timestamp NOT NULL,
	`sonnetTotal` int NOT NULL DEFAULT 4,
	`sonnetUsed` int NOT NULL DEFAULT 0,
	`sonnetOrbitaUsed` boolean NOT NULL DEFAULT false,
	`haikuTotal` int NOT NULL DEFAULT 10,
	`haikuUsed` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `weekly_credits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `plan` enum('essencial','premium') DEFAULT 'essencial' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `onboardingCompleted` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `cartaDeNavegacaoCompleted` boolean DEFAULT false NOT NULL;