CREATE TABLE `flight_phases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`icon` varchar(64) NOT NULL DEFAULT 'Map',
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `flight_phases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `flight_subphases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`phaseId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`videoUrl` text,
	`content` text,
	`suggestedCommands` json DEFAULT ('[]'),
	`sortOrder` int NOT NULL DEFAULT 0,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `flight_subphases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_phase_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phaseId` int NOT NULL,
	`subphaseId` int,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	`prysmasAwarded` int NOT NULL DEFAULT 0,
	CONSTRAINT `user_phase_progress_id` PRIMARY KEY(`id`)
);
