import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  cartaDeNavegacao,
  chatMessages,
  chatSessions,
  InsertUser,
  protocolHistory,
  userIntegrations,
  brainNotes,
  userProgress,
  users,
  weeklyCredits,
  flightPhases,
  flightSubphases,
  userPhaseProgress,
  type InsertFlightPhase,
  type InsertFlightSubphase,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;

    for (const field of textFields) {
      const value = user[field];
      if (value === undefined) continue;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    }

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserAvatar(userId: number, avatarUrl: string | null) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ avatarUrl }).where(eq(users.id, userId));
}

// ─── User Integrations ────────────────────────────────────────────────────────
export async function getIntegration(userId: number, provider: "notion" | "google_calendar") {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(userIntegrations)
    .where(and(eq(userIntegrations.userId, userId), eq(userIntegrations.provider, provider)))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertIntegration(data: {
  userId: number;
  provider: "notion" | "google_calendar";
  accessToken: string;
  refreshToken?: string;
  tokenExpiresAt?: Date;
  workspaceId?: string;
  workspaceName?: string;
  templatePageId?: string;
  providerUserId?: string;
  metadata?: Record<string, unknown>;
}) {
  const db = await getDb();
  if (!db) return;
  const existing = await getIntegration(data.userId, data.provider);
  if (existing) {
    await db
      .update(userIntegrations)
      .set({
        accessToken: data.accessToken,
        refreshToken: data.refreshToken ?? null,
        tokenExpiresAt: data.tokenExpiresAt ?? null,
        workspaceId: data.workspaceId ?? existing.workspaceId,
        workspaceName: data.workspaceName ?? existing.workspaceName,
        templatePageId: data.templatePageId ?? existing.templatePageId,
        providerUserId: data.providerUserId ?? existing.providerUserId,
        metadata: data.metadata ?? existing.metadata,
      })
      .where(eq(userIntegrations.id, existing.id));
  } else {
    await db.insert(userIntegrations).values({
      userId: data.userId,
      provider: data.provider,
      accessToken: data.accessToken,
      refreshToken: data.refreshToken ?? null,
      tokenExpiresAt: data.tokenExpiresAt ?? null,
      workspaceId: data.workspaceId ?? null,
      workspaceName: data.workspaceName ?? null,
      templatePageId: data.templatePageId ?? null,
      providerUserId: data.providerUserId ?? null,
      metadata: data.metadata ?? null,
    });
  }
}

export async function deleteIntegration(userId: number, provider: "notion" | "google_calendar") {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(userIntegrations)
    .where(and(eq(userIntegrations.userId, userId), eq(userIntegrations.provider, provider)));
}

// ─── Weekly Credits ───────────────────────────────────────────────────────────
function getWeekBoundaries(date: Date = new Date()): { weekStart: Date; weekEnd: Date } {
  const d = new Date(date);
  const day = d.getDay(); // 0 = Sunday
  const diff = d.getDate() - day;
  const weekStart = new Date(d.setDate(diff));
  weekStart.setHours(0, 0, 0, 0);
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);
  return { weekStart, weekEnd };
}

export async function getOrCreateWeeklyCredits(userId: number, plan: "essencial" | "premium") {
  const db = await getDb();
  if (!db) return null;
  const { weekStart, weekEnd } = getWeekBoundaries();

  const existing = await db
    .select()
    .from(weeklyCredits)
    .where(
      and(
        eq(weeklyCredits.userId, userId),
        gte(weeklyCredits.weekStart, weekStart),
        lte(weeklyCredits.weekEnd, weekEnd)
      )
    )
    .limit(1);

  if (existing.length > 0) return existing[0];

  // Create new cycle with plan-based limits
  const sonnetTotal = plan === "premium" ? 9 : 4;
  const haikuTotal = plan === "premium" ? 15 : 10;

  await db.insert(weeklyCredits).values({
    userId,
    weekStart,
    weekEnd,
    sonnetTotal,
    sonnetUsed: 0,
    sonnetOrbitaUsed: false,
    haikuTotal,
    haikuUsed: 0,
  });

  const created = await db
    .select()
    .from(weeklyCredits)
    .where(
      and(
        eq(weeklyCredits.userId, userId),
        gte(weeklyCredits.weekStart, weekStart)
      )
    )
    .limit(1);

  return created[0] ?? null;
}

export async function consumeCredit(
  userId: number,
  model: "sonnet" | "haiku",
  isOrbitaSemanal = false
) {
  const db = await getDb();
  if (!db) return { success: false, reason: "db_unavailable" };

  const { weekStart, weekEnd } = getWeekBoundaries();
  const credits = await db
    .select()
    .from(weeklyCredits)
    .where(
      and(
        eq(weeklyCredits.userId, userId),
        gte(weeklyCredits.weekStart, weekStart),
        lte(weeklyCredits.weekEnd, weekEnd)
      )
    )
    .limit(1);

  if (!credits[0]) return { success: false, reason: "no_credits_record" };
  const c = credits[0];

  if (model === "sonnet") {
    // Órbita Semanal has its own guaranteed slot
    if (isOrbitaSemanal) {
      if (c.sonnetOrbitaUsed) return { success: false, reason: "orbita_already_used" };
      await db
        .update(weeklyCredits)
        .set({ sonnetOrbitaUsed: true })
        .where(eq(weeklyCredits.id, c.id));
      return { success: true };
    }
    if (c.sonnetUsed >= c.sonnetTotal) return { success: false, reason: "sonnet_limit_reached" };
    await db
      .update(weeklyCredits)
      .set({ sonnetUsed: c.sonnetUsed + 1 })
      .where(eq(weeklyCredits.id, c.id));
  } else {
    if (c.haikuUsed >= c.haikuTotal) return { success: false, reason: "haiku_limit_reached" };
    await db
      .update(weeklyCredits)
      .set({ haikuUsed: c.haikuUsed + 1 })
      .where(eq(weeklyCredits.id, c.id));
  }

  return { success: true };
}

// ─── Chat Sessions ─────────────────────────────────────────────────────────────
export async function createChatSession(data: {
  userId: number;
  protocolId?: string;
  protocolName?: string;
  title?: string;
  model: "sonnet" | "haiku";
}) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(chatSessions).values({
    userId: data.userId,
    protocolId: data.protocolId ?? null,
    protocolName: data.protocolName ?? null,
    title: data.title ?? null,
    model: data.model,
    status: "active",
    creditsConsumed: 0,
  });
  const result = await db
    .select()
    .from(chatSessions)
    .where(eq(chatSessions.userId, data.userId))
    .orderBy(desc(chatSessions.createdAt))
    .limit(1);
  return result[0] ?? null;
}

export async function getChatSessions(userId: number, status?: "active" | "archived") {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(chatSessions.userId, userId)];
  if (status) conditions.push(eq(chatSessions.status, status));
  return db
    .select()
    .from(chatSessions)
    .where(and(...conditions))
    .orderBy(desc(chatSessions.createdAt));
}

export async function archiveChatSession(sessionId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(chatSessions)
    .set({ status: "archived", archivedAt: new Date() })
    .where(eq(chatSessions.id, sessionId));
}

export async function getChatMessages(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId))
    .orderBy(chatMessages.createdAt);
}

export async function addChatMessage(data: {
  sessionId: number;
  userId: number;
  role: "user" | "assistant" | "system";
  content: string;
  model?: "sonnet" | "haiku";
  tokensUsed?: number;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(chatMessages).values({
    sessionId: data.sessionId,
    userId: data.userId,
    role: data.role,
    content: data.content,
    model: data.model ?? null,
    tokensUsed: data.tokensUsed ?? null,
  });
}

// ─── Protocol History ──────────────────────────────────────────────────────────
export async function getProtocolHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(protocolHistory)
    .where(eq(protocolHistory.userId, userId))
    .orderBy(desc(protocolHistory.createdAt));
}

// ─── Onboarding ───────────────────────────────────────────────────────────────
export async function completeOnboarding(
  userId: number,
  cartaDeNavegacao: Record<string, string | string[]>
) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(users)
    .set({
      onboardingCompleted: true,
      cartaDeNavegacaoCompleted: true,
    })
    .where(eq(users.id, userId));
}

// ─── Carta de Navegação ───────────────────────────────────────────────────────
export async function getCartaDeNavegacao(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(cartaDeNavegacao)
    .where(eq(cartaDeNavegacao.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function upsertCartaDeNavegacao(
  userId: number,
  data: Partial<typeof cartaDeNavegacao.$inferInsert>
) {
  const db = await getDb();
  if (!db) return;
  const existing = await getCartaDeNavegacao(userId);
  if (existing) {
    await db
      .update(cartaDeNavegacao)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(cartaDeNavegacao.userId, userId));
  } else {
    await db.insert(cartaDeNavegacao).values({ userId, ...data });
  }
}

// ─── User Progress (Gamificação) ──────────────────────────────────────────────

// Fases da implementação — ordem sequencial obrigatória
// plano_voo → missoes_semana → checkin_semanal → comandos → revisao_trimestral
export const IMPLEMENTATION_PHASES = [
  { id: "plano_voo",          label: "plano de vôo",          phase: 1 },
  { id: "missoes_semana",     label: "missões da semana",      phase: 2 },
  { id: "checkin_semanal",    label: "check-in semanal",       phase: 3 },
  { id: "comandos",           label: "biblioteca de comandos", phase: 4 },
  { id: "revisao_trimestral", label: "revisão trimestral",     phase: 5 },
] as const;

export type PhaseId = typeof IMPLEMENTATION_PHASES[number]["id"];

export async function getUserProgress(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(userProgress)
    .where(eq(userProgress.userId, userId))
    .limit(1);
  if (result.length > 0) return result[0];

  // Criar registro inicial se não existir
  await db.insert(userProgress).values({
    userId,
    currentPhase: 1, // Plano de Voo já desbloqueado por padrão
    completedPhases: [],
    prysmasEarned: 0,
  });
  const fresh = await db
    .select()
    .from(userProgress)
    .where(eq(userProgress.userId, userId))
    .limit(1);
  return fresh.length > 0 ? fresh[0] : null;
}

export async function unlockNextPhase(userId: number, completedPhaseId: PhaseId): Promise<{ prysmasAwarded: number; nextPhaseId: string | null }> {
  const db = await getDb();
  if (!db) return { prysmasAwarded: 0, nextPhaseId: null };

  const progress = await getUserProgress(userId);
  if (!progress) return { prysmasAwarded: 0, nextPhaseId: null };

  const completed = (progress.completedPhases as string[]) ?? [];

  // Evitar duplicatas
  if (completed.includes(completedPhaseId)) {
    return { prysmasAwarded: 0, nextPhaseId: null };
  }

  const newCompleted = [...completed, completedPhaseId];
  const currentPhaseData = IMPLEMENTATION_PHASES.find(p => p.id === completedPhaseId);
  const nextPhaseData = IMPLEMENTATION_PHASES.find(p => p.phase === (currentPhaseData?.phase ?? 0) + 1);

  const newCurrentPhase = nextPhaseData ? nextPhaseData.phase : (currentPhaseData?.phase ?? progress.currentPhase);
  const prysmasToAward = 3;

  await db
    .update(userProgress)
    .set({
      completedPhases: newCompleted,
      currentPhase: newCurrentPhase,
      prysmasEarned: sql`${userProgress.prysmasEarned} + ${prysmasToAward}`,
      updatedAt: new Date(),
    })
    .where(eq(userProgress.userId, userId));

  // Atualizar total de prysmas no usuário (incremental — não sobrescreve prysmas de subfases)
  await db
    .update(users)
    .set({ prysmasTotal: sql`${users.prysmasTotal} + ${prysmasToAward}` })
    .where(eq(users.id, userId));

  return { prysmasAwarded: prysmasToAward, nextPhaseId: nextPhaseData?.id ?? null };
}

// ─── 2º Cérebro (Brain Notes) ─────────────────────────────────────────────────

export async function getBrainNotes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(brainNotes)
    .where(eq(brainNotes.userId, userId))
    .orderBy(brainNotes.sortOrder, brainNotes.createdAt);
}

export async function createBrainNote(
  userId: number,
  data: { content: string; type: "note" | "checklist" | "bullet"; sortOrder?: number }
) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(brainNotes).values({
    userId,
    content: data.content,
    type: data.type,
    sortOrder: data.sortOrder ?? 0,
  });
  return result;
}

export async function updateBrainNote(
  userId: number,
  noteId: number,
  data: { content?: string; checked?: boolean; sortOrder?: number }
) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(brainNotes)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(brainNotes.id, noteId), eq(brainNotes.userId, userId)));
}

export async function deleteBrainNote(userId: number, noteId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .delete(brainNotes)
    .where(and(eq(brainNotes.id, noteId), eq(brainNotes.userId, userId)));
}

// ─── Plano de Vôo — Helpers ────────────────────────────────────────────────────
export async function getFlightPhases() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(flightPhases).where(eq(flightPhases.active, true)).orderBy(flightPhases.sortOrder);
}

export async function getAllFlightPhases() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(flightPhases).orderBy(flightPhases.sortOrder);
}

export async function getFlightSubphases(phaseId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(flightSubphases)
    .where(and(eq(flightSubphases.phaseId, phaseId), eq(flightSubphases.active, true)))
    .orderBy(flightSubphases.sortOrder);
}

export async function getAllFlightSubphases() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(flightSubphases).orderBy(flightSubphases.phaseId, flightSubphases.sortOrder);
}

export async function upsertFlightPhase(data: InsertFlightPhase & { id?: number }) {
  const db = await getDb();
  if (!db) return null;
  if (data.id) {
    await db.update(flightPhases).set({ ...data, updatedAt: new Date() }).where(eq(flightPhases.id, data.id));
    return data.id;
  }
  const result = await db.insert(flightPhases).values(data);
  return (result as any).insertId as number;
}

export async function deleteFlightPhase(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(flightSubphases).where(eq(flightSubphases.phaseId, id));
  await db.delete(flightPhases).where(eq(flightPhases.id, id));
}

export async function upsertFlightSubphase(data: InsertFlightSubphase & { id?: number }) {
  const db = await getDb();
  if (!db) return null;
  if (data.id) {
    await db.update(flightSubphases).set({ ...data, updatedAt: new Date() }).where(eq(flightSubphases.id, data.id));
    return data.id;
  }
  const result = await db.insert(flightSubphases).values(data);
  return (result as any).insertId as number;
}

export async function deleteFlightSubphase(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(flightSubphases).where(eq(flightSubphases.id, id));
}

export async function getUserPhaseProgress(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(userPhaseProgress).where(eq(userPhaseProgress.userId, userId));
}

export async function completeSubphase(
  userId: number,
  phaseId: number,
  subphaseId: number | null,
  prysmas: number
) {
  const db = await getDb();
  if (!db) return;
  await db.insert(userPhaseProgress).values({
    userId,
    phaseId,
    subphaseId: subphaseId ?? undefined,
    prysmasAwarded: prysmas,
  });
  // Atualizar prysmasTotal no usuário (incremental)
  await db
    .update(users)
    .set({ prysmasTotal: sql`${users.prysmasTotal} + ${prysmas}` })
    .where(eq(users.id, userId));
  // Atualizar prysmasEarned no userProgress (para manter consistente com o contador da sidebar)
  const existingProgress = await getUserProgress(userId);
  if (existingProgress) {
    await db
      .update(userProgress)
      .set({ prysmasEarned: sql`${userProgress.prysmasEarned} + ${prysmas}`, updatedAt: new Date() })
      .where(eq(userProgress.userId, userId));
  } else {
    await db.insert(userProgress).values({
      userId,
      currentPhase: 1,
      completedPhases: [],
      prysmasEarned: prysmas,
    });
  }
}

// ─── Gerenciamento de Dados (LGPD) ────────────────────────────────────────────

/** Limpa todo o histórico de chats do usuário (sessões + mensagens) */
export async function clearUserChats(userId: number) {
  const db = await getDb();
  if (!db) return;
  const sessions = await db.select({ id: chatSessions.id }).from(chatSessions).where(eq(chatSessions.userId, userId));
  for (const s of sessions) {
    await db.delete(chatMessages).where(eq(chatMessages.sessionId, s.id));
  }
  await db.delete(chatSessions).where(eq(chatSessions.userId, userId));
}

/** Zera o contador de prysmas e limpa o progresso de fases — volta ao estado de novo usuário */
export async function resetUserPrysmas(userId: number) {
  const db = await getDb();
  if (!db) return;
  // Zera prysmasTotal na tabela users
  await db.update(users).set({ prysmasTotal: 0 }).where(eq(users.id, userId));
  // Zera prysmasEarned e reseta progresso na tabela userProgress
  await db.update(userProgress)
    .set({ prysmasEarned: 0, completedPhases: [], currentPhase: 0 })
    .where(eq(userProgress.userId, userId));
  // Limpa progresso granular de subfases
  await db.delete(userPhaseProgress).where(eq(userPhaseProgress.userId, userId));
}

/** Reinicia o Prysma: limpa todos os dados operacionais, volta ao estado de novo usuário (mantém conta e integrações) */
export async function clearAllUserData(userId: number) {
  const db = await getDb();
  if (!db) return;
  // Chats
  await clearUserChats(userId);
  // Prysmas + progresso de fases (usa resetUserPrysmas para garantir consistência)
  await resetUserPrysmas(userId);
  // Histórico de protocolos
  await db.delete(protocolHistory).where(eq(protocolHistory.userId, userId));
  // Brain notes
  await db.delete(brainNotes).where(eq(brainNotes.userId, userId));
  // Carta de navegação
  await db.delete(cartaDeNavegacao).where(eq(cartaDeNavegacao.userId, userId));
  // Créditos semanais
  await db.delete(weeklyCredits).where(eq(weeklyCredits.userId, userId));
  // Reset flags de onboarding — volta ao estado de novo usuário
  await db.update(users)
    .set({ onboardingCompleted: false, cartaDeNavegacaoCompleted: false, prysmasTotal: 0 })
    .where(eq(users.id, userId));
}

/** Exclui a conta do usuário e todos os seus dados */
export async function deleteUserAccount(userId: number) {
  const db = await getDb();
  if (!db) return;
  await clearAllUserData(userId);
  await db.delete(userIntegrations).where(eq(userIntegrations.userId, userId));
  await db.delete(users).where(eq(users.id, userId));
}
