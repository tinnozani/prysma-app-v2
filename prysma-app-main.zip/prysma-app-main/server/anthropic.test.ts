import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";
import { callAnthropic, getModelForProtocol, MODELS, PROTOCOL_MODEL_MAP } from "./prysma-ai";

describe("prysma-ai: roteamento de modelos", () => {
  it("retorna sonnet para protocolos de profundidade", () => {
    expect(getModelForProtocol("carta_de_navegacao")).toBe("sonnet");
    expect(getModelForProtocol("sinastria_criativa")).toBe("sonnet");
    expect(getModelForProtocol("orbita_semanal")).toBe("sonnet");
    expect(getModelForProtocol("revisao_trimestral")).toBe("sonnet");
  });

  it("retorna haiku para protocolos táticos", () => {
    expect(getModelForProtocol("lancamento_de_nave")).toBe("haiku");
    expect(getModelForProtocol("missao_rapida")).toBe("haiku");
    expect(getModelForProtocol("segundo_cerebro")).toBe("haiku");
    expect(getModelForProtocol("input_livre")).toBe("haiku");
  });

  it("retorna haiku como fallback para protocolo desconhecido", () => {
    expect(getModelForProtocol("protocolo_inexistente")).toBe("haiku");
  });

  it("todos os protocolos mapeados têm modelos válidos", () => {
    for (const [protocol, model] of Object.entries(PROTOCOL_MODEL_MAP)) {
      expect(["sonnet", "haiku"]).toContain(model);
      expect(MODELS[model]).toBeDefined();
    }
  });
});

describe("prysma-ai: API Anthropic", () => {
  it("chave ANTHROPIC_API_KEY está configurada", () => {
    expect(ENV.anthropicApiKey).toBeTruthy();
    expect(ENV.anthropicApiKey.length).toBeGreaterThan(10);
  });

  it("chave é válida (formato correto)", () => {
    // Valida o formato da chave sem fazer chamada à API (evita consumo de créditos)
    expect(ENV.anthropicApiKey).toMatch(/^sk-ant-/);
  });
});
