/**
 * prysma_ — Rota de Streaming do Chat
 * POST /api/chat/stream
 * Retorna Server-Sent Events (SSE) com a resposta do Navegador
 */

import type { Express, Request, Response } from "express";
import { sdk } from "./_core/sdk";
import {
  addChatMessage,
  consumeCredit,
  createChatSession,
  getChatMessages,
  getChatSessions,
  getIntegration,
  getOrCreateWeeklyCredits,
} from "./db";
import {
  callAnthropicStream,
  getModelForProtocol,
  type AnthropicMessage,
} from "./prysma-ai";

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getUserFromRequest(req: Request): Promise<{ id: number; plan: string } | null> {
  try {
    const user = await sdk.authenticateRequest(req);
    return user ?? null;
  } catch {
    return null;
  }
}

// ─── Registro das Rotas de Chat ───────────────────────────────────────────────

export function registerChatRoutes(app: Express) {
  /**
   * POST /api/chat/stream
   * Body: { sessionId?, protocolKey?, message, forceDeep? }
   * Resposta: SSE com chunks de texto
   */
  app.post("/api/chat/stream", async (req: Request, res: Response) => {
    const user = await getUserFromRequest(req);
    if (!user) {
      res.status(401).json({ error: "não autorizado" });
      return;
    }

    const { sessionId, protocolKey = "input_livre", message, forceDeep = false } = req.body as {
      sessionId?: number;
      protocolKey?: string;
      message: string;
      forceDeep?: boolean;
    };

    if (!message?.trim()) {
      res.status(400).json({ error: "mensagem vazia" });
      return;
    }

    // Determina o modelo a usar
    const effectiveProtocol = forceDeep ? `${protocolKey}_profundo` : protocolKey;
    const modelKey = getModelForProtocol(effectiveProtocol);
    const isOrbitaSemanal = protocolKey === "orbita_semanal";

    // Verifica créditos disponíveis
    const plan = (user.plan as "essencial" | "premium") ?? "essencial";
    const credits = await getOrCreateWeeklyCredits(user.id, plan);
    if (!credits) {
      res.status(500).json({ error: "erro ao verificar cristais de energia" });
      return;
    }

    const creditResult = await consumeCredit(user.id, modelKey, isOrbitaSemanal);
    if (!creditResult.success) {
      res.status(402).json({
        error: "cristais_esgotados",
        message: creditResult.reason ?? "seus cristais de energia foram totalmente consumidos neste ciclo.",
      });
      return;
    }

    // Cria ou recupera a sessão
    let activeSessionId = sessionId;
    if (!activeSessionId) {
      const newSession = await createChatSession({
        userId: user.id,
        protocolId: protocolKey,
        protocolName: protocolKey.replace(/_/g, " "),
        model: modelKey,
      });
      if (!newSession) {
        res.status(500).json({ error: "erro ao criar sessão" });
        return;
      }
      activeSessionId = newSession.id;
    }

    // Busca histórico da sessão para contexto
    const sessions = await getChatSessions(user.id);
    const owns = sessions.some((s) => s.id === activeSessionId);
    if (!owns) {
      res.status(403).json({ error: "sessão não encontrada" });
      return;
    }

    const history = await getChatMessages(activeSessionId!);

    // Salva a mensagem do usuário
    await addChatMessage({
      sessionId: activeSessionId!,
      userId: user.id,
      role: "user",
      content: message,
      model: modelKey,
    });

    // Monta o histórico para a API
    const apiMessages: AnthropicMessage[] = [
      ...history.map((msg) => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      })),
      { role: "user", content: message },
    ];

    // Busca a Carta de Navegação do usuário (se existir)
    const notionIntegration = await getIntegration(user.id, "notion");
    const cartaDeNavegacao = (notionIntegration?.metadata as any)?.cartaDeNavegacao ?? undefined;

    // Configura SSE
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Session-Id", String(activeSessionId));
    res.flushHeaders();

    let fullResponse = "";

    try {
      const stream = await callAnthropicStream(apiMessages, {
        protocolKey: effectiveProtocol,
        cartaDeNavegacao,
        maxTokens: modelKey === "sonnet" ? 4096 : 2048,
      });

      const reader = stream.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6);
          if (data === "[DONE]") continue;

          try {
            const parsed = JSON.parse(data);
            // Anthropic SSE format
            if (parsed.type === "content_block_delta" && parsed.delta?.type === "text_delta") {
              const text = parsed.delta.text;
              fullResponse += text;
              res.write(`data: ${JSON.stringify({ text })}\n\n`);
            }
          } catch {
            // linha não é JSON válido — ignora
          }
        }
      }

      // Salva a resposta completa no banco
      await addChatMessage({
        sessionId: activeSessionId!,
        userId: user.id,
        role: "assistant",
        content: fullResponse,
        model: modelKey,
      });

      // Sinaliza fim do stream com metadados
      res.write(`data: ${JSON.stringify({
        done: true,
        sessionId: activeSessionId,
        model: modelKey,
        suggestDeepen: modelKey === "haiku" && fullResponse.length > 200,
      })}\n\n`);

    } catch (err: any) {
      const errorMsg = err?.message ?? "erro desconhecido";
      res.write(`data: ${JSON.stringify({ error: errorMsg })}\n\n`);
    } finally {
      res.end();
    }
  });

  /**
   * GET /api/chat/session/:sessionId
   * Retorna metadados da sessão e mensagens
   */
  app.get("/api/chat/session/:sessionId", async (req: Request, res: Response) => {
    const user = await getUserFromRequest(req);
    if (!user) {
      res.status(401).json({ error: "não autorizado" });
      return;
    }

    const sessionId = parseInt(req.params.sessionId);
    if (isNaN(sessionId)) {
      res.status(400).json({ error: "sessionId inválido" });
      return;
    }

    const sessions = await getChatSessions(user.id);
    const session = sessions.find((s) => s.id === sessionId);
    if (!session) {
      res.status(404).json({ error: "sessão não encontrada" });
      return;
    }

    const messages = await getChatMessages(sessionId);
    res.json({ session, messages });
  });
}
