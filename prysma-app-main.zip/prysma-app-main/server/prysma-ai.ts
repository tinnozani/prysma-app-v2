import { ENV } from "./_core/env";

export const MODELS = {
  sonnet: "claude-3-5-sonnet-20241022",
  haiku: "claude-3-5-haiku-20241022",
} as const;

export type ModelKey = keyof typeof MODELS;

export const PROTOCOL_MODEL_MAP: Record<string, ModelKey> = {
  "carta": "sonnet",
  "01": "sonnet",
  "sinastria_criativa": "sonnet",
  "duelo_de_sinastria": "sonnet",
  "orbita_semanal": "sonnet",
  "revisao_trimestral": "sonnet",
  "input_livre": "haiku",
  "segundo_cerebro": "haiku",
};

export function getModelForProtocol(protocolKey: string): ModelKey {
  return PROTOCOL_MODEL_MAP[protocolKey] ?? "haiku";
}

export function buildSystemPrompt(protocolId?: string, cartaDeNavegacao?: string, messageCount: number = 0): string {
  const base = `# KERNEL PRYSMA V7.2
identidade: prysma_ (navegador de energia criativa).
tom: franqueza elegante, direto, sóbrio.
regras: minúsculas sempre, marcadores :: e }_, tratar como comandante.
${cartaDeNavegacao ? `\n## CARTA ATUAL\n${JSON.stringify(cartaDeNavegacao)}` : ""}`;

  if (protocolId === "01" || protocolId === "carta") {
    return `${base}
## PROTOCOLO 01 :: CARTA DE NAVEGAÇÃO
objetivo: mapear o ponto zero (essência vs sobrevivência).
TURNO ATUAL: ${messageCount + 1}. 
REGRA ABSOLUTA: é proibido gerar a carta final antes do turno 11.
PING-PONG: faça apenas uma pergunta por vez.
ISOLAMENTO: não use termos técnicos (tríade, tud, etc) até o turno final.`;
  }

  return `${base}\nprotocolo ativo: ${protocolId ?? "input livre"}`;
}

export async function callAnthropic(messages: any[], options: any = {}) {
  const { protocolKey = "input_livre", cartaDeNavegacao, messageCount = 0 } = options;
  const modelKey = getModelForProtocol(protocolKey);
  const systemPrompt = buildSystemPrompt(protocolKey, cartaDeNavegacao, messageCount);

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": ENV.anthropicApiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODELS[modelKey],
      max_tokens: 4096,
      system: systemPrompt,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
    }),
  });

  const data = await response.json();
  return data.content[0].text;
}