const NOTION_API = "https://api.notion.com/v1";
const NOTION_VERSION = "2022-06-28";

function notionHeaders(token: string) {
  return {
    Authorization: `Bearer ${token}`,
    "Notion-Version": NOTION_VERSION,
    "Content-Type": "application/json",
  };
}

const DB_PROJETOS_ID = "7c5c66f1-40dd-82f4-8e1e-87aecb2d6202";

export async function upsertProjetoNotion(token: string, data: any) {
  const properties: any = {
    "Projetos": { title: [{ text: { content: data.nome } }] },
    "Órbita": { select: { name: data.orbita } },
    "Status": { select: { name: data.status } }
  };
  if (data.horizonte) properties["Horizonte"] = { rich_text: [{ text: { content: data.horizonte } }] };

  return fetch(`${NOTION_API}/pages`, {
    method: "POST",
    headers: notionHeaders(token),
    body: JSON.stringify({ parent: { database_id: DB_PROJETOS_ID }, properties }),
  });
}

// ... mantenha as funções de queryTUD que já existiam