/**
 * integrations-oauth.ts
 * Rotas Express para OAuth do Notion e Google Calendar
 *
 * Fluxo Notion:
 * 1. /api/integrations/notion/connect → redireciona para o Notion OAuth
 * 2. /api/integrations/notion/callback → recebe o code, troca por token, salva no DB
 *
 * Fluxo Google Calendar:
 * 1. /api/integrations/google/connect → redireciona para o Google OAuth
 * 2. /api/integrations/google/callback → recebe o code, troca por token, salva no DB
 */

import type { Express, Request, Response } from "express";
import { getUserByOpenId, upsertIntegration } from "./db";
import { sdk } from "./_core/sdk";

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getUserFromRequest(req: Request) {
  try {
    const session = await sdk.authenticateRequest(req as Parameters<typeof sdk.authenticateRequest>[0]);
    if (!session?.openId) return null;
    return getUserByOpenId(session.openId);
  } catch {
    return null;
  }
}

function getBaseUrl(req: Request): string {
  const proto = req.headers["x-forwarded-proto"] || req.protocol || "https";
  const host = req.headers["x-forwarded-host"] || req.headers.host || "localhost:3000";
  return `${proto}://${host}`;
}

// ─── Notion OAuth ─────────────────────────────────────────────────────────────

function registerNotionOAuth(app: Express) {
  const NOTION_CLIENT_ID = process.env.NOTION_CLIENT_ID;
  const NOTION_CLIENT_SECRET = process.env.NOTION_CLIENT_SECRET;

  // Inicia o fluxo OAuth do Notion
  app.get("/api/integrations/notion/connect", async (req: Request, res: Response) => {
    const user = await getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: "Não autenticado" });

    if (!NOTION_CLIENT_ID) {
      return res.status(503).json({
        error: "notion_not_configured",
        message: "Integração com Notion não configurada ainda.",
      });
    }

    const baseUrl = getBaseUrl(req);
    const redirectUri = `${baseUrl}/api/integrations/notion/callback`;
    const state = Buffer.from(JSON.stringify({ userId: user.id })).toString("base64");

    const notionAuthUrl = new URL("https://api.notion.com/v1/oauth/authorize");
    notionAuthUrl.searchParams.set("client_id", NOTION_CLIENT_ID);
    notionAuthUrl.searchParams.set("response_type", "code");
    notionAuthUrl.searchParams.set("owner", "user");
    notionAuthUrl.searchParams.set("redirect_uri", redirectUri);
    notionAuthUrl.searchParams.set("state", state);

    return res.redirect(notionAuthUrl.toString());
  });

  // Callback do Notion OAuth
  app.get("/api/integrations/notion/callback", async (req: Request, res: Response) => {
    const { code, state, error } = req.query as Record<string, string>;

    if (error) {
      return res.redirect(`/perfil?notion_error=${encodeURIComponent(error)}`);
    }

    if (!code || !state) {
      return res.redirect("/perfil?notion_error=missing_params");
    }

    if (!NOTION_CLIENT_ID || !NOTION_CLIENT_SECRET) {
      return res.redirect("/perfil?notion_error=not_configured");
    }

    try {
      const stateData = JSON.parse(Buffer.from(state, "base64").toString());
      const userId = stateData.userId;

      const baseUrl = getBaseUrl(req);
      const redirectUri = `${baseUrl}/api/integrations/notion/callback`;

      // Troca o code pelo token de acesso
      const tokenResponse = await fetch("https://api.notion.com/v1/oauth/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Basic ${Buffer.from(`${NOTION_CLIENT_ID}:${NOTION_CLIENT_SECRET}`).toString("base64")}`,
        },
        body: JSON.stringify({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri,
        }),
      });

      if (!tokenResponse.ok) {
        const errText = await tokenResponse.text();
        console.error("[Notion OAuth] Token exchange failed:", errText);
        return res.redirect("/perfil?notion_error=token_exchange_failed");
      }

      const tokenData = await tokenResponse.json() as {
        access_token: string;
        workspace_id: string;
        workspace_name: string;
        bot_id: string;
        duplicated_template_id?: string;
      };

      // Salva a integração no banco
      await upsertIntegration({
        userId,
        provider: "notion",
        accessToken: tokenData.access_token,
        workspaceId: tokenData.workspace_id,
        workspaceName: tokenData.workspace_name,
        templatePageId: tokenData.duplicated_template_id ?? undefined,
        providerUserId: tokenData.bot_id,
        metadata: tokenData,
      });

      return res.redirect("/perfil?notion_success=1");
    } catch (err) {
      console.error("[Notion OAuth] Callback error:", err);
      return res.redirect("/perfil?notion_error=callback_failed");
    }
  });
}

// ─── Google Calendar OAuth ────────────────────────────────────────────────────

function registerGoogleOAuth(app: Express) {
  const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
  const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

  const SCOPES = [
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/calendar.events",
  ].join(" ");

  // Inicia o fluxo OAuth do Google
  app.get("/api/integrations/google/connect", async (req: Request, res: Response) => {
    const user = await getUserFromRequest(req);
    if (!user) return res.status(401).json({ error: "Não autenticado" });

    if (!GOOGLE_CLIENT_ID) {
      return res.status(503).json({
        error: "google_not_configured",
        message: "Integração com Google Calendar não configurada ainda.",
      });
    }

    const baseUrl = getBaseUrl(req);
    const redirectUri = `${baseUrl}/api/integrations/google/callback`;
    const state = Buffer.from(JSON.stringify({ userId: user.id })).toString("base64");

    const googleAuthUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
    googleAuthUrl.searchParams.set("client_id", GOOGLE_CLIENT_ID);
    googleAuthUrl.searchParams.set("response_type", "code");
    googleAuthUrl.searchParams.set("scope", SCOPES);
    googleAuthUrl.searchParams.set("redirect_uri", redirectUri);
    googleAuthUrl.searchParams.set("state", state);
    googleAuthUrl.searchParams.set("access_type", "offline");
    googleAuthUrl.searchParams.set("prompt", "consent");

    return res.redirect(googleAuthUrl.toString());
  });

  // Callback do Google OAuth
  app.get("/api/integrations/google/callback", async (req: Request, res: Response) => {
    const { code, state, error } = req.query as Record<string, string>;

    if (error) {
      return res.redirect(`/perfil?google_error=${encodeURIComponent(error)}`);
    }

    if (!code || !state) {
      return res.redirect("/perfil?google_error=missing_params");
    }

    if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
      return res.redirect("/perfil?google_error=not_configured");
    }

    try {
      const stateData = JSON.parse(Buffer.from(state, "base64").toString());
      const userId = stateData.userId;

      const baseUrl = getBaseUrl(req);
      const redirectUri = `${baseUrl}/api/integrations/google/callback`;

      // Troca o code pelo token de acesso
      const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          code,
          client_id: GOOGLE_CLIENT_ID,
          client_secret: GOOGLE_CLIENT_SECRET,
          redirect_uri: redirectUri,
          grant_type: "authorization_code",
        }),
      });

      if (!tokenResponse.ok) {
        const errText = await tokenResponse.text();
        console.error("[Google OAuth] Token exchange failed:", errText);
        return res.redirect("/perfil?google_error=token_exchange_failed");
      }

      const tokenData = await tokenResponse.json() as {
        access_token: string;
        refresh_token?: string;
        expires_in: number;
        token_type: string;
      };

      // Busca o email do usuário Google
      const userInfoResponse = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      const userInfo = await userInfoResponse.json() as { id: string; email: string };

      const tokenExpiresAt = new Date(Date.now() + tokenData.expires_in * 1000);

      // Salva a integração no banco
      await upsertIntegration({
        userId,
        provider: "google_calendar",
        accessToken: tokenData.access_token,
        refreshToken: tokenData.refresh_token ?? undefined,
        tokenExpiresAt,
        providerUserId: userInfo.id,
        metadata: { email: userInfo.email },
      });

      return res.redirect("/perfil?google_success=1");
    } catch (err) {
      console.error("[Google OAuth] Callback error:", err);
      return res.redirect("/perfil?google_error=callback_failed");
    }
  });
}

// ─── Registro Principal ───────────────────────────────────────────────────────

export function registerIntegrationOAuthRoutes(app: Express) {
  registerNotionOAuth(app);
  registerGoogleOAuth(app);
}
